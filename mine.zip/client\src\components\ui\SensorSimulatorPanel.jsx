// client/src/components/ui/SensorSimulatorPanel.jsx
// Interactive Sensor Override & Hazard Simulator Panel for SIH 2026 Demonstrations

import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useMinoMine } from "../../context/MinoMineContext";

export default function SensorSimulatorPanel() {
  const { workers, selectedWorkerId, setSelectedWorkerId, updateWorkerSensor, triggerHazardEvent, clearAllEmergencies } = useMinoMine();
  const [isOpen, setIsOpen] = useState(false);

  const activeWorkerId = selectedWorkerId || workers[0]?.id || "W001";
  const worker = workers.find((w) => w.id === activeWorkerId) || workers[0];

  if (!worker) return null;

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end">
      {/* Trigger Toggle Button */}
      <motion.button
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={() => setIsOpen((v) => !v)}
        className="flex items-center gap-2.5 px-4 py-2.5 rounded-full font-mono text-xs font-bold text-black bg-mine-neon shadow-[0_0_20px_rgba(255,107,0,0.4)] transition-all"
      >
        <span className="text-sm">⚡</span>
        <span>{isOpen ? "CLOSE SENSOR SIMULATOR" : "SIH SENSOR SIMULATOR"}</span>
      </motion.button>

      {/* Simulator Drawer Panel */}
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.95 }}
            className="mb-3 w-96 glass-strong rounded-2xl p-5 border border-mine-neon/30 shadow-2xl text-white overflow-hidden"
          >
            {/* Header */}
            <div className="flex items-center justify-between pb-3 border-b border-white/10 mb-4">
              <div>
                <h4 className="font-display font-bold text-sm text-mine-neon uppercase tracking-wider">
                  Hardware Sensor Overrides
                </h4>
                <p className="font-mono text-[10px] text-white/40">SIH 2026 Demo Control Console</p>
              </div>
              <button
                onClick={() => clearAllEmergencies()}
                className="text-[10px] font-mono px-2 py-1 rounded bg-mine-safe/20 text-mine-safe border border-mine-safe/40 hover:bg-mine-safe/30 transition-all"
              >
                RESET ALL
              </button>
            </div>

            {/* Target Worker Selector */}
            <div className="mb-4">
              <label className="block text-[10px] font-mono text-white/40 uppercase mb-1">
                Target Underground Miner
              </label>
              <select
                value={activeWorkerId}
                onChange={(e) => setSelectedWorkerId(e.target.value)}
                className="w-full bg-black/60 border border-white/15 rounded-lg px-3 py-1.5 font-mono text-xs text-white focus:outline-none focus:border-mine-neon"
              >
                {workers.map((w) => (
                  <option key={w.id} value={w.id}>
                    {w.id} - {w.name} ({w.zone.split("–")[0].trim()}) [{w.safetyStatus}]
                  </option>
                ))}
              </select>
            </div>

            {/* Quick Hazard Event Triggers */}
            <div className="mb-5">
              <label className="block text-[10px] font-mono text-white/40 uppercase mb-2">
                Simulate Hardware Hazard Event
              </label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  onClick={() => triggerHazardEvent(activeWorkerId, "FALL")}
                  className="px-2.5 py-1.5 rounded bg-red-950/60 border border-red-500/40 hover:border-red-400 text-[10px] font-mono font-semibold text-red-300 flex items-center justify-center gap-1 transition-colors"
                >
                  <span>🤸</span> MPU6050 Fall
                </button>
                <button
                  onClick={() => triggerHazardEvent(activeWorkerId, "GAS_LEAK")}
                  className="px-2.5 py-1.5 rounded bg-yellow-950/60 border border-yellow-500/40 hover:border-yellow-400 text-[10px] font-mono font-semibold text-yellow-300 flex items-center justify-center gap-1 transition-colors"
                >
                  <span>☁️</span> MQ Gas Leak
                </button>
                <button
                  onClick={() => triggerHazardEvent(activeWorkerId, "FIRE")}
                  className="px-2.5 py-1.5 rounded bg-orange-950/60 border border-orange-500/40 hover:border-orange-400 text-[10px] font-mono font-semibold text-orange-300 flex items-center justify-center gap-1 transition-colors"
                >
                  <span>🔥</span> Flame Sensor
                </button>
                <button
                  onClick={() => triggerHazardEvent(activeWorkerId, "ABNORMAL_HEART_RATE")}
                  className="px-2.5 py-1.5 rounded bg-purple-950/60 border border-purple-500/40 hover:border-purple-400 text-[10px] font-mono font-semibold text-purple-300 flex items-center justify-center gap-1 transition-colors"
                >
                  <span>❤️</span> MAX30102 Spike
                </button>
              </div>
            </div>

            {/* Live Sliders for Fine-Grained Override */}
            <div className="space-y-3 pt-2 border-t border-white/10 text-xs">
              {/* Heart Rate Slider */}
              <div>
                <div className="flex justify-between font-mono text-[10px] text-white/60 mb-1">
                  <span>MAX30102 Heart Rate</span>
                  <span className="text-mine-neon font-bold">{worker.heartRate} BPM</span>
                </div>
                <input
                  type="range"
                  min="40"
                  max="180"
                  value={worker.heartRate}
                  onChange={(e) => updateWorkerSensor(activeWorkerId, "heartRate", parseInt(e.target.value))}
                  className="w-full accent-mine-neon bg-white/10 h-1 rounded cursor-pointer"
                />
              </div>

              {/* MQ Gas PPM Slider */}
              <div>
                <div className="flex justify-between font-mono text-[10px] text-white/60 mb-1">
                  <span>MQ Gas Sensor (PPM)</span>
                  <span className="text-yellow-400 font-bold">{worker.gasLevel} PPM</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="350"
                  value={worker.gasLevel}
                  onChange={(e) => updateWorkerSensor(activeWorkerId, "gasLevel", parseInt(e.target.value))}
                  className="w-full accent-yellow-400 bg-white/10 h-1 rounded cursor-pointer"
                />
              </div>

              {/* Temperature Slider */}
              <div>
                <div className="flex justify-between font-mono text-[10px] text-white/60 mb-1">
                  <span>Temp Sensor</span>
                  <span className="text-orange-400 font-bold">{worker.temperature} °C</span>
                </div>
                <input
                  type="range"
                  min="35.0"
                  max="42.0"
                  step="0.1"
                  value={worker.temperature}
                  onChange={(e) => updateWorkerSensor(activeWorkerId, "temperature", parseFloat(e.target.value))}
                  className="w-full accent-orange-400 bg-white/10 h-1 rounded cursor-pointer"
                />
              </div>

              {/* Toggles */}
              <div className="flex items-center justify-between pt-2">
                <button
                  onClick={() => updateWorkerSensor(activeWorkerId, "fallDetected", !worker.fallDetected)}
                  className={`text-[10px] font-mono px-2 py-1 rounded border transition-colors ${
                    worker.fallDetected
                      ? "bg-red-500/20 text-red-400 border-red-500"
                      : "bg-white/5 text-white/40 border-white/10"
                  }`}
                >
                  MPU6050 Fall: {worker.fallDetected ? "DETECTED" : "NORMAL"}
                </button>
                <button
                  onClick={() => updateWorkerSensor(activeWorkerId, "fireDetected", !worker.fireDetected)}
                  className={`text-[10px] font-mono px-2 py-1 rounded border transition-colors ${
                    worker.fireDetected
                      ? "bg-orange-500/20 text-orange-400 border-orange-500"
                      : "bg-white/5 text-white/40 border-white/10"
                  }`}
                >
                  Flame Sensor: {worker.fireDetected ? "FIRE!" : "CLEAR"}
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
