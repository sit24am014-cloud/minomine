// client/src/views/ControlRoomView.jsx
// MINO MINE — Underground Mining Safety Control Room Operations Command Center (SIH 2026)

import React, { useState, useMemo } from "react";
import { useMinoMine } from "../context/MinoMineContext";
import HardwareDiagnosticModal from "../components/ui/HardwareDiagnosticModal";

export default function ControlRoomView() {
  const {
    workers,
    incidents,
    setSelectedWorkerId,
    triggerHazardEvent,
    acknowledgeIncident,
    dispatchResponse,
    resolveIncident,
    clearAllEmergencies,
    broadcastControlRoomCommand,
    controlRoomBroadcasts,
    clearControlRoomBroadcasts,
  } = useMinoMine();

  // Control Room Command State (FLOW B: CONTROL ROOM -> WORKERS)
  const [selectedCommand, setSelectedCommand] = useState("TUNNEL COLLAPSE");
  const [selectedTargetZone, setSelectedTargetZone] = useState("Zone B – East Tunnel");
  const [selectedRecipients, setSelectedRecipients] = useState(["W002", "W003", "W004", "W005"]);
  const [customMessage, setCustomMessage] = useState("TUNNEL COLLAPSE DETECTED IN ZONE B. EVACUATE TO SAFE ROUTE IMMEDIATELY.");
  const [txAnimPhase, setTxAnimPhase] = useState(null);

  const safeWorkers = useMemo(() => workers.filter((w) => w.safetyStatus === "SAFE"), [workers]);
  const warnWorkers = useMemo(() => workers.filter((w) => w.safetyStatus === "WARNING"), [workers]);
  const critWorkers = useMemo(() => workers.filter((w) => w.safetyStatus === "CRITICAL"), [workers]);
  const activeIncidents = useMemo(() => incidents.filter((i) => i.status !== "RESOLVED"), [incidents]);

  const handleBroadcast = () => {
    broadcastControlRoomCommand({
      type: selectedCommand,
      zone: selectedTargetZone,
      recipientWorkerIds: selectedRecipients,
      message: customMessage,
      severity: "HIGH",
    });

    setTxAnimPhase("TRANSMITTING");
    setTimeout(() => {
      setTxAnimPhase("RECEIVED");
    }, 1200);
    setTimeout(() => {
      setTxAnimPhase(null);
    }, 4500);
  };

  const COMMAND_PRESETS = [
    "TUNNEL COLLAPSE",
    "EVACUATE ZONE",
    "FIRE EVACUATION",
    "GAS LEAK WARNING",
    "MINE-WIDE EMERGENCY",
    "RETURN TO SAFE ZONE",
  ];

  const ZONES = [
    "ALL ZONES",
    "Zone A – Main Shaft",
    "Zone B – East Tunnel",
    "Zone C – Blast Chamber",
    "Zone D – Ore Processing",
  ];

  return (
    <div className="space-y-6 font-sans text-slate-100 bg-[#0b0e14] min-h-screen p-4 sm:p-6">
      {/* ─── MAIN CONTROL ROOM HEADER ─── */}
      <div className="bg-slate-900 p-5 rounded-xl border border-slate-800 flex flex-wrap items-center justify-between gap-4 shadow-lg">
        <div>
          <div className="text-xs font-bold text-amber-500 tracking-wider uppercase">
            MINO MINE
          </div>
          <h1 className="text-2xl font-black text-white tracking-tight mt-0.5">
            UNDERGROUND MINING SAFETY CONTROL SYSTEM
          </h1>
          <p className="text-xs text-slate-400 font-sans mt-0.5">
            Surface Control Room Station · Subterranean Telemetry Command Console
          </p>
        </div>

        <div className="flex items-center gap-3 text-xs">
          <div className="bg-slate-950 px-3 py-2 rounded-lg border border-slate-800">
            <span className="text-slate-400 block text-[10px] uppercase font-bold">SYSTEM</span>
            <span className="font-bold text-emerald-400">ONLINE</span>
          </div>

          <div className="bg-slate-950 px-3 py-2 rounded-lg border border-slate-800">
            <span className="text-slate-400 block text-[10px] uppercase font-bold">NETWORK</span>
            <span className="font-bold text-blue-400">LoRa DEMO</span>
          </div>

          <div className="bg-slate-950 px-3 py-2 rounded-lg border border-slate-800">
            <span className="text-slate-400 block text-[10px] uppercase font-bold">WORKERS</span>
            <span className="font-bold text-white font-mono">{workers.length}</span>
          </div>
        </div>
      </div>

      {/* ─── TOP METRICS SUMMARY BAR ─── */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 font-sans">
        <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 flex items-center justify-between">
          <div>
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">SAFE</span>
            <span className="text-3xl font-black text-emerald-400 font-mono mt-1 block">
              {safeWorkers.length}
            </span>
          </div>
          <span className="text-xs px-2.5 py-1 rounded font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/30">
            NOMINAL
          </span>
        </div>

        <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 flex items-center justify-between">
          <div>
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">WARNING</span>
            <span className="text-3xl font-black text-amber-400 font-mono mt-1 block">
              {warnWorkers.length}
            </span>
          </div>
          <span className="text-xs px-2.5 py-1 rounded font-bold bg-amber-500/10 text-amber-400 border border-amber-500/30">
            ATTENTION
          </span>
        </div>

        <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 flex items-center justify-between">
          <div>
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">CRITICAL</span>
            <span className={`text-3xl font-black font-mono mt-1 block ${critWorkers.length > 0 ? "text-red-500" : "text-emerald-400"}`}>
              {critWorkers.length}
            </span>
          </div>
          <span className={`text-xs px-2.5 py-1 rounded font-bold border ${critWorkers.length > 0 ? "bg-red-500/10 text-red-400 border-red-500/30" : "bg-emerald-500/10 text-emerald-400 border-emerald-500/30"}`}>
            {critWorkers.length > 0 ? "ALERT" : "CLEAR"}
          </span>
        </div>

        <div className="bg-slate-900 p-4 rounded-xl border border-slate-800 flex items-center justify-between">
          <div>
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider block">ACTIVE INCIDENTS</span>
            <span className={`text-3xl font-black font-mono mt-1 block ${activeIncidents.length > 0 ? "text-red-500" : "text-emerald-400"}`}>
              {activeIncidents.length}
            </span>
          </div>
          {activeIncidents.length > 0 && (
            <button
              onClick={clearAllEmergencies}
              className="text-[11px] px-2.5 py-1 rounded font-bold bg-emerald-600 hover:bg-emerald-500 text-white transition-colors"
            >
              CLEAR ALL
            </button>
          )}
        </div>
      </div>

      {/* ─── FLOW A: INCOMING WORKER INCIDENTS ─── */}
      <div className="bg-slate-900 p-5 rounded-xl border border-slate-800 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div>
            <span className="text-[10px] text-red-400 font-bold uppercase tracking-widest block font-mono">
              FLOW A: WORKER → CONTROL ROOM
            </span>
            <h2 className="text-lg font-bold text-white tracking-tight">
              INCOMING WORKER INCIDENTS ({activeIncidents.length})
            </h2>
          </div>
          <button
            onClick={() => triggerHazardEvent("W001", "FALL")}
            className="text-xs font-bold px-3 py-1.5 rounded bg-red-600 hover:bg-red-500 text-white transition-colors shadow"
          >
            TEST: TRIGGER W001 FALL
          </button>
        </div>

        {activeIncidents.length === 0 ? (
          <div className="p-6 text-center text-xs text-slate-400 bg-slate-950 rounded-lg border border-slate-800 font-sans">
            No incoming worker hazards detected. All subterranean worker sensors reporting nominal telemetry.
          </div>
        ) : (
          <div className="space-y-3">
            {activeIncidents.map((inc) => (
              <div
                key={inc.id}
                className="p-4 rounded-xl bg-slate-950 border-2 border-red-500/80 flex flex-col md:flex-row md:items-center justify-between gap-4 font-sans shadow-lg"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-black text-white text-sm">{inc.workerId} — {inc.workerName}</span>
                    <span className="px-2 py-0.5 rounded bg-red-600 text-white font-bold text-[10px]">
                      {inc.type}
                    </span>
                    <span className="text-xs text-slate-400 font-mono">
                      {new Date(inc.timestamp).toLocaleTimeString()}
                    </span>
                  </div>

                  <div className="text-xs text-red-300 font-semibold">
                    Location: <span className="font-mono text-slate-200">{inc.location}</span>
                  </div>

                  <div className="flex flex-wrap gap-4 text-xs text-slate-300 pt-1 font-mono">
                    <span>HR: <strong className="text-red-400">{inc.sensorValues.heartRate} BPM</strong></span>
                    <span>TEMP: <strong className="text-red-400">{inc.sensorValues.temperature}°C</strong></span>
                    <span>GAS: <strong className="text-amber-400">{inc.sensorValues.gasLevel} PPM</strong></span>
                    <span>COMMUNICATION: <strong className="text-blue-400">EMERGENCY PACKET RECEIVED</strong></span>
                  </div>
                </div>

                <div className="flex items-center gap-2 text-xs">
                  {inc.acknowledgementStatus === "UNACKNOWLEDGED" && (
                    <button
                      onClick={() => acknowledgeIncident(inc.id)}
                      className="px-3 py-2 rounded bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold transition-colors"
                    >
                      ACKNOWLEDGE
                    </button>
                  )}
                  <button
                    onClick={() => setSelectedWorkerId(inc.workerId)}
                    className="px-3 py-2 rounded bg-slate-800 hover:bg-slate-700 text-blue-400 font-bold border border-slate-700 transition-colors"
                  >
                    LOCATE WORKER
                  </button>
                  <button
                    onClick={() => resolveIncident(inc.id)}
                    className="px-3 py-2 rounded bg-emerald-600 hover:bg-emerald-500 text-white font-bold transition-colors"
                  >
                    DISPATCH RESPONSE
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* ─── FLOW B: CONTROL ROOM EMERGENCY COMMANDS ─── */}
      <div className="bg-slate-900 p-5 rounded-xl border border-slate-800 space-y-4 font-sans">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div>
            <span className="text-[10px] text-blue-400 font-bold uppercase tracking-widest block font-mono">
              FLOW B: CONTROL ROOM → WORKERS (REVERSE BROADCAST)
            </span>
            <h2 className="text-lg font-bold text-white tracking-tight">
              CONTROL ROOM EMERGENCY BROADCAST PANEL
            </h2>
          </div>
          {controlRoomBroadcasts.length > 0 && (
            <button
              onClick={clearControlRoomBroadcasts}
              className="text-xs font-bold px-3 py-1 rounded bg-slate-800 text-slate-300 hover:bg-slate-700 border border-slate-700 font-mono"
            >
              CLEAR LOG
            </button>
          )}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
          {/* Controls Form */}
          <div className="lg:col-span-8 space-y-4 bg-slate-950 p-4 rounded-xl border border-slate-800">
            {/* Event Type Selection */}
            <div>
              <label className="text-xs text-slate-400 font-bold uppercase tracking-wider block mb-2">
                EVENT TYPE
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 font-mono">
                {COMMAND_PRESETS.map((cmd) => (
                  <button
                    key={cmd}
                    onClick={() => {
                      setSelectedCommand(cmd);
                      if (cmd === "TUNNEL COLLAPSE") {
                        setSelectedTargetZone("Zone B – East Tunnel");
                        setCustomMessage("TUNNEL COLLAPSE DETECTED IN ZONE B. EVACUATE TO SAFE ROUTE IMMEDIATELY.");
                      }
                    }}
                    className={`p-2.5 rounded-lg border text-xs font-bold text-left transition-all ${
                      selectedCommand === cmd
                        ? "bg-blue-600 text-white border-blue-400 shadow-md"
                        : "bg-slate-900 text-slate-300 border-slate-800 hover:border-slate-700"
                    }`}
                  >
                    [ {cmd} ]
                  </button>
                ))}
              </div>
            </div>

            {/* Target Zone & Recipients */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="text-xs text-slate-400 font-bold uppercase tracking-wider block mb-1.5">
                  ZONE
                </label>
                <select
                  value={selectedTargetZone}
                  onChange={(e) => {
                    const z = e.target.value;
                    setSelectedTargetZone(z);
                    if (z !== "ALL ZONES") {
                      const prefix = z.split("–")[0].trim();
                      const zoneWorkerIds = workers.filter((w) => w.zone.startsWith(prefix)).map((w) => w.id);
                      setSelectedRecipients(zoneWorkerIds);
                    } else {
                      setSelectedRecipients(workers.map((w) => w.id));
                    }
                  }}
                  className="w-full bg-slate-900 border border-slate-800 text-white font-bold text-xs rounded-lg p-2.5 focus:outline-none focus:border-blue-500 cursor-pointer font-mono"
                >
                  {ZONES.map((z) => (
                    <option key={z} value={z}>
                      [ {z} ]
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs text-slate-400 font-bold uppercase tracking-wider block">
                    RECIPIENTS ({selectedRecipients.length})
                  </label>
                  <button
                    type="button"
                    onClick={() => {
                      if (selectedTargetZone !== "ALL ZONES") {
                        const prefix = selectedTargetZone.split("–")[0].trim();
                        const zoneWorkerIds = workers.filter((w) => w.zone.startsWith(prefix)).map((w) => w.id);
                        setSelectedRecipients(zoneWorkerIds);
                      } else {
                        setSelectedRecipients(workers.map((w) => w.id));
                      }
                    }}
                    className="text-[10px] text-blue-400 font-bold hover:underline font-mono"
                  >
                    [ SELECT ALL WORKERS IN ZONE ]
                  </button>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-3 gap-1.5 max-h-[110px] overflow-y-auto bg-slate-900 p-2.5 rounded-lg border border-slate-800 text-xs font-mono">
                  {workers.map((w) => {
                    const isChecked = selectedRecipients.includes(w.id);
                    return (
                      <label key={w.id} className="flex items-center gap-1.5 text-slate-200 cursor-pointer hover:text-white">
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={() => {
                            if (isChecked) {
                              setSelectedRecipients(selectedRecipients.filter((id) => id !== w.id));
                            } else {
                              setSelectedRecipients([...selectedRecipients, w.id]);
                            }
                          }}
                          className="accent-blue-500 rounded cursor-pointer"
                        />
                        <span className="font-bold">{w.id}</span>
                      </label>
                    );
                  })}
                </div>
              </div>
            </div>

            {/* Custom Evacuation Message */}
            <div>
              <label className="text-xs text-slate-400 font-bold uppercase tracking-wider block mb-1.5">
                BROADCAST MESSAGE INSTRUCTION
              </label>
              <textarea
                rows={2}
                value={customMessage}
                onChange={(e) => setCustomMessage(e.target.value)}
                className="w-full bg-slate-900 border border-slate-800 text-white font-mono text-xs rounded-lg p-2.5 focus:outline-none focus:border-blue-500"
              />
            </div>

            <button
              onClick={handleBroadcast}
              className="w-full py-3 rounded-xl bg-blue-600 hover:bg-blue-500 text-white font-bold text-xs tracking-wider transition-colors shadow-lg font-mono"
            >
              BROADCAST EMERGENCY
            </button>

            {/* Reverse Flow Animation Indicator */}
            {txAnimPhase && (
              <div className="p-3 rounded-xl bg-blue-950 border border-blue-500 text-blue-300 text-xs font-mono font-bold space-y-1 text-center shadow-lg animate-pulse">
                <div className="text-cyan-300 tracking-wider">
                  CONTROL ROOM → GATEWAY → REPEATER 3 → REPEATER 2 → REPEATER 1 → TARGET HELMETS
                </div>
                <div className="text-white text-xs">
                  {txAnimPhase === "TRANSMITTING" ? "📡 EMERGENCY BROADCAST TRANSMITTING..." : "✔ BROADCAST RECEIVED BY WORKER HELMETS"}
                </div>
              </div>
            )}
          </div>

          {/* Broadcast Log */}
          <div className="lg:col-span-4 bg-slate-950 p-4 rounded-xl border border-slate-800 flex flex-col justify-between">
            <div>
              <span className="text-xs text-slate-400 font-bold uppercase tracking-wider block mb-2 font-mono">
                ACTIVE COMMAND BROADCAST LOG ({controlRoomBroadcasts.length})
              </span>

              {controlRoomBroadcasts.length === 0 ? (
                <div className="text-xs text-slate-500 py-6 text-center font-sans">
                  No emergency broadcasts active. Select event type and recipients above to dispatch evacuation directives.
                </div>
              ) : (
                <div className="space-y-2 max-h-[220px] overflow-y-auto pr-1">
                  {controlRoomBroadcasts.map((bc) => (
                    <div key={bc.broadcastId} className="p-2.5 rounded bg-slate-900 border border-blue-500/40 text-xs space-y-1 font-mono">
                      <div className="flex justify-between font-bold text-blue-400">
                        <span>{bc.type}</span>
                        <span className="text-[10px] text-slate-400">{new Date(bc.timestamp).toLocaleTimeString()}</span>
                      </div>
                      <div className="text-slate-300 text-[11px]">
                        Zone: {bc.zone} | Targets: {bc.recipientWorkerIds.join(", ")}
                      </div>
                      <div className="text-slate-400 text-[10px] line-clamp-1 italic">
                        "{bc.message}"
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="text-[11px] text-slate-400 pt-2 border-t border-slate-800 font-mono">
              Subterranean LoRa Mesh Gateway · Reverse Command Channel Active
            </div>
          </div>
        </div>
      </div>

      {/* ─── WORKER OPERATIONS (ALL 12 WORKERS SIMULTANEOUSLY) ─── */}
      <div className="bg-slate-900 p-5 rounded-xl border border-slate-800 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div>
            <h2 className="text-lg font-bold text-white tracking-tight">
              WORKER OPERATIONS MONITORING GRID (12 WORKERS)
            </h2>
            <p className="text-xs text-slate-400">
              Simultaneous 12-smart-helmet telemetry tracking. Click any card to open worker diagnostic details.
            </p>
          </div>
          <span className="text-xs font-mono text-slate-400 bg-slate-950 px-3 py-1 rounded border border-slate-800">
            ALL 12 NODES ONLINE
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {workers.map((w) => {
            const isCrit = w.safetyStatus === "CRITICAL";
            const isWarn = w.safetyStatus === "WARNING";
            const isOff = w.safetyStatus === "OFFLINE";

            const activeEvacBc = (controlRoomBroadcasts || []).find(
              (bc) => bc.status === "ACTIVE" && (bc.recipientWorkerIds.includes("ALL") || bc.recipientWorkerIds.includes(w.id))
            );

            const isEvac = activeEvacBc && !isCrit;

            const cardBorder = isCrit
              ? "border-red-500 bg-red-950/30 shadow-[0_0_15px_rgba(239,68,68,0.2)]"
              : isEvac
              ? "border-amber-500 bg-amber-950/30 shadow-[0_0_15px_rgba(245,158,11,0.2)]"
              : isWarn
              ? "border-amber-500 bg-amber-950/20"
              : isOff
              ? "border-slate-800 bg-slate-950 opacity-60"
              : "border-slate-800 bg-slate-950 hover:border-slate-700";

            const badgeStyle = isCrit
              ? "bg-red-500/20 text-red-400 border-red-500/50 font-black animate-pulse"
              : isEvac
              ? "bg-amber-500/20 text-amber-300 border-amber-500/50 font-bold"
              : isWarn
              ? "bg-amber-500/20 text-amber-400 border-amber-500/50 font-bold"
              : isOff
              ? "bg-slate-800 text-slate-400 border-slate-700"
              : "bg-emerald-500/20 text-emerald-400 border-emerald-500/50 font-bold";

            const statusText = isCrit
              ? `CRITICAL — ${
                  w.fallDetected
                    ? "FALL"
                    : w.fireDetected
                    ? "FIRE"
                    : w.gasLevel >= 180
                    ? "GAS SURGE"
                    : w.temperature >= 38.5
                    ? "HIGH TEMP"
                    : w.heartRate > 125 || w.heartRate < 45
                    ? "TACHYCARDIA"
                    : "ALERT"
                }`
              : isEvac
              ? "EVACUATION REQUIRED"
              : w.safetyStatus;

            return (
              <div
                key={w.id}
                onClick={() => setSelectedWorkerId(w.id)}
                className={`p-4 rounded-xl border transition-all cursor-pointer space-y-2.5 font-sans ${cardBorder}`}
              >
                {/* Header */}
                <div className="flex items-start justify-between border-b border-slate-800/80 pb-2">
                  <div>
                    <div className="font-mono text-xs font-bold text-blue-400">{w.id}</div>
                    <div className="font-bold text-white text-sm">{w.name}</div>
                  </div>
                  <span className={`text-[10px] px-2 py-0.5 rounded border ${badgeStyle}`}>
                    {statusText}
                  </span>
                </div>

                {/* Hazard Badges */}
                {(w.fallDetected || w.fireDetected || w.gasLevel >= 80 || w.heartRate > 100 || w.heartRate < 45 || w.temperature >= 37.8) && (
                  <div className="flex items-center gap-1 flex-wrap font-mono text-[9px]">
                    {w.fallDetected && (
                      <span className="px-1.5 py-0.5 rounded bg-red-500/20 text-red-400 border border-red-500/40 font-bold animate-pulse">
                        🤸 FALL
                      </span>
                    )}
                    {w.fireDetected && (
                      <span className="px-1.5 py-0.5 rounded bg-orange-500/20 text-orange-400 border border-orange-500/40 font-bold animate-pulse">
                        🔥 FIRE
                      </span>
                    )}
                    {w.gasLevel >= 180 && (
                      <span className="px-1.5 py-0.5 rounded bg-yellow-500/20 text-yellow-400 border border-yellow-500/40 font-bold animate-pulse">
                        ☁️ GAS ({w.gasLevel} PPM)
                      </span>
                    )}
                    {(w.heartRate > 125 || w.heartRate < 45) && (
                      <span className="px-1.5 py-0.5 rounded bg-red-500/20 text-red-400 border border-red-500/40 font-bold animate-pulse">
                        ❤️ HIGH HR ({w.heartRate})
                      </span>
                    )}
                    {w.temperature >= 38.5 && (
                      <span className="px-1.5 py-0.5 rounded bg-red-500/20 text-red-400 border border-red-500/40 font-bold animate-pulse">
                        🌡️ HIGH TEMP ({w.temperature}°C)
                      </span>
                    )}
                  </div>
                )}

                {/* Location */}
                <div className="text-xs text-slate-300 space-y-0.5">
                  <div className="font-semibold">{w.zone}</div>
                  <div className="text-slate-400 text-[11px] font-mono">{w.depthMeters}m UNDERGROUND</div>
                </div>

                {/* Telemetry Metrics */}
                <div className="grid grid-cols-2 gap-2 text-xs font-mono pt-1">
                  <div className="bg-slate-900 p-2 rounded border border-slate-800">
                    <span className="text-[9px] text-slate-400 block uppercase font-sans">HR</span>
                    <span className={`font-bold ${w.heartRate > 125 ? "text-red-400" : "text-slate-100"}`}>
                      {w.heartRate} <span className="text-[9px] font-normal text-slate-400">BPM</span>
                    </span>
                  </div>

                  <div className="bg-slate-900 p-2 rounded border border-slate-800">
                    <span className="text-[9px] text-slate-400 block uppercase font-sans">TEMP</span>
                    <span className={`font-bold ${w.temperature >= 38.5 ? "text-red-400" : "text-slate-100"}`}>
                      {w.temperature} <span className="text-[9px] font-normal text-slate-400">°C</span>
                    </span>
                  </div>

                  <div className="bg-slate-900 p-2 rounded border border-slate-800">
                    <span className="text-[9px] text-slate-400 block uppercase font-sans">GAS</span>
                    <span className={`font-bold ${w.gasLevel >= 80 ? "text-amber-400" : "text-slate-100"}`}>
                      {w.gasLevel} <span className="text-[9px] font-normal text-slate-400">PPM</span>
                    </span>
                  </div>

                  <div className="bg-slate-900 p-2 rounded border border-slate-800">
                    <span className="text-[9px] text-slate-400 block uppercase font-sans">BATTERY</span>
                    <span className="font-bold text-emerald-400">{w.battery}%</span>
                  </div>
                </div>

                {/* LoRa Status Footer */}
                <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
                  <span>LoRa: <strong className={w.communicationStatus === "OFFLINE" ? "text-slate-500" : "text-blue-400"}>{w.communicationStatus === "OFFLINE" ? "OFFLINE" : "CONNECTED"}</strong></span>
                  <span className="text-blue-400 font-bold hover:underline">DETAILS →</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Hardware Diagnostic Modal rendered at root in App.jsx */}
    </div>
  );
}

