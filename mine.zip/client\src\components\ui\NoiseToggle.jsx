// client/src/components/ui/NoiseToggle.jsx
// Toggle that emits socket event and controls visor visual feedback

import React from "react";
import { motion } from "framer-motion";

export default function NoiseToggle({ active, onToggle }) {
  return (
    <div className="flex items-center gap-3">
      <span className="text-xs font-mono text-white/40 uppercase tracking-widest">
        Noise Cancel
      </span>
      <motion.button
        onClick={onToggle}
        className="relative w-12 h-6 rounded-full border transition-colors"
        style={{
          background:   active ? "rgba(0,212,255,0.15)" : "rgba(255,255,255,0.05)",
          borderColor:  active ? "#00d4ff" : "rgba(255,255,255,0.15)",
          boxShadow:    active ? "0 0 8px rgba(0,212,255,0.3)" : "none",
        }}
        whileTap={{ scale: 0.95 }}
      >
        <motion.div
          className="absolute top-0.5 w-5 h-5 rounded-full"
          style={{ background: active ? "#00d4ff" : "#555" }}
          animate={{ left: active ? "calc(100% - 22px)" : "2px" }}
          transition={{ type: "spring", stiffness: 400, damping: 25 }}
        />
      </motion.button>
      <span
        className="text-xs font-mono font-semibold transition-colors"
        style={{ color: active ? "#00d4ff" : "#555" }}
      >
        {active ? "ON" : "OFF"}
      </span>
    </div>
  );
}
