// client/src/sections/HeroSection.jsx
// Full-viewport hero with 3D helmet + scroll-driven story panels connected to MinoMineContext

import React, { useState, useEffect, Suspense } from "react";
import { motion, AnimatePresence } from "framer-motion";
import HelmetScene from "../components/three/HelmetScene";
import DataPanel from "../components/ui/DataPanel";
import NoiseToggle from "../components/ui/NoiseToggle";
import { useMinoMine } from "../context/MinoMineContext";

const STORY_PANELS = [
  {
    id: "detect",
    trigger: 0.15,
    label: "01 / DETECT",
    title: "12-Sensor Edge Fusion",
    body: "PPG pulse oximeter (MAX30102), 6-axis IMU (MPU6050 fall detection), electrochemical MQ gas detector, flame IR sensor, temperature probe, and LDR light sensor monitor worker safety continuously at the edge.",
    icon: "◎",
    color: "#ff6b00",
  },
  {
    id: "connect",
    trigger: 0.45,
    label: "02 / CONNECT",
    title: "Subterranean LoRa Telemetry",
    body: "ESP32 SoC coordinates long-range LoRa SX1276 radio transmission, penetrating up to 5 km of dense underground rock to reach surface control room dashboards within 200 milliseconds.",
    icon: "⟁",
    color: "#00d4ff",
  },
  {
    id: "protect",
    trigger: 0.72,
    label: "03 / PROTECT",
    title: "Automated Incident Alerts",
    body: "Man-down fall detection, hazardous gas surges, flame detection, and vitals anomalies automatically trigger haptic vibration motor feedback in the helmet and broadcast immediate rescue incidents.",
    icon: "◈",
    color: "#ffd700",
  },
];

function StoryCard({ panel, visible }) {
  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          key={panel.id}
          initial={{ opacity: 0, x: -40 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -30 }}
          transition={{ duration: 0.5, ease: "easeOut" }}
          className="glass rounded-2xl p-6 max-w-xs"
          style={{ borderColor: `${panel.color}33` }}
        >
          <div
            className="text-3xl font-display font-black mb-3"
            style={{ color: panel.color, textShadow: `0 0 12px ${panel.color}55` }}
          >
            {panel.icon}
          </div>
          <p
            className="text-[10px] font-mono uppercase tracking-widest mb-2"
            style={{ color: panel.color }}
          >
            {panel.label}
          </p>
          <h3 className="font-display font-bold text-white text-xl mb-2 leading-tight">
            {panel.title}
          </h3>
          <p className="text-white/50 text-xs leading-relaxed font-body">{panel.body}</p>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

export default function HeroSection({ onScrollToDashboard }) {
  const { activeEmergency, communicationState, updateWorkerSensor, workers } = useMinoMine();

  const [scrollProgress, setScrollProgress] = useState(0);
  const [clickedComponent, setClickedComponent] = useState(null);
  const [noiseCancel, setNoiseCancel] = useState(true);
  const [visiblePanel, setVisiblePanel] = useState(null);

  useEffect(() => {
    const hero = document.getElementById("hero-section");
    const onScroll = () => {
      if (!hero) return;
      const rect = hero.getBoundingClientRect();
      const total = hero.offsetHeight - window.innerHeight;
      const prog = Math.max(0, Math.min(1, -rect.top / total));
      setScrollProgress(prog);

      let current = null;
      for (const p of STORY_PANELS) {
        if (prog >= p.trigger) current = p.id;
      }
      setVisiblePanel(current);
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const handleNoiseToggle = () => {
    const next = !noiseCancel;
    setNoiseCancel(next);
    workers.forEach((w) => updateWorkerSensor(w.id, "noiseCancel", next));
  };

  const handleComponentClick = (id) => {
    setClickedComponent((prev) => (prev === id ? null : id));
  };

  return (
    <section id="hero-section" className="relative" style={{ height: "280vh" }}>
      {/* Sticky Viewport */}
      <div className="sticky top-0 h-screen overflow-hidden flex flex-col">
        {/* Background Grid */}
        <div
          className="absolute inset-0 bg-grid-dark bg-grid-32 opacity-100"
          style={{ backgroundSize: "32px 32px" }}
        />

        <div
          className="absolute inset-0"
          style={{
            background:
              "radial-gradient(ellipse 70% 70% at 50% 50%, transparent 30%, #0a0a0f 100%)",
          }}
        />

        {/* Scan line effect */}
        <div
          className="absolute left-0 right-0 h-px opacity-10 pointer-events-none"
          style={{
            background: "linear-gradient(90deg, transparent, #ff6b00, transparent)",
            animation: "scan-line 4s linear infinite",
          }}
        />

        {/* Corner Badges */}
        <div className="absolute top-20 left-8 z-10">
          <p className="text-[10px] font-mono text-mine-neon uppercase tracking-widest font-bold">
            SIH 2026 · PS ID: SIH26039
          </p>
          <p className="text-[10px] font-mono text-white/30 mt-1">
            ESP32 + 12 Hardware Sensors Concept
          </p>
        </div>
        <div className="absolute top-20 right-8 z-10 text-right">
          <p className="text-[10px] font-mono text-mine-neon/50 uppercase tracking-widest">
            System Revision v3.4.0
          </p>
          <p className="text-[10px] font-mono text-white/30 mt-1">
            {communicationState.socketConnected
              ? "● LoRa Mesh Gateway Connected"
              : "○ Simulation Standalone Mode"}
          </p>
        </div>

        {/* Main Headline */}
        <div className="absolute top-24 left-1/2 -translate-x-1/2 text-center z-10 pointer-events-none">
          <motion.p
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="text-[11px] font-mono uppercase tracking-[0.4em] text-mine-neon mb-2 font-bold"
          >
            Smart Mining Safety & Worker Protection
          </motion.p>
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.5 }}
            className="font-display font-black text-white leading-none"
            style={{ fontSize: "clamp(2.5rem, 6vw, 4.5rem)" }}
          >
            MINO MINE
            <br />
            <span className="neon-text" style={{ color: "#ff6b00" }}>
              SMART HELMET
            </span>
          </motion.h1>
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.8 }}
            className="text-white/40 text-xs mt-3 font-body max-w-md mx-auto"
          >
            PPG Oximeter · MPU6050 Fall Detection · MQ Gas Array · Flame Sensor · LoRa Telemetry
          </motion.p>
        </div>

        {/* 3D Helmet WebGL Canvas */}
        <div className="relative w-full h-full pt-16">
          <Suspense
            fallback={
              <div className="flex items-center justify-center h-full">
                <div className="text-mine-neon font-mono text-sm animate-pulse">
                  Initializing 12-Hardware Component 3D Model…
                </div>
              </div>
            }
          >
            <HelmetScene
              onComponentClick={handleComponentClick}
              activeEmergency={activeEmergency}
              noiseCancel={noiseCancel}
            />
          </Suspense>

          {/* Component Tech Info Slide-in */}
          <DataPanel
            componentId={clickedComponent}
            onClose={() => setClickedComponent(null)}
          />

          {/* Story Cards */}
          <div className="absolute left-8 bottom-24 z-10 flex flex-col gap-4">
            {STORY_PANELS.map((panel) => (
              <StoryCard
                key={panel.id}
                panel={panel}
                visible={visiblePanel === panel.id}
              />
            ))}
          </div>

          {/* Controls bottom-right */}
          <div className="absolute right-8 bottom-24 z-10 flex flex-col items-end gap-4">
            <NoiseToggle active={noiseCancel} onToggle={handleNoiseToggle} />
            <div className="text-[9px] font-mono text-white/30 text-right">
              DRAG TO ROTATE · SCROLL TO DISASSEMBLE
            </div>
          </div>

          {/* Scroll Cue */}
          <motion.div
            animate={{ y: [0, 8, 0] }}
            transition={{ repeat: Infinity, duration: 1.8, ease: "easeInOut" }}
            className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10 flex flex-col items-center gap-2 cursor-pointer"
            onClick={scrollProgress > 0.85 ? onScrollToDashboard : undefined}
          >
            <span className="text-[9px] font-mono text-white/30 uppercase tracking-widest font-bold">
              {scrollProgress > 0.85 ? "Enter Control Room" : "Scroll to Disassemble Helmet"}
            </span>
            <div className="w-5 h-8 border border-white/20 rounded-full flex items-start justify-center pt-1.5">
              <div className="w-1 h-2 bg-mine-neon rounded-full" />
            </div>
          </motion.div>

          {/* Progress bar */}
          <div className="absolute bottom-0 left-0 right-0 h-px bg-white/5">
            <motion.div
              className="h-full bg-mine-neon"
              style={{ width: `${scrollProgress * 100}%` }}
              transition={{ duration: 0.1 }}
            />
          </div>
        </div>
      </div>
    </section>
  );
}
