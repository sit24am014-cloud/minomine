// client/src/context/MinoMineContext.jsx
// Centralized State Management & Multi-Device Real-Time Sync Engine for MINO MINE

import React, { createContext, useContext, useState, useEffect, useCallback, useRef } from "react";
import { INITIAL_WORKERS } from "../services/sensorSimulation";
import { evaluateSafetyStatus, checkWorkerIncident } from "../services/alertEngine";
import useSocket from "../hooks/useSocket";

const SOCKET_URL = import.meta.env.VITE_SOCKET_URL || `http://${window.location.hostname}:3001`;

const MinoMineContext = createContext(null);

export function MinoMineProvider({ children }) {
  const { workers: socketWorkers, alerts: socketAlerts, isConnected: socketConnected, socket } = useSocket(SOCKET_URL);

  const [workers, setWorkers] = useState(INITIAL_WORKERS);
  const [incidents, setIncidents] = useState([]);
  const [selectedWorkerId, setSelectedWorkerId] = useState(null); // Default null (no modal open)
  const [filterZone, setFilterZone] = useState("ALL");
  const [filterStatus, setFilterStatus] = useState("ALL");
  const [noiseCancelGlobal, setNoiseCancelGlobal] = useState(true);
  const [isSimulationPaused, setIsSimulationPaused] = useState(false);
  const [isDemoActive, setIsDemoActive] = useState(false);
  const [activeCallWorkerId, setActiveCallWorkerId] = useState(null);
  const [evacuatedZones, setEvacuatedZones] = useState([]);
  const [deviceMode, setDeviceMode] = useState("CONTROL ROOM"); // "CONTROL ROOM" | "WORKER PHONE" | "SIMULATOR"

  const demoIntervalRef = useRef(null);
  const broadcastChannelRef = useRef(null);

  // Initialize BroadcastChannel for cross-tab local sync
  useEffect(() => {
    if (typeof window !== "undefined" && "BroadcastChannel" in window) {
      const channel = new BroadcastChannel("minomine_sync_channel");
      broadcastChannelRef.current = channel;

      channel.onmessage = (event) => {
        const { type, payload } = event.data || {};
        if (type === "STATE_OVERRIDE") {
          if (payload.workers) setWorkers(payload.workers);
          if (payload.incidents) setIncidents(payload.incidents);
        } else if (type === "TRIGGER_HAZARD") {
          applyHazardToWorker(payload.workerId, payload.emergencyType, false);
        } else if (type === "UPDATE_SENSOR") {
          applySensorUpdate(payload.workerId, payload.sensorKey, payload.value, false);
        }
      };

      return () => channel.close();
    }
  }, []);

  // Listen for multi-device Socket.io sync events
  useEffect(() => {
    if (!socket) return;

    socket.on("initial_broadcasts", (broadcasts) => {
      if (Array.isArray(broadcasts)) {
        setControlRoomBroadcasts(broadcasts);
      }
    });

    socket.on("worker_sensor_synced", ({ workerId, sensorKey, value }) => {
      applySensorUpdate(workerId, sensorKey, value, false);
    });

    socket.on("hazard_event_synced", ({ workerId, emergencyType }) => {
      applyHazardToWorker(workerId, emergencyType, false);
    });

    socket.on("incident_resolved_synced", ({ incidentId }) => {
      resolveIncidentInternal(incidentId, false);
    });

    socket.on("control_room_broadcast_synced", (data) => {
      if (data && data.broadcastId) {
        setControlRoomBroadcasts((prev) => {
          const exists = prev.some((bc) => bc.broadcastId === data.broadcastId);
          if (exists) return prev;
          return [data, ...prev];
        });
        if (data.zone && data.zone !== "ALL ZONES") {
          setEvacuatedZones((prev) => (prev.includes(data.zone) ? prev : [...prev, data.zone]));
        } else {
          setEvacuatedZones(["Zone A", "Zone B", "Zone C", "Zone D"]);
        }
      }
    });

    socket.on("broadcast_acknowledged_synced", ({ broadcastId, workerId }) => {
      if (broadcastId && workerId) {
        setControlRoomBroadcasts((prev) =>
          prev.map((bc) => {
            if (bc.broadcastId === broadcastId) {
              const acked = (bc.acknowledgedWorkerIds || []).includes(workerId)
                ? bc.acknowledgedWorkerIds
                : [...(bc.acknowledgedWorkerIds || []), workerId];
              return { ...bc, acknowledgedWorkerIds: acked };
            }
            return bc;
          })
        );
      }
    });
  }, [socket]);

  // Sync continuous telemetry from server
  useEffect(() => {
    if (isSimulationPaused || !socketWorkers || socketWorkers.length === 0) return;

    setWorkers((prevWorkers) => {
      return prevWorkers.map((w) => {
        const incoming = socketWorkers.find((sw) => sw.id === w.id);
        if (!incoming) return w;

        if (w.fallDetected || w.fireDetected || w.gasLevel >= 180 || w.heartRate > 130 || w.temperature >= 38.5) {
          return w;
        }

        const updated = {
          ...w,
          heartRate: incoming.heartRate ?? w.heartRate,
          temperature: parseFloat(incoming.temperature) || w.temperature,
          systolicBP: incoming.systolicBP || incoming.systolic || w.systolicBP,
          diastolicBP: incoming.diastolicBP || incoming.diastolic || w.diastolicBP,
          respiration: incoming.respiration || w.respiration,
          gasLevel: incoming.gasLevel ?? w.gasLevel,
          battery: incoming.battery ?? w.battery,
          spO2: incoming.o2 ? parseFloat(incoming.o2) : w.spO2,
          noiseDb: incoming.noiseDb ?? w.noiseDb,
          noiseCancel: incoming.noiseCancel ?? w.noiseCancel,
          hrHistory: incoming.hrHistory || w.hrHistory,
          lastUpdated: Date.now(),
        };

        updated.safetyStatus = evaluateSafetyStatus(updated);
        return updated;
      });
    });
  }, [socketWorkers, isSimulationPaused]);

  // Core internal sensor update function
  const applySensorUpdate = (workerId, sensorKey, value, shouldBroadcast = true) => {
    setWorkers((prevWorkers) => {
      let newlyTriggeredIncident = null;

      const nextWorkers = prevWorkers.map((w) => {
        if (w.id !== workerId) return w;

        const updated = { ...w, [sensorKey]: value, lastUpdated: Date.now() };

        if (sensorKey === "heartRate" && typeof value === "number") {
          updated.hrHistory = [...(w.hrHistory || []).slice(-29), value];
        }

        updated.safetyStatus = evaluateSafetyStatus(updated);

        const incident = checkWorkerIncident(updated);
        if (incident) newlyTriggeredIncident = incident;

        return updated;
      });

      if (newlyTriggeredIncident) {
        setIncidents((prevIncidents) => {
          const hasRecent = prevIncidents.some(
            (inc) =>
              inc.workerId === newlyTriggeredIncident.workerId &&
              inc.type === newlyTriggeredIncident.type &&
              inc.status === "ACTIVE"
          );
          if (hasRecent) return prevIncidents;
          return [newlyTriggeredIncident, ...prevIncidents];
        });
      }

      return nextWorkers;
    });

    if (shouldBroadcast) {
      if (socket) socket.emit("client_update_sensor", { workerId, sensorKey, value });
      if (broadcastChannelRef.current) {
        broadcastChannelRef.current.postMessage({ type: "UPDATE_SENSOR", payload: { workerId, sensorKey, value } });
      }
    }
  };

  // Core internal hazard trigger function
  const applyHazardToWorker = (workerId, emergencyType, shouldBroadcast = true) => {
    setWorkers((prevWorkers) => {
      let createdIncident = null;

      const nextWorkers = prevWorkers.map((w) => {
        if (w.id !== workerId) return w;

        const updated = { ...w, lastUpdated: Date.now() };

        switch (emergencyType) {
          case "FALL":
            updated.fallDetected = true;
            updated.heartRate = 96;
            updated.temperature = 36.6;
            updated.systolicBP = 120;
            updated.diastolicBP = 80;
            updated.respiration = 20;
            updated.safetyStatus = "CRITICAL";
            break;
          case "FIRE":
            updated.fireDetected = true;
            updated.temperature = 40.2;
            updated.heartRate = 108;
            updated.systolicBP = 120;
            updated.diastolicBP = 80;
            updated.safetyStatus = "CRITICAL";
            break;
          case "GAS_LEAK":
            updated.gasLevel = 265;
            updated.respiration = 24;
            updated.heartRate = 84;
            updated.temperature = 36.6;
            updated.systolicBP = 120;
            updated.diastolicBP = 80;
            updated.safetyStatus = "CRITICAL";
            break;
          case "MEDICAL":
            updated.spO2 = 84;
            updated.heartRate = 138;
            updated.systolicBP = 155;
            updated.diastolicBP = 98;
            updated.respiration = 28;
            updated.temperature = 36.6;
            updated.safetyStatus = "CRITICAL";
            break;
          case "MANUAL_EMERGENCY":
            updated.fallDetected = false;
            updated.heartRate = 125;
            updated.temperature = 36.6;
            updated.systolicBP = 122;
            updated.diastolicBP = 78;
            updated.safetyStatus = "CRITICAL";
            break;
          default:
            break;
        }

        const incident = checkWorkerIncident(updated);
        if (incident) createdIncident = incident;
        return updated;
      });

      if (createdIncident) {
        setIncidents((prev) => {
          const exists = prev.some(
            (inc) =>
              inc.workerId === createdIncident.workerId &&
              inc.type === createdIncident.type &&
              inc.status === "ACTIVE"
          );
          if (exists) return prev;
          return [createdIncident, ...prev];
        });
      }

      return nextWorkers;
    });

    if (shouldBroadcast) {
      if (socket) socket.emit("client_trigger_hazard", { workerId, emergencyType });
      if (broadcastChannelRef.current) {
        broadcastChannelRef.current.postMessage({ type: "TRIGGER_HAZARD", payload: { workerId, emergencyType } });
      }
    }
  };

  const updateWorkerSensor = useCallback((workerId, sensorKey, value) => {
    applySensorUpdate(workerId, sensorKey, value, true);
  }, [socket]);

  const triggerHazardEvent = useCallback((workerId, emergencyType) => {
    applyHazardToWorker(workerId, emergencyType, true);
  }, [socket]);

  const resetWorker = useCallback((workerId) => {
    setWorkers((prevWorkers) =>
      prevWorkers.map((w) => {
        if (w.id !== workerId) return w;
        const reset = {
          ...w,
          fallDetected: false,
          fireDetected: false,
          gasLevel: 14,
          temperature: 36.6,
          heartRate: 74,
          systolicBP: 118,
          diastolicBP: 76,
          respiration: 16,
          spO2: 98,
          battery: Math.max(w.battery, 85),
          communicationStatus: "ONLINE",
          lastUpdated: Date.now(),
        };
        reset.safetyStatus = evaluateSafetyStatus(reset);
        return reset;
      })
    );

    setIncidents((prev) =>
      prev.map((inc) =>
        inc.workerId === workerId && inc.status === "ACTIVE"
          ? { ...inc, status: "RESOLVED", acknowledgementStatus: "ACKNOWLEDGED" }
          : inc
      )
    );
  }, []);

  const clearAllEmergencies = useCallback(() => {
    setWorkers((prev) =>
      prev.map((w) => {
        if (w.id === "W010") {
          return {
            ...w,
            communicationStatus: "OFFLINE",
            safetyStatus: "OFFLINE",
            heartRate: 0,
            systolicBP: 0,
            diastolicBP: 0,
            respiration: 0,
            gasLevel: 0,
            battery: 12,
            lastUpdated: Date.now(),
          };
        }
        const reset = {
          ...w,
          fallDetected: false,
          fireDetected: false,
          gasLevel: 15,
          temperature: 36.6,
          heartRate: 75,
          systolicBP: 118,
          diastolicBP: 76,
          respiration: 16,
          spO2: 98,
          communicationStatus: "ONLINE",
          lastUpdated: Date.now(),
        };
        reset.safetyStatus = evaluateSafetyStatus(reset);
        return reset;
      })
    );
    setIncidents((prev) =>
      prev.map((inc) => ({ ...inc, status: "RESOLVED", acknowledgementStatus: "ACKNOWLEDGED" }))
    );
    setEvacuatedZones([]);
    setActiveCallWorkerId(null);
    if (socket) socket.emit("clear_emergency");
  }, [socket]);

  const resolveIncidentInternal = (incidentId, shouldBroadcast = true) => {
    setIncidents((prev) => {
      const inc = prev.find((i) => i.id === incidentId);
      if (inc) resetWorker(inc.workerId);
      return prev.map((i) => (i.id === incidentId ? { ...i, status: "RESOLVED" } : i));
    });

    if (shouldBroadcast && socket) {
      socket.emit("client_resolve_incident", { incidentId });
    }
  };

  const resolveIncident = useCallback((incidentId) => {
    resolveIncidentInternal(incidentId, true);
  }, [socket, resetWorker]);

  const dispatchResponse = useCallback((incidentId) => {
    setIncidents((prev) =>
      prev.map((inc) =>
        inc.id === incidentId
          ? { ...inc, responseDispatched: true, status: "ACKNOWLEDGED", acknowledgementStatus: "ACKNOWLEDGED" }
          : inc
      )
    );
  }, []);

  const callWorker = useCallback((workerId) => {
    setActiveCallWorkerId((prev) => (prev === workerId ? null : workerId));
  }, []);

  const evacuateArea = useCallback((zoneName) => {
    setEvacuatedZones((prev) => (prev.includes(zoneName) ? prev : [...prev, zoneName]));
  }, []);

  const [controlRoomBroadcasts, setControlRoomBroadcasts] = useState([]);

  const broadcastControlRoomCommand = useCallback(({ type, zone, recipientWorkerIds, message, severity = "HIGH" }) => {
    const newBroadcast = {
      broadcastId: `BC-${Date.now().toString().slice(-6)}`,
      type: type || "EVACUATE ZONE",
      zone: zone || "ALL ZONES",
      recipientWorkerIds: recipientWorkerIds && recipientWorkerIds.length > 0 ? recipientWorkerIds : ["ALL"],
      message: message || "ENVIRONMENTAL HAZARD DETECTED. EVACUATE TO SAFE ROUTE.",
      timestamp: Date.now(),
      severity,
      status: "ACTIVE",
      acknowledgedWorkerIds: [],
    };

    setControlRoomBroadcasts((prev) => [newBroadcast, ...prev]);

    if (zone && zone !== "ALL ZONES") {
      setEvacuatedZones((prev) => (prev.includes(zone) ? prev : [...prev, zone]));
    } else {
      setEvacuatedZones(["Zone A", "Zone B", "Zone C", "Zone D"]);
    }

    if (socket) {
      socket.emit("client_broadcast_command", newBroadcast);
    }
    if (broadcastChannelRef.current) {
      broadcastChannelRef.current.postMessage({ type: "CONTROL_ROOM_BROADCAST", payload: newBroadcast });
    }
  }, [socket]);

  const acknowledgeBroadcast = useCallback((broadcastId, workerId) => {
    setControlRoomBroadcasts((prev) =>
      prev.map((bc) => {
        if (bc.broadcastId === broadcastId) {
          const acked = (bc.acknowledgedWorkerIds || []).includes(workerId)
            ? bc.acknowledgedWorkerIds
            : [...(bc.acknowledgedWorkerIds || []), workerId];
          return { ...bc, acknowledgedWorkerIds: acked };
        }
        return bc;
      })
    );

    if (socket) {
      socket.emit("client_acknowledge_broadcast", { broadcastId, workerId });
    }
    if (broadcastChannelRef.current) {
      broadcastChannelRef.current.postMessage({ type: "ACKNOWLEDGE_BROADCAST", payload: { broadcastId, workerId } });
    }
  }, [socket]);

  const clearControlRoomBroadcasts = useCallback(() => {
    setControlRoomBroadcasts([]);
    setEvacuatedZones([]);
  }, []);

  const acknowledgeIncident = useCallback((incidentId) => {
    setIncidents((prev) =>
      prev.map((inc) =>
        inc.id === incidentId
          ? { ...inc, status: "ACKNOWLEDGED", acknowledgementStatus: "ACKNOWLEDGED" }
          : inc
      )
    );
  }, []);

  const startDemoMode = useCallback(() => {
    clearAllEmergencies();
    setIsDemoActive(true);

    if (demoIntervalRef.current) clearInterval(demoIntervalRef.current);

    let step = 0;
    demoIntervalRef.current = setInterval(() => {
      step++;
      if (step === 1) {
        updateWorkerSensor("W004", "gasLevel", 95);
      } else if (step === 2) {
        triggerHazardEvent("W004", "FALL");
      } else if (step === 3) {
        updateWorkerSensor("W006", "temperature", 38.8);
      } else if (step === 4) {
        triggerHazardEvent("W003", "FIRE");
      } else {
        clearInterval(demoIntervalRef.current);
        setIsDemoActive(false);
      }
    }, 4000);
  }, [clearAllEmergencies, triggerHazardEvent, updateWorkerSensor]);

  const toggleSimulationPause = useCallback(() => {
    setIsSimulationPaused((prev) => !prev);
  }, []);

  const activeEmergency = incidents.some((inc) => inc.status === "ACTIVE");
  const selectedWorker = selectedWorkerId ? workers.find((w) => w.id === selectedWorkerId) || null : null;

  const value = {
    workers,
    incidents,
    activeEmergency,
    selectedWorkerId,
    selectedWorker,
    setSelectedWorkerId,
    filterZone,
    setFilterZone,
    filterStatus,
    setFilterStatus,
    noiseCancelGlobal,
    setNoiseCancelGlobal,
    isSimulationPaused,
    isDemoActive,
    activeCallWorkerId,
    evacuatedZones,
    controlRoomBroadcasts,
    broadcastControlRoomCommand,
    acknowledgeBroadcast,
    clearControlRoomBroadcasts,
    deviceMode,
    setDeviceMode,
    toggleSimulationPause,
    startDemoMode,
    updateWorkerSensor,
    triggerHazardEvent,
    resetWorker,
    acknowledgeIncident,
    dispatchResponse,
    callWorker,
    evacuateArea,
    resolveIncident,
    clearAllEmergencies,
    communicationState: {
      connectedClients: 1,
      loraGatewayOnline: true,
      meshSignalDb: -68,
      lastPacketTimestamp: Date.now(),
      socketConnected,
    },
    socket,
  };

  return <MinoMineContext.Provider value={value}>{children}</MinoMineContext.Provider>;
}

export function useMinoMine() {
  const ctx = useContext(MinoMineContext);
  if (!ctx) {
    throw new Error("useMinoMine must be used within a MinoMineProvider");
  }
  return ctx;
}
