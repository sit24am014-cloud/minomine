// client/src/sections/DashboardSection.jsx
// Control Room & Real-Time Monitoring Dashboard — central hub consuming MinoMineContext

import React, { useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import WorkerCard from "../components/ui/WorkerCard";
import AlertBanner from "../components/ui/AlertBanner";
import EmergencyButton from "../components/ui/EmergencyButton";
import StatusIndicator from "../components/ui/StatusIndicator";
import SubterraneanZoneMap from "../components/ui/SubterraneanZoneMap";
import IncidentCenter from "../components/ui/IncidentCenter";
import HardwareDiagnosticModal from "../components/ui/HardwareDiagnosticModal";
import { useMinoMine } from "../context/MinoMineContext";

// Aggregate stats calculated from central worker state
function useAggregates(workers) {
  return useMemo(() => {
    if (!workers || !workers.length) return {};
    const hrs = workers.map((w) => w.heartRate).filter((hr) => hr > 0);
    const bats = workers.map((w) => w.battery);
    const critW = workers.filter((w) => w.safetyStatus === "CRITICAL");
    const warnW = workers.filter((w) => w.safetyStatus === "WARNING");
    const offW = workers.filter((w) => w.safetyStatus === "OFFLINE");

    return {
      avgHR: hrs.length ? Math.round(hrs.reduce((a, b) => a + b, 0) / hrs.length) : "--",
      minHR: hrs.length ? Math.min(...hrs) : "--",
      maxHR: hrs.length ? Math.max(...hrs) : "--",
      avgBattery: Math.round(bats.reduce((a, b) => a + b, 0) / bats.length),
      critCount: critW.length,
      warnCount: warnW.length,
      offCount: offW.length,
      safeCount: workers.length - critW.length - warnW.length - offW.length,
    };
  }, [workers]);
}

function StatCard({ label, value, unit, color = "#ff6b00", sub }) {
  return (
    <div className="glass rounded-xl px-4 py-3 flex flex-col gap-0.5 min-w-[110px]">
      <span className="text-[9px] font-mono text-white/30 uppercase tracking-widest">{label}</span>
      <span className="font-mono text-xl font-bold leading-none" style={{ color }}>
        {value}
        <span className="text-xs font-normal text-white/30 ml-1">{unit}</span>
      </span>
      {sub && <span className="text-[9px] font-mono text-white/20 mt-0.5">{sub}</span>}
    </div>
  );
}

function FilterPill({ label, active, onClick }) {
  return (
    <button
      onClick={onClick}
      className="text-[10px] font-mono px-3 py-1 rounded-full border transition-all"
      style={{
        borderColor: active ? "#ff6b00" : "rgba(255,255,255,0.1)",
        background: active ? "rgba(255,107,0,0.15)" : "transparent",
        color: active ? "#ff6b00" : "rgba(255,255,255,0.4)",
      }}
    >
      {label}
    </button>
  );
}

export default function DashboardSection() {
  const {
    workers,
    incidents,
    activeEmergency,
    communicationState,
    filterZone,
    setFilterZone,
    filterStatus,
    setFilterStatus,
    triggerHazardEvent,
    clearAllEmergencies,
  } = useMinoMine();

  const aggregates = useAggregates(workers);

  // Filtered & sorted workers list (Critical / Emergency first)
  const filteredWorkers = useMemo(() => {
    let list = [...workers];
    if (filterZone !== "ALL") {
      list = list.filter((w) => w.zone.startsWith(filterZone));
    }
    if (filterStatus !== "ALL") {
      list = list.filter((w) => w.safetyStatus === filterStatus);
    }
    const priority = { CRITICAL: 0, WARNING: 1, SAFE: 2, OFFLINE: 3 };
    return list.sort((a, b) => (priority[a.safetyStatus] ?? 4) - (priority[b.safetyStatus] ?? 4));
  }, [workers, filterZone, filterStatus]);

  const uniqueZones = useMemo(() => {
    const set = new Set(workers.map((w) => w.zone.split("–")[0].trim()));
    return ["ALL", ...Array.from(set)];
  }, [workers]);

  return (
    <section
      id="dashboard-section"
      className="relative min-h-screen py-24 px-6 lg:px-12"
      style={{
        background: "linear-gradient(180deg, #0a0a0f 0%, #0d0d18 40%, #0a0a0f 100%)",
      }}
    >
      {/* Top Divider */}
      <div
        className="absolute top-0 left-0 right-0 h-px"
        style={{
          background: "linear-gradient(90deg, transparent, rgba(255,107,0,0.4), transparent)",
        }}
      />

      {/* Section Header */}
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: "-100px" }}
        transition={{ duration: 0.6 }}
        className="mb-8"
      >
        <div className="flex items-center gap-2 mb-2">
          <span className="text-[10px] font-mono font-bold px-2 py-0.5 rounded bg-mine-neon/20 text-mine-neon border border-mine-neon/30">
            SIH 2026 PROBLEM ID: SIH26039
          </span>
          <span className="text-[10px] font-mono text-white/40">
            Underground Mine Safety, Monitoring & Rescue
          </span>
        </div>
        <div className="flex items-end justify-between flex-wrap gap-4">
          <h2
            className="font-display font-black text-white leading-none"
            style={{ fontSize: "clamp(2rem, 4vw, 3.5rem)" }}
          >
            SURFACE CONTROL ROOM
            <br />
            <span className="text-mine-neon neon-text">WORKER DASHBOARD</span>
          </h2>
          <StatusIndicator
            isConnected={communicationState.socketConnected}
            workerCount={workers.length}
            activeEmergency={activeEmergency}
          />
        </div>
      </motion.div>

      {/* Alert Banner if emergencies are active */}
      <AlertBanner
        alerts={incidents}
        activeEmergency={activeEmergency}
        onDismiss={clearAllEmergencies}
      />

      {/* Aggregate Vitals & Status Bar */}
      <motion.div
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
        className="flex items-center gap-3 flex-wrap mb-8"
      >
        <StatCard
          label="Total Underground"
          value={workers.length}
          unit="miners"
          color="#ffd700"
          sub="12 Smart Helmets Active"
        />
        <StatCard
          label="Safe / Nominal"
          value={aggregates.safeCount ?? 0}
          unit="workers"
          color="#00e676"
        />
        <StatCard
          label="Warning / Elevated"
          value={aggregates.warnCount ?? 0}
          unit="workers"
          color="#ffab00"
        />
        <StatCard
          label="Critical / Emergency"
          value={aggregates.critCount ?? 0}
          unit="workers"
          color={aggregates.critCount > 0 ? "#ff1744" : "#00e676"}
        />
        <StatCard
          label="Avg Heart Rate"
          value={aggregates.avgHR ?? "--"}
          unit="bpm"
          color="#ff6b00"
          sub={`Range: ${aggregates.minHR}-${aggregates.maxHR}`}
        />
        <StatCard
          label="Avg Helmet Battery"
          value={aggregates.avgBattery ?? "--"}
          unit="%"
          color={aggregates.avgBattery < 30 ? "#ff1744" : "#00e676"}
        />

        {/* SOS Emergency Trigger Button */}
        <div className="ml-auto flex items-center gap-4">
          <EmergencyButton
            onTrigger={() => triggerHazardEvent(workers[0]?.id || "W001", "MANUAL_EMERGENCY")}
            activeEmergency={activeEmergency}
          />
        </div>
      </motion.div>

      {/* Subterranean Mine Shaft Corridor GIS Map */}
      <SubterraneanZoneMap />

      {/* Incident Log & Management Center */}
      <IncidentCenter />

      {/* Filter Row */}
      <div className="flex items-center justify-between flex-wrap gap-4 mb-6">
        <div className="flex items-center gap-2 flex-wrap">
          <span className="text-[9px] font-mono text-white/30 uppercase tracking-widest mr-1">
            Mine Zone:
          </span>
          {uniqueZones.map((z) => (
            <FilterPill
              key={z}
              label={z}
              active={filterZone === z}
              onClick={() => setFilterZone(z)}
            />
          ))}
          <div className="w-px h-4 bg-white/10 mx-2" />
          <span className="text-[9px] font-mono text-white/30 uppercase tracking-widest mr-1">
            Safety Status:
          </span>
          {["ALL", "SAFE", "WARNING", "CRITICAL", "OFFLINE"].map((s) => (
            <FilterPill
              key={s}
              label={s}
              active={filterStatus === s}
              onClick={() => setFilterStatus(s)}
            />
          ))}
        </div>
        <div className="text-[10px] font-mono text-white/30">
          Showing {filteredWorkers.length} of 12 Underground Helmets
        </div>
      </div>

      {/* Worker Cards Grid */}
      <motion.div layout className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        <AnimatePresence mode="popLayout">
          {filteredWorkers.map((worker) => (
            <WorkerCard key={worker.id} worker={worker} />
          ))}
        </AnimatePresence>
      </motion.div>

      {/* Diagnostic Modal for Selected Worker */}
      <HardwareDiagnosticModal />

      {/* Footer info */}
      <div className="mt-16 pt-6 border-t border-white/5 flex items-center justify-between flex-wrap gap-4">
        <p className="font-mono text-[10px] text-white/20">
          MINO MINE · Smart Mining Safety Helmet Demonstration System (SIH 2026)
        </p>
        <p className="font-mono text-[10px] text-white/20">
          Centralized Real-Time Simulation Engine Active
        </p>
      </div>
    </section>
  );
}
