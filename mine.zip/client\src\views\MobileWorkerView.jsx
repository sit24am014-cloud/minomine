// client/src/views/MobileWorkerView.jsx
// Worker Safety Device Interface — Mobile Helmet Controller & Telemetry Console (SIH 2026)

import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useMinoMine } from "../context/MinoMineContext";

export default function MobileWorkerView() {
  const {
    workers,
    incidents,
    selectedWorkerId,
    setSelectedWorkerId,
    updateWorkerSensor,
    triggerHazardEvent,
    resetWorker,
    acknowledgeIncident,
    controlRoomBroadcasts,
    acknowledgeBroadcast,
  } = useMinoMine();

  // Local phone worker selection state so worker changing always works independently
  const [phoneWorkerId, setPhoneWorkerId] = useState(selectedWorkerId || workers[0]?.id || "W001");

  useEffect(() => {
    if (selectedWorkerId) {
      setPhoneWorkerId(selectedWorkerId);
    }
  }, [selectedWorkerId]);

  const activeWorkerId = phoneWorkerId || workers[0]?.id || "W001";
  const worker = workers.find((w) => w.id === activeWorkerId) || workers[0];

  const [txState, setTxState] = useState(null); // { label: string, phase: 'DETECTED'|'TRANSMITTING'|'SENT' }

  const activeIncident = incidents.find(
    (inc) => inc.workerId === worker?.id && inc.status !== "RESOLVED"
  );

  // Target filtering for Control Room Emergency Broadcasts
  const activeBroadcasts = (controlRoomBroadcasts || []).filter((bc) => {
    if (bc.status !== "ACTIVE") return false;
    if (bc.acknowledgedWorkerIds?.includes(worker?.id)) return false;
    if (bc.recipientWorkerIds.includes("ALL") || bc.type === "MINE-WIDE EMERGENCY") return true;
    if (bc.recipientWorkerIds.includes(worker?.id)) return true;
    if (bc.zone && worker?.zone && bc.zone.split("–")[0].trim().toUpperCase() === worker?.zone.split("–")[0].trim().toUpperCase()) return true;
    return false;
  });

  const currentBroadcast = activeBroadcasts[0];

  // Real Physical Vibration & Web Audio Buzzer Loop for Smart Helmet Ear-Piece
  useEffect(() => {
    if (!currentBroadcast) return;

    let vibrateInterval = null;
    let audioCtx = null;
    let osc = null;
    let gain = null;

    // Trigger physical phone vibration pattern
    const triggerVibration = () => {
      if (typeof window !== "undefined" && navigator.vibrate) {
        try {
          navigator.vibrate([400, 150, 400, 150, 400, 150, 800]);
        } catch (err) {
          // ignore
        }
      }
    };

    triggerVibration();
    vibrateInterval = setInterval(triggerVibration, 2200);

    // Web Audio API Acoustic Alert (Ear-Piece Buzzer simulation)
    try {
      const AudioCtxClass = window.AudioContext || window.webkitAudioContext;
      if (AudioCtxClass) {
        audioCtx = new AudioCtxClass();
        osc = audioCtx.createOscillator();
        gain = audioCtx.createGain();

        osc.type = "sawtooth";
        osc.frequency.setValueAtTime(880, audioCtx.currentTime);
        gain.gain.setValueAtTime(0.1, audioCtx.currentTime);

        osc.connect(gain);
        gain.connect(audioCtx.destination);
        osc.start();
      }
    } catch (err) {
      // Audio fallback
    }

    return () => {
      if (vibrateInterval) clearInterval(vibrateInterval);
      if (typeof window !== "undefined" && navigator.vibrate) {
        try {
          navigator.vibrate(0);
        } catch (err) {}
      }
      if (osc) {
        try {
          osc.stop();
          osc.disconnect();
        } catch (err) {}
      }
      if (audioCtx) {
        try {
          audioCtx.close();
        } catch (err) {}
      }
    };
  }, [currentBroadcast?.broadcastId]);

  const isCritical = worker?.safetyStatus === "CRITICAL" || activeIncident !== undefined;
  const isWarning = worker?.safetyStatus === "WARNING";

  const statusColorClass = isCritical
    ? "bg-red-500/20 text-red-400 border-red-500 font-black"
    : isWarning
    ? "bg-amber-500/20 text-amber-400 border-amber-500 font-bold"
    : "bg-emerald-500/20 text-emerald-400 border-emerald-500 font-bold";

  const handleAction = (label, actionFn) => {
    setTxState({ label, phase: "DETECTED" });
    actionFn();

    setTimeout(() => {
      setTxState({ label, phase: "TRANSMITTING" });
    }, 400);

    setTimeout(() => {
      setTxState({ label, phase: "SENT" });
    }, 1000);

    setTimeout(() => {
      setTxState(null);
    }, 3500);
  };

  if (!worker) return null;

  return (
    <div className="w-full max-w-md mx-auto min-h-screen bg-slate-950 text-slate-100 p-3 sm:p-4 font-mono overflow-x-hidden space-y-4">
      {/* ─── HEADER ─── */}
      <div className="p-4 bg-slate-900 rounded-xl border border-slate-800 space-y-3 shadow-lg">
        <div className="flex items-center justify-between border-b border-slate-800 pb-2">
          <div>
            <div className="font-black text-white text-base tracking-wider flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-500" />
              MINO MINE
            </div>
            <div className="text-[10px] text-amber-500 font-bold uppercase tracking-widest mt-0.5">
              WORKER SAFETY DEVICE
            </div>
          </div>
          <span className="text-[9px] px-2.5 py-1 rounded font-bold bg-blue-500/10 text-blue-400 border border-blue-500/30">
            HELMET NODE
          </span>
        </div>

        {/* Worker Selector */}
        <div className="space-y-1">
          <label className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">
            SELECT WORKER DEVICE
          </label>
          <select
            value={activeWorkerId}
            onChange={(e) => {
              const chosenId = e.target.value;
              setPhoneWorkerId(chosenId);
            }}
            className="w-full bg-slate-800 border border-slate-700 text-white font-bold text-xs rounded-lg px-3 py-2.5 focus:outline-none focus:border-amber-500 transition-colors cursor-pointer"
          >
            {workers.map((w) => (
              <option key={w.id} value={w.id}>
                {w.id} — {w.name} ({w.zone.split("–")[0].trim()})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* ─── LIVE DEVICE METRICS DISPLAY ─── */}
      <div className="p-4 bg-slate-900 rounded-xl border border-slate-800 space-y-3">
        <div className="flex items-center justify-between border-b border-slate-800 pb-2">
          <span className="text-xs text-slate-400 font-bold uppercase">DEVICE TELEMETRY</span>
          <span className={`text-[10px] px-2.5 py-0.5 rounded border ${statusColorClass}`}>
            STATUS: {worker.safetyStatus}
          </span>
        </div>

        <div className="grid grid-cols-2 gap-2 text-xs">
          <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800">
            <span className="text-[9px] text-slate-500 block uppercase">NETWORK</span>
            <span className="font-bold text-blue-400 text-xs">LoRa CONNECTED</span>
          </div>

          <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800">
            <span className="text-[9px] text-slate-500 block uppercase">HEART RATE</span>
            <span className={`font-bold ${worker.heartRate > 125 ? "text-red-400" : "text-emerald-400"}`}>
              {worker.heartRate} <span className="text-[9px] font-normal text-slate-400">BPM</span>
            </span>
          </div>

          <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800">
            <span className="text-[9px] text-slate-500 block uppercase">TEMPERATURE</span>
            <span className={`font-bold ${worker.temperature >= 38.5 ? "text-red-400" : "text-emerald-400"}`}>
              {worker.temperature} <span className="text-[9px] font-normal text-slate-400">°C</span>
            </span>
          </div>

          <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800">
            <span className="text-[9px] text-slate-500 block uppercase">GAS (MQ)</span>
            <span className={`font-bold ${worker.gasLevel >= 180 ? "text-red-400" : worker.gasLevel >= 80 ? "text-amber-400" : "text-emerald-400"}`}>
              {worker.gasLevel} <span className="text-[9px] font-normal text-slate-400">PPM</span>
            </span>
          </div>

          <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800">
            <span className="text-[9px] text-slate-500 block uppercase">BATTERY</span>
            <span className="font-bold text-emerald-400">{worker.battery}%</span>
          </div>

          <div className="p-2.5 rounded-lg bg-slate-950 border border-slate-800">
            <span className="text-[9px] text-slate-500 block uppercase">LOCATION</span>
            <span className="font-bold text-cyan-400 text-xs truncate block" title={worker.zone}>
              {worker.zone.split("–")[0].trim()}
            </span>
          </div>
        </div>

        <div className="text-[10px] text-slate-400 pt-1 flex justify-between border-t border-slate-800/80">
          <span className="font-semibold text-slate-300">📍 {worker.zone} ({worker.latitude.toFixed(4)}° N, {worker.longitude.toFixed(4)}° E)</span>
          <span className="font-bold text-amber-500">{worker.depthMeters}m Depth</span>
        </div>
      </div>

      {/* ─── FLOW B: CONTROL ROOM EMERGENCY BROADCAST CARD (HELMET EAR VIBRATION) ─── */}
      <AnimatePresence>
        {currentBroadcast && (
          <motion.div
            initial={{ opacity: 0, y: -15, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="p-4 rounded-2xl bg-red-950/95 border-2 border-red-500 text-xs space-y-3 font-mono shadow-[0_0_40px_rgba(239,68,68,0.6)] relative overflow-hidden text-slate-100"
          >
            {/* Animated Vibration Line */}
            <div className="absolute top-0 inset-x-0 h-2 bg-gradient-to-r from-red-500 via-amber-400 to-red-500 animate-pulse" />

            {/* Header */}
            <div className="flex items-center justify-between border-b border-red-500/50 pb-2">
              <div className="flex items-center gap-2.5">
                <motion.span
                  animate={{ rotate: [-10, 10, -10, 10, 0], scale: [1, 1.2, 1] }}
                  transition={{ repeat: Infinity, duration: 0.4 }}
                  className="text-3xl"
                >
                  📳
                </motion.span>
                <div>
                  <div className="font-black text-red-400 text-sm tracking-wider uppercase flex items-center gap-2">
                    <span>EVACUATION DIRECTIVE</span>
                    <span className="w-2 h-2 rounded-full bg-red-500 animate-ping" />
                  </div>
                  <div className="text-[10px] text-amber-300 font-bold uppercase tracking-widest mt-0.5">
                    HELMET EAR VIBRATOR MOTOR ACTIVE
                  </div>
                </div>
              </div>
              <span className="px-2.5 py-1 rounded bg-red-600 text-white font-black text-[10px] tracking-wider uppercase shadow">
                {currentBroadcast.type}
              </span>
            </div>

            {/* Haptic & Audio Motor Status Banner */}
            <div className="p-3 rounded-xl bg-black/80 border border-amber-500/60 flex items-center justify-between gap-3 shadow-inner">
              <div className="space-y-1">
                <div className="text-[10px] text-amber-400 font-black uppercase tracking-wider flex items-center gap-1.5">
                  <span className="animate-pulse">📳</span> HELMET VIBRATION MOTOR: <span className="text-emerald-400 animate-pulse">VIBRATING NEAR EAR</span>
                </div>
                <div className="text-[10px] text-slate-300 font-semibold">
                  Tactile Signal: <strong className="text-amber-300">3 Long Pulses (GET OUT OF TUNNEL)</strong>
                </div>
                <div className="text-[9px] text-slate-400">
                  No screen reading required — ear piece vibrator is active on device
                </div>
              </div>
              <motion.div
                animate={{ x: [-4, 4, -4, 4, 0], scale: [1, 1.2, 1] }}
                transition={{ repeat: Infinity, duration: 0.2 }}
                className="text-3xl shrink-0"
              >
                📳
              </motion.div>
            </div>

            {/* Broadcast Details */}
            <div className="space-y-1.5 text-slate-200 text-[11px]">
              <div className="flex justify-between items-center bg-slate-900/90 p-2 rounded-lg border border-slate-800">
                <span className="text-slate-400 font-bold">TARGET ZONE:</span>
                <span className="font-extrabold text-amber-300">{currentBroadcast.zone}</span>
              </div>
              <div className="p-3 rounded-xl bg-slate-900/90 border border-red-500/40 text-amber-200 font-bold text-xs space-y-1">
                <div className="text-[10px] text-slate-400 font-normal uppercase">CONTROL ROOM INSTRUCTION:</div>
                <div className="text-red-300 font-extrabold uppercase text-xs leading-relaxed">
                  "{currentBroadcast.message || "TUNNEL COLLAPSE DETECTED. EVACUATE TO SAFE ROUTE IMMEDIATELY."}"
                </div>
              </div>
            </div>

            {/* Acknowledge Button */}
            <button
              onClick={() => acknowledgeBroadcast(currentBroadcast.broadcastId, worker.id)}
              className="w-full py-3 rounded-xl bg-amber-500 hover:bg-amber-400 active:scale-[0.98] text-black font-black text-xs transition-all tracking-wider uppercase font-mono shadow-lg flex items-center justify-center gap-2 cursor-pointer"
            >
              <span>🔕</span>
              <span>ACKNOWLEDGE & STOP HELMET VIBRATION</span>
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ─── EMERGENCY ACTIVE STATUS BANNER WITH LOCATION & REASON FOR HAZARD ─── */}
      {(isCritical || isWarning) && (
        <motion.div
          initial={{ opacity: 0, y: -5 }}
          animate={{ opacity: 1, y: 0 }}
          className={`p-4 rounded-xl text-xs space-y-2.5 border-2 ${
            isCritical
              ? "bg-red-950/90 border-red-500 animate-pulse shadow-[0_0_25px_rgba(239,68,68,0.4)]"
              : "bg-amber-950/90 border-amber-500 shadow-[0_0_20px_rgba(245,158,11,0.3)]"
          }`}
        >
          <div className="flex items-center justify-between font-bold border-b pb-1.5 border-slate-700/50">
            <span className="flex items-center gap-1.5 text-sm font-black">
              {isCritical ? "🚨 EMERGENCY HAZARD TRANSMITTED" : "⚠️ WARNING TELEMETRY ALERT"}
            </span>
            <span className={`px-2 py-0.5 rounded text-[10px] font-black ${
              isCritical ? "bg-red-600 text-white" : "bg-amber-500 text-black"
            }`}>
              {worker.safetyStatus}
            </span>
          </div>

          <div className="space-y-1.5 text-slate-200 text-[11px]">
            <div><strong>WORKER NODE:</strong> <span className="font-bold text-amber-400">{worker.id} — {worker.name}</span></div>
            
            <div className="p-2.5 rounded-lg bg-black/70 border border-red-500/40 space-y-1">
              <span className="text-[10px] text-slate-400 block font-bold uppercase tracking-wider">
                REASON FOR HAZARD:
              </span>
              <span className="text-red-300 font-extrabold text-xs block">
                {worker.fallDetected
                  ? "🤸 MPU6050 Accelerometer Impact (4.2G Sudden Fall Drop)"
                  : worker.fireDetected
                  ? "🔥 IR Flame Sensor Ignition (760-1100nm Optical Alert)"
                  : worker.gasLevel >= 180
                  ? `☁️ Critical MQ Gas Surge (${worker.gasLevel} PPM CH₄/CO Toxic Hazard)`
                  : worker.gasLevel >= 80
                  ? `⚠️ Warning MQ Gas Concentration (${worker.gasLevel} PPM CH₄/CO Level)`
                  : worker.temperature >= 38.5
                  ? `🌡️ Hyperthermia Thermal Stress (${worker.temperature}°C High Temperature)`
                  : worker.heartRate > 125
                  ? `❤️ Cardiac Tachycardia Stress (${worker.heartRate} BPM High Heart Rate)`
                  : worker.heartRate > 100
                  ? `⚠️ Elevated Cardiac Stress (${worker.heartRate} BPM Elevated Heart Rate)`
                  : "⚠️ Sensor Telemetry Anomaly Detected"}
              </span>
            </div>

            <div className="p-2.5 rounded-lg bg-slate-900 border border-slate-800 space-y-0.5">
              <span className="text-[9px] text-slate-400 block font-bold uppercase tracking-wider">
                WORKER LOCATION & SUBTERRANEAN POSITION:
              </span>
              <span className="text-cyan-300 font-bold text-xs block">
                📍 {worker.zone}
              </span>
              <span className="text-slate-300 text-[10px] block">
                Depth: <strong className="text-amber-400">{worker.depthMeters}m</strong> | GIS Coordinates: {worker.latitude.toFixed(4)}° N, {worker.longitude.toFixed(4)}° E
              </span>
            </div>

            <div className="flex items-center justify-between text-[10px] pt-1">
              <span className="text-slate-400">COMMUNICATION:</span>
              <span className="text-cyan-400 font-bold">EMERGENCY LORA PACKET SENT TO CONTROL ROOM</span>
            </div>
          </div>

          {activeIncident && activeIncident.acknowledgementStatus === "UNACKNOWLEDGED" && (
            <button
              onClick={() => acknowledgeIncident(activeIncident.id)}
              className="w-full mt-2 py-2.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-black font-bold text-xs transition-colors shadow-md uppercase tracking-wider font-mono"
            >
              ACKNOWLEDGE ALERT DIRECTIVE
            </button>
          )}
        </motion.div>
      )}

      {/* ─── LIVE TRANSMISSION STATE ANIMATION TOAST ─── */}
      <AnimatePresence>
        {txState && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="p-3 rounded-xl bg-blue-950 border border-blue-500/60 text-blue-300 text-xs font-bold text-center space-y-1 shadow-lg"
          >
            <div className="flex items-center justify-center gap-2 text-sm text-cyan-300">
              <span className="animate-spin">📡</span>
              <span>{txState.label.toUpperCase()} DETECTED</span>
            </div>
            <div className="text-[11px] text-blue-200">
              {txState.phase === "DETECTED" && "MPU6050 / ESP32 Sensor Hazard Triggered..."}
              {txState.phase === "TRANSMITTING" && "TRANSMITTING EMERGENCY VIA LORA MESH..."}
              {txState.phase === "SENT" && "✔ EMERGENCY PACKET SENT TO CONTROL ROOM"}
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ─── WORKER SENSOR ACTIONS (CARDS 1-6) ─── */}
      <div className="space-y-3 pt-2">
        <div className="text-xs text-slate-400 font-bold uppercase tracking-wider flex items-center justify-between">
          <span>WORKER SENSOR CONTROLS</span>
          <span className="text-[10px] text-amber-500 font-normal">Target: {worker.id}</span>
        </div>

        {/* CARD 1: HEART RATE */}
        <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 space-y-2.5">
          <div className="flex items-center justify-between text-xs border-b border-slate-800 pb-1.5">
            <span className="font-bold text-white flex items-center gap-1.5">
              <span>❤️</span> CARD 1: HEART RATE
            </span>
            <span className="text-amber-400 font-bold">Current: {worker.heartRate} BPM</span>
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs">
            <button
              onClick={() => handleAction("Heart Rate Increase", () => updateWorkerSensor(worker.id, "heartRate", worker.heartRate + 15))}
              className="py-2.5 px-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-white font-bold text-[11px] border border-slate-700 transition-colors"
            >
              ▲ INCREASE HEART RATE
            </button>
            <button
              onClick={() => handleAction("Heart Rate Decrease", () => updateWorkerSensor(worker.id, "heartRate", Math.max(45, worker.heartRate - 15)))}
              className="py-2.5 px-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-white font-bold text-[11px] border border-slate-700 transition-colors"
            >
              ▼ DECREASE HEART RATE
            </button>
            <button
              onClick={() => handleAction("Abnormal Heart Rate", () => updateWorkerSensor(worker.id, "heartRate", 112))}
              className="py-2.5 px-2 rounded-lg bg-amber-950/60 hover:bg-amber-900/60 text-amber-300 font-bold text-[11px] border border-amber-500/40 transition-colors"
            >
              ⚠️ SET ABNORMAL
            </button>
            <button
              onClick={() => handleAction("Critical Heart Rate", () => updateWorkerSensor(worker.id, "heartRate", 145))}
              className="py-2.5 px-2 rounded-lg bg-red-950/60 hover:bg-red-900/60 text-red-300 font-bold text-[11px] border border-red-500/40 transition-colors"
            >
              🚨 SET CRITICAL
            </button>
          </div>

          <button
            onClick={() => handleAction("Reset Heart Rate", () => updateWorkerSensor(worker.id, "heartRate", 74))}
            className="w-full py-2.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs border border-slate-700 transition-colors"
          >
            🔄 RESET HEART RATE
          </button>
        </div>

        {/* CARD 2: TEMPERATURE */}
        <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 space-y-2.5">
          <div className="flex items-center justify-between text-xs border-b border-slate-800 pb-1.5">
            <span className="font-bold text-white flex items-center gap-1.5">
              <span>🌡️</span> CARD 2: TEMPERATURE
            </span>
            <span className="text-amber-400 font-bold">Current: {worker.temperature}°C</span>
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs">
            <button
              onClick={() => handleAction("Temperature Increase", () => updateWorkerSensor(worker.id, "temperature", parseFloat((worker.temperature + 0.8).toFixed(1))))}
              className="py-2.5 px-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-white font-bold text-[11px] border border-slate-700 transition-colors"
            >
              ▲ INCREASE TEMP
            </button>
            <button
              onClick={() => handleAction("High Temperature Hazard", () => updateWorkerSensor(worker.id, "temperature", 39.1))}
              className="py-2.5 px-2 rounded-lg bg-red-950/60 hover:bg-red-900/60 text-red-300 font-bold text-[11px] border border-red-500/40 transition-colors"
            >
              🔥 SET HIGH TEMP
            </button>
          </div>

          <button
            onClick={() => handleAction("Reset Temperature", () => updateWorkerSensor(worker.id, "temperature", 36.6))}
            className="w-full py-2.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs border border-slate-700 transition-colors"
          >
            🔄 RESET TEMPERATURE
          </button>
        </div>

        {/* CARD 3: GAS SENSOR */}
        <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 space-y-2.5">
          <div className="flex items-center justify-between text-xs border-b border-slate-800 pb-1.5">
            <span className="font-bold text-white flex items-center gap-1.5">
              <span>☁️</span> CARD 3: MQ GAS SENSOR
            </span>
            <span className="text-amber-400 font-bold">Current: {worker.gasLevel} PPM</span>
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs">
            <button
              onClick={() => handleAction("Gas Increase", () => updateWorkerSensor(worker.id, "gasLevel", worker.gasLevel + 40))}
              className="py-2.5 px-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-white font-bold text-[11px] border border-slate-700 transition-colors"
            >
              ▲ INCREASE GAS
            </button>
            <button
              onClick={() => handleAction("Gas Leak Hazard", () => triggerHazardEvent(worker.id, "GAS_LEAK"))}
              className="py-2.5 px-2 rounded-lg bg-amber-950/60 hover:bg-amber-900/60 text-amber-300 font-bold text-[11px] border border-amber-500/40 transition-colors"
            >
              ⚠️ TRIGGER GAS LEAK
            </button>
          </div>

          <button
            onClick={() => handleAction("Clear Gas Alert", () => updateWorkerSensor(worker.id, "gasLevel", 15))}
            className="w-full py-2.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs border border-slate-700 transition-colors"
          >
            🔄 CLEAR GAS ALERT
          </button>
        </div>

        {/* CARD 4: MOVEMENT (MPU6050) */}
        <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 space-y-2.5">
          <div className="flex items-center justify-between text-xs border-b border-slate-800 pb-1.5">
            <span className="font-bold text-white flex items-center gap-1.5">
              <span>🤸</span> CARD 4: MOVEMENT (MPU6050)
            </span>
            <span className="text-xs text-slate-400">{worker.fallDetected ? "FALL" : "NORMAL"}</span>
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs">
            <button
              onClick={() => handleAction("Fall Hazard", () => triggerHazardEvent(worker.id, "FALL"))}
              className="py-2.5 px-2 rounded-lg bg-red-950/60 hover:bg-red-900/60 text-red-300 font-bold text-[11px] border border-red-500/40 transition-colors"
            >
              🚨 SIMULATE FALL
            </button>
            <button
              onClick={() => handleAction("Abnormal Motion", () => updateWorkerSensor(worker.id, "heartRate", 108))}
              className="py-2.5 px-2 rounded-lg bg-amber-950/60 hover:bg-amber-900/60 text-amber-300 font-bold text-[11px] border border-amber-500/40 transition-colors"
            >
              ⚠️ ABNORMAL MOTION
            </button>
          </div>

          <button
            onClick={() => handleAction("Reset Motion", () => updateWorkerSensor(worker.id, "fallDetected", false))}
            className="w-full py-2.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs border border-slate-700 transition-colors"
          >
            🔄 RESET MOVEMENT
          </button>
        </div>

        {/* CARD 5: FLAME SENSOR */}
        <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 space-y-2.5">
          <div className="flex items-center justify-between text-xs border-b border-slate-800 pb-1.5">
            <span className="font-bold text-white flex items-center gap-1.5">
              <span>🔥</span> CARD 5: FLAME SENSOR
            </span>
            <span className="text-xs text-slate-400">{worker.fireDetected ? "FIRE" : "CLEAR"}</span>
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs">
            <button
              onClick={() => handleAction("Fire Hazard", () => triggerHazardEvent(worker.id, "FIRE"))}
              className="py-2.5 px-2 rounded-lg bg-orange-950/60 hover:bg-orange-900/60 text-orange-300 font-bold text-[11px] border border-orange-500/40 transition-colors"
            >
              🔥 TRIGGER FIRE
            </button>
            <button
              onClick={() => handleAction("Clear Fire", () => updateWorkerSensor(worker.id, "fireDetected", false))}
              className="py-2.5 px-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-[11px] border border-slate-700 transition-colors"
            >
              🔄 CLEAR FIRE
            </button>
          </div>
        </div>

        {/* CARD 6: MEDICAL & SOS */}
        <div className="p-3.5 rounded-xl bg-slate-900 border border-slate-800 space-y-2.5">
          <div className="flex items-center justify-between text-xs border-b border-slate-800 pb-1.5">
            <span className="font-bold text-white flex items-center gap-1.5">
              <span>🚑</span> CARD 6: MEDICAL & SOS
            </span>
            <span className="text-xs text-purple-400 font-bold">EMERGENCY</span>
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs">
            <button
              onClick={() => handleAction("Medical Emergency", () => triggerHazardEvent(worker.id, "MEDICAL"))}
              className="py-3 px-2 rounded-lg bg-purple-950/60 hover:bg-purple-900/60 text-purple-300 font-bold text-[11px] border border-purple-500/40 transition-colors"
            >
              🚑 MEDICAL EMERGENCY
            </button>
            <button
              onClick={() => handleAction("Manual SOS", () => triggerHazardEvent(worker.id, "MANUAL_EMERGENCY"))}
              className="py-3 px-2 rounded-lg bg-red-600 hover:bg-red-500 text-white font-black text-[12px] tracking-wider transition-colors shadow-lg animate-pulse"
            >
              🆘 SOS EMERGENCY
            </button>
          </div>

          <button
            onClick={() => handleAction("Reset Worker", () => resetWorker(worker.id))}
            className="w-full py-3 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition-colors shadow-md mt-2"
          >
            🔄 RESET WORKER ({worker.id}) TO SAFE
          </button>
        </div>
      </div>
    </div>
  );
}

