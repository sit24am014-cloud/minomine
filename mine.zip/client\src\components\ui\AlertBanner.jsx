// client/src/components/ui/AlertBanner.jsx
// Full-width emergency alert banner with flashing animation

import React from "react";
import { motion, AnimatePresence } from "framer-motion";

export default function AlertBanner({ alerts = [], activeEmergency, onDismiss }) {
  const latest = alerts[0];

  return (
    <AnimatePresence>
      {activeEmergency && latest && (
        <motion.div
          initial={{ y: -80, opacity: 0 }}
          animate={{ y: 0,   opacity: 1 }}
          exit={{    y: -80, opacity: 0 }}
          transition={{ type: "spring", stiffness: 280, damping: 22 }}
          className="w-full rounded-xl overflow-hidden mb-4"
          style={{
            background: "rgba(255,23,68,0.12)",
            border:     "1px solid rgba(255,23,68,0.4)",
          }}
        >
          <div className="animate-pulse-alert p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-4">
                {/* Pulsing siren icon */}
                <div className="relative flex-shrink-0">
                  <div className="w-10 h-10 rounded-full bg-mine-danger flex items-center justify-center text-lg animate-ping absolute inset-0 opacity-30" />
                  <div className="w-10 h-10 rounded-full bg-mine-danger flex items-center justify-center text-lg relative z-10">
                    ⚠
                  </div>
                </div>

                <div>
                  <p className="font-display font-bold text-mine-danger text-sm uppercase tracking-widest">
                    Emergency Alert
                  </p>
                  <p className="font-mono text-white text-sm mt-0.5">{latest.message}</p>
                  <p className="font-mono text-white/40 text-xs mt-0.5">
                    Severity: {latest.severity?.toUpperCase()} &nbsp;·&nbsp;
                    {new Date(latest.timestamp).toLocaleTimeString()}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-3">
                {/* Animated waveform bars */}
                <div className="flex items-end gap-0.5 h-8">
                  {[3,5,7,4,6,8,5,3,6,7].map((h, i) => (
                    <div
                      key={i}
                      className="w-1 bg-mine-danger rounded-full"
                      style={{
                        height:    `${h * 3}px`,
                        animation: `data-flash ${0.3 + i * 0.07}s ease-in-out infinite alternate`,
                      }}
                    />
                  ))}
                </div>

                <button
                  onClick={onDismiss}
                  className="text-xs font-mono text-white/50 hover:text-white border border-white/20 hover:border-white/40 rounded px-3 py-1 transition-colors"
                >
                  DISMISS
                </button>
              </div>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
