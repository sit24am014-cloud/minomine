// client/src/views/IncidentHistoryView.jsx
// Subterranean Emergency Incident History & Event Log for MINO MINE

import React from "react";
import { useMinoMine } from "../context/MinoMineContext";
import IncidentCenter from "../components/ui/IncidentCenter";

export default function IncidentHistoryView() {
  const { incidents, controlRoomBroadcasts } = useMinoMine();

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="command-panel p-6 border-l-4 border-l-red-500">
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="font-mono text-xs font-bold text-red-500 bg-red-500/10 px-2 py-0.5 rounded border border-red-500/30">
                MINO MINE
              </span>
              <span className="font-mono text-xs text-slate-400">
                UNDERGROUND MINING SAFETY SYSTEM
              </span>
            </div>
            <h1 className="font-display text-2xl font-black text-white">
              INCIDENT HISTORY & RESCUE TIMELINE
            </h1>
          </div>
          <span className="font-mono text-xs px-3 py-1.5 rounded bg-slate-800 text-amber-400 border border-slate-700">
            DEMO / SIMULATION MODE
          </span>
        </div>
      </div>

      <IncidentCenter />

      {/* Control Room Broadcast Directives History */}
      <div className="command-panel p-6">
        <h3 className="font-display font-bold text-lg text-white mb-4">
          Control Room Emergency Broadcast Directives
        </h3>
        {controlRoomBroadcasts.length === 0 ? (
          <div className="text-center py-6 text-slate-500 font-mono text-xs bg-slate-950 rounded border border-slate-800">
            No Control Room evacuation broadcasts logged yet.
          </div>
        ) : (
          <div className="space-y-3">
            {controlRoomBroadcasts.map((bc) => (
              <div key={bc.broadcastId} className="p-4 rounded bg-slate-900 border border-blue-500/40 flex items-center justify-between flex-wrap gap-4 text-xs font-mono">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-blue-400">{bc.broadcastId}</span>
                    <span className="px-2 py-0.5 rounded bg-red-600 text-white font-bold text-[10px]">{bc.type}</span>
                    <span className="text-amber-300 font-bold">{bc.zone}</span>
                  </div>
                  <div className="text-[11px] text-slate-300 mt-1">
                    Targets: {bc.recipientWorkerIds.join(", ")} | "{bc.message}"
                  </div>
                  <div className="text-[10px] text-slate-400 mt-0.5">
                    Timestamp: {new Date(bc.timestamp).toLocaleString()}
                  </div>
                </div>
                <div className="text-right">
                  <span className="px-2.5 py-1 rounded bg-slate-800 text-emerald-400 font-bold border border-slate-700">
                    STATUS: ACTIVE
                  </span>
                  <div className="text-[10px] text-slate-400 mt-1">
                    Ack: {bc.acknowledgedWorkerIds?.length || 0} Workers
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="command-panel p-6">
        <h3 className="font-display font-bold text-lg text-white mb-4">
          SIH 2026 Emergency Incident Audit Trail
        </h3>
        {incidents.length === 0 ? (
          <div className="text-center py-8 text-slate-500 font-mono text-xs bg-slate-950 rounded border border-slate-800">
            No worker incidents recorded. Use the Sensor Simulator tab to trigger test emergency events.
          </div>
        ) : (
          <div className="space-y-3">
            {incidents.map((inc) => (
              <div key={inc.id} className="p-4 rounded bg-slate-900/60 border border-slate-800 flex items-center justify-between flex-wrap gap-4 text-xs font-mono">
                <div>
                  <span className="font-bold text-amber-500">{inc.id}</span> — <span className="text-white font-semibold">{inc.type}</span> ({inc.workerName})
                  <div className="text-[10px] text-slate-400 mt-0.5">{inc.location} · {new Date(inc.timestamp).toLocaleString()}</div>
                </div>
                <div className="flex items-center gap-3">
                  <span className="px-2 py-1 rounded bg-slate-800 text-slate-300">
                    Status: {inc.status}
                  </span>
                  <span className="px-2 py-1 rounded bg-slate-800 text-slate-300">
                    Ack: {inc.acknowledgementStatus}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
