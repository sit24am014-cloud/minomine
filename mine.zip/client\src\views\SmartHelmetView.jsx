// client/src/views/SmartHelmetView.jsx
// Interactive MINO MINE Smart Helmet 12-Hardware Visualization Component

import React, { useState, Suspense } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useMinoMine } from "../context/MinoMineContext";
import HelmetScene from "../components/three/HelmetScene";
import DataPanel from "../components/ui/DataPanel";

const COMPONENTS_LIST = [
  {
    id: "esp32",
    name: "ESP32 MCU SoC",
    shortName: "ESP32",
    purpose: "Main Microcontroller & Edge Sensor Processing Hub",
    safetyFunction: "Coordinates FreeRTOS tasks for 12 sensors, edge anomaly evaluation, and LoRa packet generation.",
    icon: "🔲",
    posX: "50%",
    posY: "48%",
  },
  {
    id: "max30102",
    name: "MAX30102 PPG Sensor",
    shortName: "MAX30102",
    purpose: "Heart-rate monitoring & blood oxygen pulse oximetry",
    safetyFunction: "Measures forehead arterial blood volume pulse for real-time Heart Rate (BPM) and Blood Oxygen Saturation (SpO₂%).",
    icon: "❤️",
    posX: "32%",
    posY: "55%",
  },
  {
    id: "mpu6050",
    name: "MPU6050 6-Axis IMU",
    shortName: "MPU6050",
    purpose: "Fall and movement detection",
    safetyFunction: "Detects sudden subterranean miner falls, vertical drops, structural impacts, and prolonged post-impact immobility (Man-Down).",
    icon: "🤸",
    posX: "68%",
    posY: "55%",
  },
  {
    id: "mq_gas",
    name: "MQ Gas Sensor Array",
    shortName: "MQ GAS",
    purpose: "Hazardous gas detection",
    safetyFunction: "Monitors explosive methane (CH₄) and carbon monoxide (CO) gas leaks in dark coal mine shafts.",
    icon: "☁️",
    posX: "50%",
    posY: "28%",
  },
  {
    id: "flame_sensor",
    name: "IR Flame Sensor",
    shortName: "FLAME SENSOR",
    purpose: "Underground fire & flame detection",
    safetyFunction: "760nm–1100nm infrared sensor instantly detecting open flame ignition and electrical arcing.",
    icon: "🔥",
    posX: "62%",
    posY: "36%",
  },
  {
    id: "temp_sensor",
    name: "Temperature Sensor",
    shortName: "TEMPERATURE SENSOR",
    purpose: "Thermal atmosphere & heat stroke monitor",
    safetyFunction: "Prevents miner hyperthermia, heat stroke, and thermal runaway inside hot deep mine shafts.",
    icon: "🌡️",
    posX: "38%",
    posY: "36%",
  },
  {
    id: "gps",
    name: "GPS / GIS Subterranean Beacon",
    shortName: "GPS",
    purpose: "Worker location & tunnel positioning",
    safetyFunction: "Provides exact subterranean shaft coordinates, elevation depth meters, and GIS beacon location.",
    icon: "🗺️",
    posX: "28%",
    posY: "44%",
  },
  {
    id: "lora",
    name: "LoRa SX1276 Radio",
    shortName: "LoRa",
    purpose: "Long-range emergency communication",
    safetyFunction: "Sub-GHz SX1276 radio penetrating up to 5 km of solid subterranean rock strata where Wi-Fi fails.",
    icon: "📡",
    posX: "72%",
    posY: "44%",
  },
  {
    id: "ldr",
    name: "LDR Light Sensor",
    shortName: "LDR",
    purpose: "Automatic helmet light control",
    safetyFunction: "Photoresistor measuring ambient light to automatically dim or brighten the Cree LED headlamp.",
    icon: "☀️",
    posX: "50%",
    posY: "72%",
  },
  {
    id: "led_headlamp",
    name: "Cree LED & RGB Halo",
    shortName: "LED",
    purpose: "Illumination & visual safety status beacon",
    safetyFunction: "1000 lumen headlight + RGB visual halo indicating safety status (NORMAL / WARNING / CRITICAL) to co-workers.",
    icon: "💡",
    posX: "50%",
    posY: "65%",
  },
  {
    id: "vibration_motor",
    name: "Vibration Haptic Motor",
    shortName: "VIBRATION MOTOR",
    purpose: "Silent emergency warning",
    safetyFunction: "Provides immediate tactile vibration alerts inside the helmet, audible above 100+ dB machinery noise.",
    icon: "📳",
    posX: "65%",
    posY: "65%",
  },
  {
    id: "battery",
    name: "Li-Ion Battery & BMS",
    shortName: "BATTERY",
    purpose: "Intrinsically safe power system",
    safetyFunction: "ATEX Zone 0 certified 4400 mAh power pack with smart short-circuit and thermal BMS protection.",
    icon: "🔋",
    posX: "50%",
    posY: "82%",
  },
];

export default function SmartHelmetView() {
  const { workers, selectedWorkerId, setSelectedWorkerId, triggerHazardEvent } = useMinoMine();
  const [selectedCompId, setSelectedCompId] = useState("mpu6050");
  const [renderMode, setRenderMode] = useState("diagram"); // "diagram" | "3d"

  const activeWorkerId = selectedWorkerId || workers[0]?.id || "W001";
  const worker = workers.find((w) => w.id === activeWorkerId) || workers[0];

  const selectedComp = COMPONENTS_LIST.find((c) => c.id === selectedCompId) || COMPONENTS_LIST[0];

  // Calculate Status for a component based on live worker state
  const getComponentStatus = (compKey) => {
    if (worker.safetyStatus === "OFFLINE") return { label: "OFFLINE", color: "#64748b", bg: "bg-slate-800" };

    switch (compKey) {
      case "mpu6050":
        return worker.fallDetected
          ? { label: "CRITICAL", color: "#ef4444", bg: "bg-red-500/20 border-red-500" }
          : { label: "NORMAL", color: "#10b981", bg: "bg-emerald-500/20 border-emerald-500" };
      case "mq_gas":
        return worker.gasLevel > 180
          ? { label: "CRITICAL", color: "#ef4444", bg: "bg-red-500/20 border-red-500" }
          : worker.gasLevel > 80
          ? { label: "WARNING", color: "#f59e0b", bg: "bg-amber-500/20 border-amber-500" }
          : { label: "NORMAL", color: "#10b981", bg: "bg-emerald-500/20 border-emerald-500" };
      case "flame_sensor":
        return worker.fireDetected
          ? { label: "CRITICAL", color: "#ef4444", bg: "bg-red-500/20 border-red-500" }
          : { label: "NORMAL", color: "#10b981", bg: "bg-emerald-500/20 border-emerald-500" };
      case "max30102":
        return worker.heartRate > 130 || worker.heartRate < 45
          ? { label: "CRITICAL", color: "#ef4444", bg: "bg-red-500/20 border-red-500" }
          : worker.heartRate > 105
          ? { label: "WARNING", color: "#f59e0b", bg: "bg-amber-500/20 border-amber-500" }
          : { label: "NORMAL", color: "#10b981", bg: "bg-emerald-500/20 border-emerald-500" };
      case "temp_sensor":
        return worker.temperature >= 38.5
          ? { label: "CRITICAL", color: "#ef4444", bg: "bg-red-500/20 border-red-500" }
          : worker.temperature >= 37.5
          ? { label: "WARNING", color: "#f59e0b", bg: "bg-amber-500/20 border-amber-500" }
          : { label: "NORMAL", color: "#10b981", bg: "bg-emerald-500/20 border-emerald-500" };
      case "battery":
        return worker.battery < 15
          ? { label: "CRITICAL", color: "#ef4444", bg: "bg-red-500/20 border-red-500" }
          : worker.battery < 30
          ? { label: "WARNING", color: "#f59e0b", bg: "bg-amber-500/20 border-amber-500" }
          : { label: "NORMAL", color: "#10b981", bg: "bg-emerald-500/20 border-emerald-500" };
      case "vibration_motor":
        return worker.safetyStatus === "CRITICAL"
          ? { label: "CRITICAL", color: "#ef4444", bg: "bg-red-500/20 border-red-500" }
          : { label: "NORMAL", color: "#10b981", bg: "bg-emerald-500/20 border-emerald-500" };
      default:
        return worker.safetyStatus === "CRITICAL"
          ? { label: "CRITICAL", color: "#ef4444", bg: "bg-red-500/20 border-red-500" }
          : worker.safetyStatus === "WARNING"
          ? { label: "WARNING", color: "#f59e0b", bg: "bg-amber-500/20 border-amber-500" }
          : { label: "NORMAL", color: "#10b981", bg: "bg-emerald-500/20 border-emerald-500" };
    }
  };

  // Get Live Value string for selected component
  const getSimulatedValue = (compId) => {
    switch (compId) {
      case "esp32":
        return "FreeRTOS Active · CPU Load: 24% · 520 KB SRAM";
      case "max30102":
        return `${worker.heartRate} BPM · SpO₂: ${worker.spO2 || 98}% · BP: ${worker.systolicBP}/${worker.diastolicBP}`;
      case "mpu6050":
        return worker.fallDetected ? "IMPACT DETECTED! (4.2G Accel)" : "Nominal Motion (1.02G Accel)";
      case "mq_gas":
        return `${worker.gasLevel} PPM Hazardous Gas Level`;
      case "flame_sensor":
        return worker.fireDetected ? "FIRE FLAME DETECTED! (IR High)" : "Clear (0 IR Flame Signal)";
      case "temp_sensor":
        return `${worker.temperature} °C Body / Ambient Temp`;
      case "gps":
        return `${worker.latitude.toFixed(4)}° N, ${worker.longitude.toFixed(4)}° E (${worker.depthMeters}m Shaft Depth)`;
      case "lora":
        return `${worker.communicationStatus} (868 MHz / -68 dBm RSSI)`;
      case "ldr":
        return `${worker.ldrLux || 45} Lux Ambient Illumination`;
      case "led_headlamp":
        return worker.headlightOn ? "ON (1000 Lumens Cool White)" : "DIMMED / OFF";
      case "vibration_motor":
        return worker.safetyStatus === "CRITICAL" || worker.hapticActive ? "VIBRATING HAPTIC ALERT ACTIVE" : "IDLE (Standing By)";
      case "battery":
        return `${worker.battery}% Charge (3.82V Li-Ion)`;
      default:
        return "Telemetry Stream Active";
    }
  };

  const compStatus = getComponentStatus(selectedComp.id);

  return (
    <div className="space-y-6">
      {/* Required Page Header Banner */}
      <div className="command-panel p-6 border-l-4 border-l-amber-500">
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="font-mono text-xs font-bold text-amber-500 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/30">
                MINO MINE
              </span>
              <span className="font-mono text-xs text-slate-400">
                UNDERGROUND MINING SAFETY SYSTEM
              </span>
            </div>
            <h1 className="font-display text-2xl font-black text-white">
              SMART HELMET 12-HARDWARE ARCHITECTURE
            </h1>
          </div>

          <div className="flex items-center gap-3">
            <span className="font-mono text-xs px-3 py-1.5 rounded bg-slate-800 text-amber-400 border border-slate-700">
              DEMO MODE · SIMULATED HARDWARE DATA
            </span>
            <div className="flex items-center border border-slate-700 rounded-lg overflow-hidden font-mono text-xs">
              <button
                onClick={() => setRenderMode("diagram")}
                className={`px-3 py-1.5 ${renderMode === "diagram" ? "bg-amber-500 text-black font-bold" : "bg-slate-900 text-slate-400"}`}
              >
                SCHEMATIC
              </button>
              <button
                onClick={() => setRenderMode("3d")}
                className={`px-3 py-1.5 ${renderMode === "3d" ? "bg-amber-500 text-black font-bold" : "bg-slate-900 text-slate-400"}`}
              >
                3D WEBGL
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Target Worker Selector Bar */}
      <div className="command-panel p-4 flex items-center justify-between flex-wrap gap-4 font-mono text-xs">
        <div className="flex items-center gap-3">
          <span className="text-slate-400 uppercase">Target Helmet Telemetry:</span>
          <select
            value={activeWorkerId}
            onChange={(e) => setSelectedWorkerId(e.target.value)}
            className="bg-slate-900 border border-slate-700 text-white rounded px-3 py-1.5 font-bold"
          >
            {workers.map((w) => (
              <option key={w.id} value={w.id}>
                {w.id} - {w.name} ({w.zone.split("–")[0].trim()}) [{w.safetyStatus}]
              </option>
            ))}
          </select>
        </div>

        {/* Test Trigger buttons */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => triggerHazardEvent(activeWorkerId, "FALL")}
            className="px-2.5 py-1 rounded bg-red-950/60 border border-red-500/40 text-red-400 hover:bg-red-900/40 transition-colors text-[11px]"
          >
            Trigger MPU6050 Fall
          </button>
          <button
            onClick={() => triggerHazardEvent(activeWorkerId, "GAS_LEAK")}
            className="px-2.5 py-1 rounded bg-amber-950/60 border border-amber-500/40 text-amber-400 hover:bg-amber-900/40 transition-colors text-[11px]"
          >
            Trigger MQ Gas Surge
          </button>
        </div>
      </div>

      {/* Main Interactive Diagram / 3D Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Helmet Schematic / 3D Display Panel */}
        <div className="lg:col-span-7 command-panel p-6 relative flex flex-col items-center justify-center min-h-[500px]">
          {renderMode === "diagram" ? (
            <div className="relative w-full max-w-lg aspect-square flex items-center justify-center">
              {/* SVG Helmet Outline */}
              <svg viewBox="0 0 400 400" className="w-full h-full text-slate-800 fill-current">
                {/* Outer Dome */}
                <path
                  d="M 60 200 C 60 80, 340 80, 340 200 C 340 240, 320 270, 290 280 L 110 280 C 80 270, 60 240, 60 200 Z"
                  className="fill-slate-900 stroke-slate-700 stroke-2"
                />
                {/* Brim */}
                <path
                  d="M 40 200 Q 200 240 360 200 L 370 215 Q 200 260 30 215 Z"
                  className="fill-slate-800 stroke-slate-600 stroke-2"
                />
                {/* Front Visor */}
                <path
                  d="M 120 220 C 140 260, 260 260, 280 220 Z"
                  className="fill-cyan-950/40 stroke-cyan-500/50 stroke-1"
                />
                {/* PCB Base */}
                <rect x="130" y="160" width="140" height="40" rx="4" className="fill-emerald-950/60 stroke-emerald-500/60 stroke-1" />
              </svg>

              {/* Interactive Component Nodes over SVG */}
              {COMPONENTS_LIST.map((comp) => {
                const isSelected = comp.id === selectedCompId;
                const status = getComponentStatus(comp.id);

                return (
                  <motion.button
                    key={comp.id}
                    whileHover={{ scale: 1.15 }}
                    onClick={() => setSelectedCompId(comp.id)}
                    style={{ left: comp.posX, top: comp.posY }}
                    className={`absolute -translate-x-1/2 -translate-y-1/2 px-2.5 py-1 rounded-full font-mono text-[10px] font-bold flex items-center gap-1 border shadow-xl transition-all ${
                      isSelected ? "ring-2 ring-amber-500 border-amber-500 scale-110 z-20" : ""
                    } ${status.bg}`}
                  >
                    <span>{comp.icon}</span>
                    <span>{comp.shortName}</span>
                    <span
                      className="w-1.5 h-1.5 rounded-full"
                      style={{ background: status.color }}
                    />
                  </motion.button>
                );
              })}
            </div>
          ) : (
            <div className="relative w-full h-[450px]">
              <Suspense fallback={<div className="text-amber-500 font-mono text-sm">Loading 3D WebGL Scene...</div>}>
                <HelmetScene
                  onComponentClick={(id) => setSelectedCompId(id)}
                  activeEmergency={worker.safetyStatus === "CRITICAL"}
                  noiseCancel={worker.noiseCancel}
                />
              </Suspense>
              <DataPanel componentId={selectedCompId} onClose={() => {}} />
            </div>
          )}
        </div>

        {/* Selected Component Technical Detail Card */}
        <div className="lg:col-span-5 command-panel p-6 flex flex-col justify-between space-y-6">
          <div>
            {/* Component Header Badge */}
            <div className="flex items-center justify-between pb-4 border-b border-slate-800">
              <div className="flex items-center gap-3">
                <span className="text-3xl">{selectedComp.icon}</span>
                <div>
                  <h3 className="font-display font-bold text-white text-lg leading-tight">
                    {selectedComp.name}
                  </h3>
                  <p className="font-mono text-xs text-amber-500 mt-0.5">
                    Hardware ID: {selectedComp.id.toUpperCase()}
                  </p>
                </div>
              </div>
              <span
                className="font-mono text-xs font-bold px-3 py-1 rounded border"
                style={{
                  color: compStatus.color,
                  borderColor: compStatus.color,
                  background: `${compStatus.color}15`,
                }}
              >
                {compStatus.label}
              </span>
            </div>

            {/* Component Details */}
            <div className="py-4 space-y-4 font-mono text-xs">
              <div>
                <span className="text-slate-400 uppercase text-[10px] block">PURPOSE</span>
                <p className="text-white font-semibold text-sm mt-0.5">{selectedComp.purpose}</p>
              </div>

              <div>
                <span className="text-slate-400 uppercase text-[10px] block">CURRENT STATUS & SIMULATED VALUE</span>
                <div className="p-3 rounded bg-slate-900 border border-slate-800 text-amber-400 font-bold mt-1">
                  {getSimulatedValue(selectedComp.id)}
                </div>
              </div>

              <div>
                <span className="text-slate-400 uppercase text-[10px] block">SAFETY FUNCTION</span>
                <p className="text-slate-300 leading-relaxed text-xs mt-1">{selectedComp.safetyFunction}</p>
              </div>
            </div>
          </div>

          {/* Component Selection Grid */}
          <div className="pt-4 border-t border-slate-800">
            <span className="font-mono text-[10px] text-slate-400 uppercase block mb-2">
              Select Hardware Component (12 Total)
            </span>
            <div className="grid grid-cols-3 sm:grid-cols-4 gap-1.5 font-mono text-[10px]">
              {COMPONENTS_LIST.map((comp) => (
                <button
                  key={comp.id}
                  onClick={() => setSelectedCompId(comp.id)}
                  className={`p-1.5 rounded border text-left flex items-center gap-1 transition-all ${
                    comp.id === selectedCompId
                      ? "bg-amber-500 text-black font-bold border-amber-500"
                      : "bg-slate-900 text-slate-400 border-slate-800 hover:border-slate-700"
                  }`}
                >
                  <span>{comp.icon}</span>
                  <span className="truncate">{comp.shortName}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
