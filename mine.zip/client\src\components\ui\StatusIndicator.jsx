// client/src/components/ui/StatusIndicator.jsx
// Compact system status bar for the dashboard header

import React from "react";

function Dot({ color, glow, label, value }) {
  return (
    <div className="flex items-center gap-2">
      <div
        className="w-2 h-2 rounded-full flex-shrink-0"
        style={{
          background: color,
          boxShadow:  `0 0 6px ${glow || color}`,
        }}
      />
      <span className="text-[10px] font-mono text-white/30 uppercase tracking-wider">{label}</span>
      {value !== undefined && (
        <span className="text-[10px] font-mono font-semibold" style={{ color }}>
          {value}
        </span>
      )}
    </div>
  );
}

export default function StatusIndicator({ isConnected, workerCount, activeEmergency, systemStatus }) {
  const criticalCount = 0; // Will be wired to workers prop if needed

  return (
    <div className="flex items-center gap-6 flex-wrap">
      <Dot
        color={isConnected ? "#00e676" : "#ff1744"}
        label="Socket"
        value={isConnected ? "LIVE" : "OFFLINE"}
      />
      <Dot
        color="#00d4ff"
        label="Workers"
        value={workerCount}
      />
      <Dot
        color={activeEmergency ? "#ff1744" : "#00e676"}
        label="System"
        value={activeEmergency ? "ALERT" : "NOMINAL"}
      />
      <div className="flex items-center gap-2">
        <div className="h-3 w-px bg-white/10" />
        <span className="text-[10px] font-mono text-white/20">
          {new Date().toLocaleDateString()} · {new Date().toLocaleTimeString()}
        </span>
      </div>
    </div>
  );
}
