// client/src/views/SystemView.jsx
// System Architecture, Firmware & Hardware Specifications for MINO MINE

import React from "react";

export default function SystemView() {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="command-panel p-6 border-l-4 border-l-amber-500">
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="font-mono text-xs font-bold text-amber-500 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/30">
                MINO MINE
              </span>
              <span className="font-mono text-xs text-slate-400">
                UNDERGROUND MINING SAFETY SYSTEM
              </span>
            </div>
            <h1 className="font-display text-2xl font-black text-white">
              SYSTEM ARCHITECTURE & HARDWARE SPECS
            </h1>
          </div>
          <span className="font-mono text-xs px-3 py-1.5 rounded bg-slate-800 text-amber-400 border border-slate-700">
            DEMO / SIMULATION MODE
          </span>
        </div>
      </div>

      {/* System Tech Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 font-mono text-xs">
        <div className="command-panel p-6 space-y-3">
          <h3 className="font-display font-bold text-lg text-white">SIH 2026 Problem</h3>
          <p className="text-slate-400 leading-relaxed">
            <strong>Problem Statement ID:</strong> SIH26039<br />
            <strong>Title:</strong> Underground mine safety, monitoring and rescue<br />
            <strong>Theme:</strong> Smart Mining Safety & Worker Protection
          </p>
        </div>

        <div className="command-panel p-6 space-y-3">
          <h3 className="font-display font-bold text-lg text-white">MCU & Embedded OS</h3>
          <p className="text-slate-400 leading-relaxed">
            <strong>SoC:</strong> ESP32 Dual-Core Tensilica LX6 @ 240 MHz<br />
            <strong>OS:</strong> FreeRTOS Preemptive Multi-Tasking<br />
            <strong>ATEX Certification:</strong> Zone 0 Intrinsically Safe
          </p>
        </div>

        <div className="command-panel p-6 space-y-3">
          <h3 className="font-display font-bold text-lg text-white">Subterranean Wireless</h3>
          <p className="text-slate-400 leading-relaxed">
            <strong>Transceiver:</strong> Semtech SX1276 LoRa Sub-GHz<br />
            <strong>Frequency:</strong> 868 MHz / 915 MHz ISM Band<br />
            <strong>Range:</strong> Up to 5 km solid subterranean rock
          </p>
        </div>
      </div>

      {/* 12 Hardware Components Summary List */}
      <div className="command-panel p-6">
        <h3 className="font-display font-bold text-lg text-white mb-4">
          Complete 12-Hardware Sensor Architecture Suite
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 font-mono text-xs">
          <div className="p-4 rounded bg-slate-900 border border-slate-800">
            <span className="font-bold text-amber-500">1. ESP32 MCU</span>
            <p className="text-slate-400 text-[11px] mt-1">Dual-core Tensilica MCU & FreeRTOS real-time telemetry processing hub.</p>
          </div>
          <div className="p-4 rounded bg-slate-900 border border-slate-800">
            <span className="font-bold text-red-400">2. MAX30102 PPG</span>
            <p className="text-slate-400 text-[11px] mt-1">Pulse oximeter for continuous heart rate (BPM) and blood oxygen (SpO₂%).</p>
          </div>
          <div className="p-4 rounded bg-slate-900 border border-slate-800">
            <span className="font-bold text-amber-400">3. MPU6050 6-Axis IMU</span>
            <p className="text-slate-400 text-[11px] mt-1">Accelerometer & gyroscope fall detection and man-down posture orientation.</p>
          </div>
          <div className="p-4 rounded bg-slate-900 border border-slate-800">
            <span className="font-bold text-yellow-400">4. MQ Gas Array</span>
            <p className="text-slate-400 text-[11px] mt-1">Electrochemical methane (CH₄), CO, and H₂S toxic gas monitoring array.</p>
          </div>
          <div className="p-4 rounded bg-slate-900 border border-slate-800">
            <span className="font-bold text-red-500">5. IR Flame Sensor</span>
            <p className="text-slate-400 text-[11px] mt-1">760nm–1100nm infrared optical underground fire & explosion detector.</p>
          </div>
          <div className="p-4 rounded bg-slate-900 border border-slate-800">
            <span className="font-bold text-cyan-400">6. Temperature Sensor</span>
            <p className="text-slate-400 text-[11px] mt-1">Thermal probe for ambient subterranean heat and miner heat-stroke alerts.</p>
          </div>
          <div className="p-4 rounded bg-slate-900 border border-slate-800">
            <span className="font-bold text-emerald-400">7. GPS / GIS Beacon</span>
            <p className="text-slate-400 text-[11px] mt-1">Subterranean positioning beacon and shaft elevation depth tracker.</p>
          </div>
          <div className="p-4 rounded bg-slate-900 border border-slate-800">
            <span className="font-bold text-cyan-300">8. LoRa SX1276</span>
            <p className="text-slate-400 text-[11px] mt-1">Sub-GHz long-range radio transceiver for subterranean rock penetration.</p>
          </div>
          <div className="p-4 rounded bg-slate-900 border border-slate-800">
            <span className="font-bold text-yellow-300">9. LDR Light Sensor</span>
            <p className="text-slate-400 text-[11px] mt-1">Photoresistor measuring ambient light for headlamp auto-dimming.</p>
          </div>
          <div className="p-4 rounded bg-slate-900 border border-slate-800">
            <span className="font-bold text-white">10. Cree LED Headlamp</span>
            <p className="text-slate-400 text-[11px] mt-1">1000 lumen headlight + RGB safety status visual halo indicator.</p>
          </div>
          <div className="p-4 rounded bg-slate-900 border border-slate-800">
            <span className="font-bold text-pink-400">11. Vibration Motor</span>
            <p className="text-slate-400 text-[11px] mt-1">Intra-helmet haptic feedback actuator for immediate tactile alerts.</p>
          </div>
          <div className="p-4 rounded bg-slate-900 border border-slate-800">
            <span className="font-bold text-green-400">12. Li-Ion Battery & BMS</span>
            <p className="text-slate-400 text-[11px] mt-1">ATEX Zone 0 certified 4400 mAh power system with smart BMS.</p>
          </div>
        </div>
      </div>
    </div>
  );
}
