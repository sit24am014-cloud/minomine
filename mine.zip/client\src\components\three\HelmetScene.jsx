// client/src/components/three/HelmetScene.jsx
// Three.js scene: auto-rotate, OrbitControls, scroll explosion, raycasting

import React, { useEffect, useRef, useState, useCallback } from "react";
import * as THREE from "three";
import { OrbitControls } from "three/addons/controls/OrbitControls.js";
import { buildHelmet, buildLights } from "./HelmetGeometry";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

gsap.registerPlugin(ScrollTrigger);

// Lerp helper
const lerp = (a, b, t) => a + (b - a) * t;

export default function HelmetScene({ onComponentClick, activeEmergency, noiseCancel }) {
  const mountRef   = useRef(null);
  const sceneRef   = useRef({});
  const [labels, setLabels]   = useState([]);
  const [exploded, setExploded] = useState(false);

  const project3DTo2D = useCallback((vec3, camera, width, height) => {
    const v = vec3.clone().project(camera);
    return {
      x: (v.x * 0.5 + 0.5) * width,
      y: (-v.y * 0.5 + 0.5) * height,
    };
  }, []);

  useEffect(() => {
    const mount = mountRef.current;
    if (!mount) return;

    // ── Renderer ──────────────────────────────────────────────────────────
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setSize(mount.clientWidth, mount.clientHeight);
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type    = THREE.PCFSoftShadowMap;
    renderer.toneMapping       = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.2;
    mount.appendChild(renderer.domElement);

    // ── Scene & Camera ────────────────────────────────────────────────────
    const scene  = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(45, mount.clientWidth / mount.clientHeight, 0.1, 100);
    camera.position.set(0, 0.5, 4.5);

    // ── Lights ────────────────────────────────────────────────────────────
    buildLights(scene);

    // ── Background particles ──────────────────────────────────────────────
    const particleGeo = new THREE.BufferGeometry();
    const pCount = 800;
    const positions = new Float32Array(pCount * 3);
    for (let i = 0; i < pCount * 3; i++) positions[i] = (Math.random() - 0.5) * 20;
    particleGeo.setAttribute("position", new THREE.BufferAttribute(positions, 3));
    const particles = new THREE.Points(
      particleGeo,
      new THREE.PointsMaterial({ color: 0xff6600, size: 0.03, transparent: true, opacity: 0.4 })
    );
    scene.add(particles);

    // ── Helmet ────────────────────────────────────────────────────────────
    const { helmetGroup, shellGroup, internalParts, visorMesh } = buildHelmet();
    scene.add(helmetGroup);

    // Hide internal parts initially
    internalParts.forEach(p => {
      p.scale.setScalar(0);
      p.userData.originalPos = p.position.clone();
    });

    // ── OrbitControls ─────────────────────────────────────────────────────
    const controls = new OrbitControls(camera, renderer.domElement);
    controls.enableDamping     = true;
    controls.dampingFactor     = 0.08;
    controls.enableZoom        = true;
    controls.minDistance       = 2.5;
    controls.maxDistance       = 7;
    controls.enablePan         = false;
    controls.autoRotate        = true;
    controls.autoRotateSpeed   = 0.6;

    // Resume auto-rotate 2 s after user stops dragging
    let autoRotateTimer = null;
    controls.addEventListener("start", () => {
      controls.autoRotate = false;
      if (autoRotateTimer) clearTimeout(autoRotateTimer);
    });
    controls.addEventListener("end", () => {
      autoRotateTimer = setTimeout(() => { controls.autoRotate = true; }, 2000);
    });

    // ── Raycaster ─────────────────────────────────────────────────────────
    const raycaster = new THREE.Raycaster();
    const pointer   = new THREE.Vector2();
    let hoveredMesh = null;

    const onPointerMove = (e) => {
      const rect = mount.getBoundingClientRect();
      pointer.x = ((e.clientX - rect.left) / rect.width)  * 2 - 1;
      pointer.y = -((e.clientY - rect.top)  / rect.height) * 2 + 1;
    };
    const onPointerClick = (e) => {
      const rect = mount.getBoundingClientRect();
      pointer.x = ((e.clientX - rect.left) / rect.width)  * 2 - 1;
      pointer.y = -((e.clientY - rect.top)  / rect.height) * 2 + 1;
      raycaster.setFromCamera(pointer, camera);
      const hits = raycaster.intersectObjects(internalParts, true);
      if (hits.length > 0) {
        const obj = hits[0].object;
        const comp = obj.userData.componentId || obj.parent?.userData?.componentId;
        if (comp && onComponentClick) onComponentClick(comp);
      }
    };

    mount.addEventListener("pointermove", onPointerMove);
    mount.addEventListener("click", onPointerClick);

    // ── GSAP Scroll explosion ─────────────────────────────────────────────
    const scrollTrigger = ScrollTrigger.create({
      trigger:    "#hero-section",
      start:      "top top",
      end:        "+=800",
      scrub:      1.2,
      onUpdate:   (self) => {
        const p = self.progress;

        // Shell lifts up
        gsap.set(shellGroup.position, { y: p * 3.2 });

        // Internal parts scale in with stagger
        internalParts.forEach((part, idx) => {
          const delay   = idx * 0.1;
          const progress = Math.max(0, Math.min(1, (p - delay) / (1 - delay)));
          const scale    = THREE.MathUtils.lerp(0, 1, progress);
          part.scale.setScalar(scale);
        });

        if (p > 0.5 && !exploded) setExploded(true);
        if (p < 0.1 &&  exploded) setExploded(false);
      },
    });

    // ── Label update loop ─────────────────────────────────────────────────
    let frameId;
    let emergencyGlow = 0;

    const animate = () => {
      frameId = requestAnimationFrame(animate);
      controls.update();
      particles.rotation.y += 0.0003;

      // Emergency glow pulse
      if (sceneRef.current.isEmergency) {
        emergencyGlow = (emergencyGlow + 0.05) % (Math.PI * 2);
        const intensity = 0.5 + Math.sin(emergencyGlow) * 0.5;
        internalParts.forEach(p => {
          if (p.material?.emissiveIntensity !== undefined) {
            p.material.emissiveIntensity = intensity * 2;
          }
        });
      } else {
        // Normalize emissive back
        internalParts.forEach(p => {
          if (p.material?.emissiveIntensity !== undefined &&
              p.material.emissiveIntensity > 1) {
            p.material.emissiveIntensity = lerp(p.material.emissiveIntensity, 0.8, 0.05);
          }
        });
      }

      // Hover detection on internal parts
      raycaster.setFromCamera(pointer, camera);
      const hits = raycaster.intersectObjects(internalParts, true);
      const hit  = hits.length > 0 ? hits[0].object : null;

      if (hoveredMesh && hoveredMesh !== hit) {
        // Reset previous hover glow
        const mat = hoveredMesh.material || hoveredMesh.parent?.material;
        if (mat?.emissiveIntensity !== undefined) mat.emissiveIntensity = 0.8;
        hoveredMesh = null;
        mount.style.cursor = "default";
      }
      if (hit) {
        const compId = hit.userData.componentId || hit.parent?.userData?.componentId;
        if (compId) {
          if (hit.material?.emissiveIntensity !== undefined) hit.material.emissiveIntensity = 2.5;
          hoveredMesh = hit;
          mount.style.cursor = "pointer";
        }
      }

      // Noise cancellation visor glow
      if (visorMesh?.material) {
        const targetOpacity = sceneRef.current.noiseCancel ? 0.4 : 0.15;
        visorMesh.material.opacity = lerp(visorMesh.material.opacity, targetOpacity, 0.05);
        const targetColor = sceneRef.current.noiseCancel ? new THREE.Color(0x00aaff) : new THREE.Color(0x334455);
        visorMesh.material.color.lerp(targetColor, 0.05);
      }

      // Update 2D label positions
      const w = mount.clientWidth;
      const h = mount.clientHeight;
      const newLabels = internalParts
        .filter(p => p.scale.x > 0.5 && p.userData.label)
        .map(p => {
          const worldPos = new THREE.Vector3();
          p.getWorldPosition(worldPos);
          const screen = project3DTo2D(worldPos, camera, w, h);
          return { id: p.userData.componentId, label: p.userData.label, ...screen };
        });
      setLabels(newLabels);

      renderer.render(scene, camera);
    };
    animate();

    // ── Resize handler ────────────────────────────────────────────────────
    const onResize = () => {
      if (!mount) return;
      camera.aspect = mount.clientWidth / mount.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(mount.clientWidth, mount.clientHeight);
    };
    window.addEventListener("resize", onResize);

    // Store refs for external updates
    sceneRef.current = {
      renderer, scene, camera, controls,
      helmetGroup, shellGroup, internalParts,
      isEmergency: activeEmergency,
      noiseCancel: noiseCancel,
    };

    return () => {
      cancelAnimationFrame(frameId);
      scrollTrigger.kill();
      window.removeEventListener("resize", onResize);
      mount.removeEventListener("pointermove", onPointerMove);
      mount.removeEventListener("click", onPointerClick);
      // Dispose Three.js objects
      internalParts.forEach(p => {
        p.geometry?.dispose();
        if (Array.isArray(p.material)) p.material.forEach(m => m.dispose());
        else p.material?.dispose();
      });
      renderer.dispose();
      if (mount.contains(renderer.domElement)) mount.removeChild(renderer.domElement);
    };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Sync external state into the animation loop via ref
  useEffect(() => {
    if (sceneRef.current) sceneRef.current.isEmergency = activeEmergency;
  }, [activeEmergency]);

  useEffect(() => {
    if (sceneRef.current) sceneRef.current.noiseCancel = noiseCancel;
  }, [noiseCancel]);

  return (
    <div ref={mountRef} className="relative w-full h-full" style={{ cursor: "grab" }}>
      {/* 2D labels projected over 3D positions */}
      {labels.map(l => (
        <div
          key={l.id}
          className="component-label"
          style={{ left: l.x, top: l.y, opacity: exploded ? 1 : 0 }}
        >
          {l.label}
        </div>
      ))}
    </div>
  );
}
