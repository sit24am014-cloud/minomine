// client/src/components/ui/SubterraneanZoneMap.jsx
// Interactive Subterranean Mine Shaft Floorplan and GIS Beacon Tracker

import React, { useState } from "react";
import { motion } from "framer-motion";
import { useMinoMine } from "../../context/MinoMineContext";

const ZONES = [
  { id: "Zone A", name: "Zone A – Main Shaft & Ventilation", depth: "400m - 480m", color: "#ff6b00" },
  { id: "Zone B", name: "Zone B – East Tunnel & Deep Shaft", depth: "520m - 720m", color: "#00d4ff" },
  { id: "Zone C", name: "Zone C – Blast Chamber & Explosives", depth: "580m - 610m", color: "#ffd700" },
  { id: "Zone D", name: "Zone D – Ore Processing & Refuge", depth: "320m - 390m", color: "#00e676" },
];

export default function SubterraneanZoneMap() {
  const { workers, selectedWorkerId, setSelectedWorkerId } = useMinoMine();
  const [activeZoneFilter, setActiveZoneFilter] = useState("ALL");

  const filteredWorkers = workers.filter(
    (w) => activeZoneFilter === "ALL" || w.zone.startsWith(activeZoneFilter)
  );

  return (
    <div className="glass rounded-2xl p-6 mb-8 border border-white/10 relative overflow-hidden">
      {/* Background Grid Pattern */}
      <div
        className="absolute inset-0 bg-grid-dark opacity-40 pointer-events-none"
        style={{ backgroundSize: "24px 24px" }}
      />

      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-4 mb-6 relative z-10">
        <div>
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-mine-neon animate-ping" />
            <span className="text-[10px] font-mono text-mine-neon uppercase tracking-widest">
              LoRa Mesh GIS / Subterranean Positioning System
            </span>
          </div>
          <h3 className="font-display font-bold text-white text-xl mt-1">
            Underground Shaft & Tunnel Map
          </h3>
        </div>

        {/* Zone Selector Pills */}
        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={() => setActiveZoneFilter("ALL")}
            className={`text-[10px] font-mono px-3 py-1.5 rounded-full border transition-all ${
              activeZoneFilter === "ALL"
                ? "bg-mine-neon/20 border-mine-neon text-mine-neon font-bold"
                : "border-white/10 text-white/40 hover:text-white"
            }`}
          >
            ALL ZONES (12 WORKERS)
          </button>
          {ZONES.map((z) => (
            <button
              key={z.id}
              onClick={() => setActiveZoneFilter(z.id)}
              className={`text-[10px] font-mono px-3 py-1.5 rounded-full border transition-all ${
                activeZoneFilter === z.id
                  ? "bg-white/15 border-white/40 text-white font-bold"
                  : "border-white/10 text-white/40 hover:text-white"
              }`}
            >
              {z.id}
            </button>
          ))}
        </div>
      </div>

      {/* Interactive Mine Shaft Canvas Grid */}
      <div className="relative w-full h-80 bg-black/50 rounded-xl border border-white/10 p-4 overflow-hidden flex flex-col justify-between">
        {/* Zone Banners / Corridors */}
        <div className="grid grid-cols-4 gap-3 h-full relative">
          {ZONES.map((zone) => {
            const zoneWorkers = workers.filter((w) => w.zone.startsWith(zone.id));
            const hasHazard = zoneWorkers.some((w) => w.safetyStatus === "CRITICAL");

            return (
              <div
                key={zone.id}
                className={`relative rounded-lg p-3 border transition-colors flex flex-col justify-between ${
                  hasHazard
                    ? "bg-red-950/20 border-red-500/50 shadow-[0_0_15px_rgba(255,23,68,0.2)]"
                    : "bg-white/[0.02] border-white/10"
                }`}
              >
                <div>
                  <div className="flex items-center justify-between">
                    <span
                      className="font-mono text-xs font-bold"
                      style={{ color: zone.color }}
                    >
                      {zone.id}
                    </span>
                    <span className="font-mono text-[9px] text-white/30">{zone.depth}</span>
                  </div>
                  <p className="font-display text-[11px] text-white/70 font-medium mt-0.5 line-clamp-1">
                    {zone.name.split("–")[1]?.trim()}
                  </p>
                </div>

                {/* Worker Position Dots in Corridor */}
                <div className="flex flex-wrap gap-2 mt-4 z-10">
                  {zoneWorkers.map((w) => {
                    const isSelected = selectedWorkerId === w.id;
                    const statusColor =
                      w.safetyStatus === "CRITICAL"
                        ? "#ff1744"
                        : w.safetyStatus === "WARNING"
                        ? "#ffab00"
                        : w.safetyStatus === "OFFLINE"
                        ? "#666"
                        : "#00e676";

                    return (
                      <motion.button
                        key={w.id}
                        whileHover={{ scale: 1.15 }}
                        onClick={() => setSelectedWorkerId(w.id)}
                        className={`relative rounded-md px-2 py-1 text-[10px] font-mono font-bold flex items-center gap-1 border transition-all ${
                          isSelected ? "ring-2 ring-mine-neon border-mine-neon z-20" : ""
                        }`}
                        style={{
                          background: `${statusColor}22`,
                          borderColor: statusColor,
                          color: statusColor,
                        }}
                      >
                        <span
                          className="w-1.5 h-1.5 rounded-full"
                          style={{
                            background: statusColor,
                            boxShadow: w.safetyStatus === "CRITICAL" ? "0 0 8px #ff1744" : "none",
                          }}
                        />
                        <span>{w.id}</span>
                        {w.fallDetected && <span>🤸</span>}
                        {w.fireDetected && <span>🔥</span>}
                        {w.gasLevel > 180 && <span>☁️</span>}
                      </motion.button>
                    );
                  })}
                </div>

                {/* Subterranean Level Markings */}
                <div className="mt-auto pt-2 border-t border-white/5 flex items-center justify-between text-[9px] font-mono text-white/20">
                  <span>GPS: {zoneWorkers[0]?.latitude.toFixed(4) || "23.7950"} N</span>
                  <span>{zoneWorkers.length} Miners</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Map Legend */}
      <div className="mt-4 flex items-center justify-between flex-wrap text-[10px] font-mono text-white/40">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-mine-safe" /> SAFE
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-mine-warn" /> WARNING
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-mine-danger animate-ping" /> CRITICAL / EMERGENCY
          </div>
          <div className="flex items-center gap-1.5">
            <span className="w-2 h-2 rounded-full bg-gray-500" /> OFFLINE
          </div>
        </div>
        <div>LoRa Telemetry Refresh: Real-time (200ms)</div>
      </div>
    </div>
  );
}
