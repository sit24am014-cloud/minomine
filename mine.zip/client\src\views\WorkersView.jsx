// client/src/views/WorkersView.jsx
// Detailed Worker Management & Hardware Telemetry List for MINO MINE

import React, { useState } from "react";
import { useMinoMine } from "../context/MinoMineContext";
import WorkerCard from "../components/ui/WorkerCard";
import HardwareDiagnosticModal from "../components/ui/HardwareDiagnosticModal";

export default function WorkersView() {
  const { workers, filterZone, setFilterZone, filterStatus, setFilterStatus, setSelectedWorkerId } = useMinoMine();
  const [searchTerm, setSearchTerm] = useState("");
  const [viewMode, setViewMode] = useState("grid"); // "grid" | "table"

  const filtered = workers.filter((w) => {
    const matchesSearch =
      w.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      w.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      w.zone.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesZone = filterZone === "ALL" || w.zone.startsWith(filterZone);
    const matchesStatus = filterStatus === "ALL" || w.safetyStatus === filterStatus;
    return matchesSearch && matchesZone && matchesStatus;
  });

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="command-panel p-6 border-l-4 border-l-amber-500">
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="font-mono text-xs font-bold text-amber-500 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/30">
                MINO MINE
              </span>
              <span className="font-mono text-xs text-slate-400">
                UNDERGROUND MINING SAFETY SYSTEM
              </span>
            </div>
            <h1 className="font-display text-2xl font-black text-white">
              UNDERGROUND WORKER MONITORING
            </h1>
          </div>
          <span className="font-mono text-xs px-3 py-1.5 rounded bg-slate-800 text-amber-400 border border-slate-700">
            DEMO / SIMULATION MODE
          </span>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="command-panel p-4 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3 flex-1 min-w-[240px]">
          <input
            type="text"
            placeholder="Search worker ID, name, or shaft zone..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-2 text-xs font-mono text-white focus:outline-none focus:border-amber-500"
          />
        </div>

        <div className="flex items-center gap-2">
          <select
            value={filterZone}
            onChange={(e) => setFilterZone(e.target.value)}
            className="bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs font-mono text-slate-300"
          >
            <option value="ALL">All Mine Zones</option>
            <option value="Zone A">Zone A (Main Shaft)</option>
            <option value="Zone B">Zone B (East Tunnel)</option>
            <option value="Zone C">Zone C (Blast Chamber)</option>
            <option value="Zone D">Zone D (Ore Processing)</option>
          </select>

          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-xs font-mono text-slate-300"
          >
            <option value="ALL">All Safety Statuses</option>
            <option value="SAFE">SAFE (Nominal)</option>
            <option value="WARNING">WARNING</option>
            <option value="CRITICAL">CRITICAL</option>
            <option value="OFFLINE">OFFLINE</option>
          </select>

          <div className="flex items-center border border-slate-700 rounded-lg overflow-hidden">
            <button
              onClick={() => setViewMode("grid")}
              className={`px-3 py-2 text-xs font-mono ${
                viewMode === "grid" ? "bg-amber-500 text-black font-bold" : "bg-slate-900 text-slate-400"
              }`}
            >
              GRID
            </button>
            <button
              onClick={() => setViewMode("table")}
              className={`px-3 py-2 text-xs font-mono ${
                viewMode === "table" ? "bg-amber-500 text-black font-bold" : "bg-slate-900 text-slate-400"
              }`}
            >
              TABLE
            </button>
          </div>
        </div>
      </div>

      {/* Grid or Table Display */}
      {viewMode === "grid" ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
          {filtered.map((worker) => (
            <WorkerCard key={worker.id} worker={worker} />
          ))}
        </div>
      ) : (
        <div className="command-panel overflow-x-auto">
          <table className="w-full text-left font-mono text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-800 text-slate-400 bg-slate-900/60">
                <th className="p-3">ID</th>
                <th className="p-3">WORKER NAME</th>
                <th className="p-3">ZONE & DEPTH</th>
                <th className="p-3">SAFETY STATUS</th>
                <th className="p-3">HEART RATE</th>
                <th className="p-3">BLOOD PRESSURE</th>
                <th className="p-3">GAS LEVEL</th>
                <th className="p-3">TEMP</th>
                <th className="p-3">BATTERY</th>
                <th className="p-3">ACTIONS</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-300">
              {filtered.map((w) => (
                <tr key={w.id} className="hover:bg-slate-800/30 transition-colors">
                  <td className="p-3 font-bold text-amber-500">{w.id}</td>
                  <td className="p-3 font-semibold text-white">{w.name}</td>
                  <td className="p-3">{w.zone} ({w.depthMeters}m)</td>
                  <td className="p-3">
                    <span
                      className={`px-2 py-0.5 rounded text-[10px] font-bold border ${
                        w.safetyStatus === "CRITICAL"
                          ? "bg-red-500/20 text-red-400 border-red-500/40"
                          : w.safetyStatus === "WARNING"
                          ? "bg-amber-500/20 text-amber-400 border-amber-500/40"
                          : w.safetyStatus === "OFFLINE"
                          ? "bg-slate-700 text-slate-400 border-slate-600"
                          : "bg-emerald-500/20 text-emerald-400 border-emerald-500/40"
                      }`}
                    >
                      {w.safetyStatus}
                    </span>
                  </td>
                  <td className="p-3 font-bold">{w.heartRate} BPM</td>
                  <td className="p-3">{w.systolicBP}/{w.diastolicBP} mmHg</td>
                  <td className="p-3">{w.gasLevel} PPM</td>
                  <td className="p-3">{w.temperature} °C</td>
                  <td className="p-3">{w.battery}%</td>
                  <td className="p-3">
                    <button
                      onClick={() => setSelectedWorkerId(w.id)}
                      className="px-2 py-1 bg-amber-500/10 text-amber-400 border border-amber-500/30 rounded hover:bg-amber-500/20 transition-colors text-[10px]"
                    >
                      DIAGNOSTICS
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Hardware Diagnostic Modal rendered at root level in App.jsx */}
    </div>
  );
}
