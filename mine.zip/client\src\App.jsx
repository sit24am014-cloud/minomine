// client/src/App.jsx
// Premium Industrial Command Center Interface for MINO MINE (SIH 2026)

import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { MinoMineProvider, useMinoMine } from "./context/MinoMineContext";

// View Components
import HomeView from "./views/HomeView";
import SmartHelmetView from "./views/SmartHelmetView";
import ControlRoomView from "./views/ControlRoomView";
import WorkersView from "./views/WorkersView";
import EmergencyCenterView from "./views/EmergencyCenterView";
import NetworkView from "./views/NetworkView";
import IncidentHistoryView from "./views/IncidentHistoryView";
import SensorSimulatorView from "./views/SensorSimulatorView";
import SystemView from "./views/SystemView";
import MobileWorkerView from "./views/MobileWorkerView";
import LiveDemoView from "./views/LiveDemoView";
import HardwareDiagnosticModal from "./components/ui/HardwareDiagnosticModal";

const NAV_TABS = [
  "CONTROL ROOM",
  "LIVE DEMO",
  "SMART HELMET",
  "WORKERS",
  "EMERGENCY CENTER",
  "SENSOR SIMULATOR",
  "NETWORK",
  "INCIDENT HISTORY",
  "SYSTEM",
];

function MainCommandCenter() {
  const { activeEmergency, incidents, deviceMode, setDeviceMode, communicationState } = useMinoMine();
  const [activeTab, setActiveTab] = useState("CONTROL ROOM");

  const socketConnected = communicationState?.socketConnected ?? true;
  const activeIncidentsCount = incidents.filter((i) => i.status !== "RESOLVED").length;

  return (
    <div className="min-h-screen bg-[#07090e] text-slate-100 font-sans flex flex-col selection:bg-amber-500 selection:text-black">
      {/* Global Emergency Alert Overlay */}
      <AnimatePresence>
        {activeEmergency && <div className="emergency-overlay" />}
      </AnimatePresence>

      {/* Top Connection Offline Alert Banner */}
      {!socketConnected && (
        <div className="bg-red-600 text-white font-mono font-black text-center py-2 px-4 text-xs tracking-wider uppercase animate-pulse shadow-lg z-50">
          ⚠️ CONNECTION OFFLINE — SUBTERRANEAN LORA TELEMETRY SERVER UNREACHABLE
        </div>
      )}

      {/* Top Header Bar */}
      <header className="bg-[#0f172a] border-b border-slate-800 px-4 md:px-8 py-2.5 flex items-center justify-between text-xs font-mono select-none sticky top-0 z-50 shadow-xl">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded bg-amber-500 text-black font-black flex items-center justify-center font-display text-xs shadow-[0_0_12px_rgba(245,158,11,0.5)]">
              M
            </div>
            <div>
              <span className="font-bold text-white tracking-widest text-sm block leading-none">MINO MINE</span>
              <span className="text-[9px] text-amber-500 font-bold tracking-wider">SIH 2026 (PS: SIH26039)</span>
            </div>
          </div>

          <div className="hidden lg:flex items-center gap-4 border-l border-slate-700 pl-4 text-slate-400">
            <span className="flex items-center gap-1.5">
              <span className={`w-2 h-2 rounded-full ${socketConnected ? "bg-emerald-500 pulse-safe" : "bg-red-500 animate-ping"}`} />
              SYSTEM STATUS:{" "}
              {socketConnected ? (
                <strong className="text-emerald-400">ONLINE</strong>
              ) : (
                <strong className="text-red-500 uppercase font-black">CONNECTION OFFLINE</strong>
              )}
            </span>

            <span className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-amber-500" />
              LOOP: <strong className="text-amber-400">SIMULATION</strong>
            </span>

            <span className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-cyan-500" />
              NETWORK: <strong className="text-cyan-400">LoRa REALTIME</strong>
            </span>
          </div>
        </div>

        {/* Prominent START LIVE DEMO & DEVICE MODE Switcher */}
        <div className="flex items-center gap-3">
          <button
            onClick={() => {
              setDeviceMode("CONTROL ROOM");
              setActiveTab("LIVE DEMO");
            }}
            className="px-4 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-black font-mono font-bold text-xs tracking-wider shadow-[0_0_15px_rgba(245,158,11,0.4)] animate-pulse transition-all"
          >
            ▶ START LIVE DEMO
          </button>

          <div className="hidden sm:flex items-center border border-slate-700 rounded-lg overflow-hidden bg-slate-900 font-mono text-xs">
            <button
              onClick={() => {
                setDeviceMode("CONTROL ROOM");
                setActiveTab("CONTROL ROOM");
              }}
              className={`px-3 py-1.5 font-bold transition-all ${
                deviceMode === "CONTROL ROOM" && activeTab !== "LIVE DEMO"
                  ? "bg-amber-500 text-black font-bold shadow-md"
                  : "text-slate-300 hover:text-white"
              }`}
            >
              💻 CONTROL ROOM
            </button>

            <button
              onClick={() => setDeviceMode("WORKER PHONE")}
              className={`px-3 py-1.5 font-bold transition-all ${
                deviceMode === "WORKER PHONE"
                  ? "bg-amber-500 text-black font-bold shadow-md"
                  : "text-slate-300 hover:text-white"
              }`}
            >
              📱 WORKER PHONE
            </button>

            <button
              onClick={() => {
                setDeviceMode("SIMULATOR");
                setActiveTab("SENSOR SIMULATOR");
              }}
              className={`px-3 py-1.5 font-bold transition-all ${
                deviceMode === "SIMULATOR"
                  ? "bg-amber-500 text-black font-bold shadow-md"
                  : "text-slate-300 hover:text-white"
              }`}
            >
              ⚡ SIMULATOR
            </button>
          </div>
        </div>
      </header>

      {/* Subterranean Data Flow Architecture Bar */}
      <div className="bg-[#0a0e18] border-b border-slate-800/80 px-4 md:px-8 py-1.5 font-mono text-[10px] text-slate-400 flex items-center justify-between overflow-x-auto scrollbar-none">
        <div className="flex items-center gap-2 min-w-max">
          <span className="text-amber-500 font-bold">REAL-TIME DATA FLOW:</span>
          <span className="text-slate-300 font-bold">SENSOR SIMULATOR</span>
          <span>→</span>
          <span className="text-red-400 font-bold">EMERGENCY</span>
          <span>→</span>
          <span className="text-cyan-400 font-bold">LoRa MESH NETWORK</span>
          <span>→</span>
          <span className="text-amber-400 font-bold">CONTROL ROOM</span>
          <span>→</span>
          <span className="text-emerald-400 font-bold">WORKER PHONE</span>
        </div>
        <div className="hidden md:block text-slate-500 font-semibold">
          UNDERGROUND MINING SAFETY SYSTEM · DEMO MODE · SIMULATED SENSOR DATA
        </div>
      </div>

      {/* Primary Navigation Tabs */}
      {deviceMode === "CONTROL ROOM" && (
        <nav className="bg-[#0b0f19] border-b border-slate-800/80 px-4 md:px-8 py-2 overflow-x-auto scrollbar-none">
          <div className="flex items-center gap-1 min-w-max">
            {NAV_TABS.map((tab) => {
              const isActive = activeTab === tab;
              const hasBadge = tab === "EMERGENCY CENTER" && activeIncidentsCount > 0;

              return (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={`px-3.5 py-1.5 rounded-md font-mono text-xs font-semibold tracking-wider transition-all relative ${
                    isActive
                      ? "bg-amber-500/15 text-amber-400 border border-amber-500/40"
                      : "text-slate-400 hover:text-white hover:bg-slate-800/50"
                  }`}
                >
                  <span>{tab}</span>
                  {hasBadge && (
                    <span className="ml-1.5 px-1.5 py-0.2 rounded-full bg-red-500 text-white font-bold text-[9px] animate-pulse">
                      {activeIncidentsCount}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </nav>
      )}

      {/* Main Content View Container */}
      <main className="flex-1 p-4 md:p-8 max-w-7xl w-full mx-auto">
        {deviceMode === "WORKER PHONE" ? (
          <MobileWorkerView />
        ) : deviceMode === "SIMULATOR" ? (
          <SensorSimulatorView />
        ) : (
          <>
            {activeTab === "HOME" && <HomeView onNavigate={(t) => setActiveTab(t)} />}
            {activeTab === "LIVE DEMO" && <LiveDemoView />}
            {activeTab === "SMART HELMET" && <SmartHelmetView />}
            {activeTab === "CONTROL ROOM" && <ControlRoomView />}
            {activeTab === "WORKERS" && <WorkersView />}
            {activeTab === "EMERGENCY CENTER" && <EmergencyCenterView />}
            {activeTab === "SENSOR SIMULATOR" && <SensorSimulatorView />}
            {activeTab === "NETWORK" && <NetworkView />}
            {activeTab === "INCIDENT HISTORY" && <IncidentHistoryView />}
            {activeTab === "SYSTEM" && <SystemView />}
          </>
        )}
      </main>

      {/* Global Hardware Diagnostic Modal (Root Instance) */}
      <HardwareDiagnosticModal />

      {/* Footer */}
      <footer className="border-t border-slate-800/80 bg-[#07090e] px-8 py-4 text-center font-mono text-[10px] text-slate-500 flex flex-wrap items-center justify-between gap-2">
        <div>
          MINO MINE · UNDERGROUND MINING SAFETY SYSTEM · SIH 2026 (PS: SIH26039)
        </div>
        <div>
          DEMO MODE · SIMULATED SENSOR DATA · Multi-Device Sync Engine
        </div>
      </footer>
    </div>
  );
}

export default function App() {
  return (
    <MinoMineProvider>
      <MainCommandCenter />
    </MinoMineProvider>
  );
}
