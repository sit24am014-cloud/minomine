// client/src/views/EmergencyCenterView.jsx
// High-Priority Subterranean Emergency Command Interface for MINO MINE

import React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useMinoMine } from "../context/MinoMineContext";

const SEVERITY_BADGES = {
  CRITICAL: "bg-red-500 text-white font-black border-red-400 animate-pulse",
  HIGH: "bg-orange-500 text-black font-bold border-orange-400",
  MEDIUM: "bg-amber-500 text-black font-bold border-amber-400",
  LOW: "bg-slate-700 text-slate-300 border-slate-600",
};

const EMERGENCY_ICONS = {
  FALL: "🤸",
  FIRE: "🔥",
  GAS_LEAK: "☁️",
  MEDICAL: "🚑",
  HIGH_TEMPERATURE: "🌡️",
  ABNORMAL_HEART_RATE: "❤️",
  MISSING_WORKER: "📡",
  MANUAL_EMERGENCY: "🚨",
};

export default function EmergencyCenterView() {
  const {
    workers,
    incidents,
    acknowledgeIncident,
    dispatchResponse,
    callWorker,
    evacuateArea,
    resolveIncident,
    clearAllEmergencies,
    activeCallWorkerId,
    evacuatedZones,
  } = useMinoMine();

  const activeIncidents = incidents.filter((i) => i.status !== "RESOLVED");
  const resolvedIncidents = incidents.filter((i) => i.status === "RESOLVED");

  return (
    <div className="space-y-6">
      {/* Required Page Header */}
      <div className="command-panel p-6 border-l-4 border-l-red-500">
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="font-mono text-xs font-bold text-red-500 bg-red-500/10 px-2 py-0.5 rounded border border-red-500/30">
                MINO MINE
              </span>
              <span className="font-mono text-xs text-slate-400">
                UNDERGROUND MINING SAFETY SYSTEM
              </span>
            </div>
            <h1 className="font-display text-2xl font-black text-white">
              HIGH-PRIORITY EMERGENCY COMMAND CENTER
            </h1>
          </div>
          <div className="flex items-center gap-3">
            <span className="font-mono text-xs px-3 py-1.5 rounded bg-slate-800 text-amber-400 border border-slate-700">
              DEMO / SIMULATION MODE
            </span>
            {activeIncidents.length > 0 && (
              <button
                onClick={clearAllEmergencies}
                className="font-mono text-xs font-bold px-4 py-2 rounded bg-emerald-500 text-black hover:bg-emerald-400 transition-colors shadow-lg"
              >
                RESET ALL EMERGENCIES
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Active Emergencies Section */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 font-mono">
            <span className="w-3 h-3 rounded-full bg-red-500 animate-ping" />
            <h3 className="font-display font-bold text-white text-lg">
              ACTIVE EMERGENCIES ({activeIncidents.length})
            </h3>
          </div>
          <span className="font-mono text-xs text-slate-400">
            Real-Time Telemetry Incident Stream
          </span>
        </div>

        {activeIncidents.length === 0 ? (
          <div className="command-panel p-8 text-center font-mono text-xs text-slate-500">
            ✓ No active emergency incidents. System operating under nominal safety conditions.
          </div>
        ) : (
          <div className="space-y-4">
            <AnimatePresence>
              {activeIncidents.map((inc) => {
                const targetWorker = workers.find((w) => w.id === inc.workerId) || {};
                const icon = EMERGENCY_ICONS[inc.type] || "⚠️";
                const isAck = inc.acknowledgementStatus === "ACKNOWLEDGED";
                const isDispatched = inc.responseDispatched;
                const isCalling = activeCallWorkerId === inc.workerId;
                const isEvacuated = evacuatedZones.includes(inc.location.split("(")[0].trim());

                return (
                  <motion.div
                    key={inc.id}
                    initial={{ opacity: 0, y: 15 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, height: 0 }}
                    className={`command-panel p-6 border-2 transition-all shadow-xl font-mono ${
                      inc.severity === "CRITICAL"
                        ? "border-red-500 bg-red-950/30 shadow-[0_0_25px_rgba(239,68,68,0.25)] animate-pulse"
                        : "border-amber-500 bg-amber-950/20"
                    }`}
                  >
                    {/* Header Row */}
                    <div className="flex items-start justify-between pb-3 border-b border-slate-800 flex-wrap gap-2">
                      <div className="flex items-center gap-3">
                        <span className="text-3xl">{icon}</span>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-white text-sm">{inc.id}</span>
                            <span
                              className={`text-[9px] px-2 py-0.5 rounded border uppercase ${
                                SEVERITY_BADGES[inc.severity] || SEVERITY_BADGES.MEDIUM
                              }`}
                            >
                              {inc.severity} SEVERITY
                            </span>
                            <span className="text-[10px] text-slate-400">
                              {new Date(inc.timestamp).toLocaleTimeString()}
                            </span>
                          </div>
                          <h4 className="font-display font-black text-amber-400 text-lg mt-0.5">
                            {inc.type} — WORKER {inc.workerId} ({inc.workerName})
                          </h4>
                        </div>
                      </div>

                      <div className="text-right text-xs">
                        <span className="text-slate-400 block">ACK STATUS</span>
                        <span
                          className={`font-bold ${
                            isAck ? "text-emerald-400" : "text-red-400 animate-pulse"
                          }`}
                        >
                          {isAck ? "✓ ACKNOWLEDGED" : "UNACKNOWLEDGED"}
                        </span>
                      </div>
                    </div>

                    {/* Vitals Snapshot Grid */}
                    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-3 my-4 text-xs">
                      <div className="bg-slate-900/80 p-2.5 rounded border border-slate-800">
                        <span className="text-[9px] text-slate-500 block">LOCATION</span>
                        <span className="font-bold text-white text-[11px] truncate block">
                          {inc.location}
                        </span>
                      </div>

                      <div className="bg-slate-900/80 p-2.5 rounded border border-slate-800">
                        <span className="text-[9px] text-slate-500 block">HEART RATE</span>
                        <span className={`font-bold ${inc.sensorValues.heartRate > 125 ? "text-red-400" : "text-white"}`}>
                          {inc.sensorValues.heartRate} BPM
                        </span>
                      </div>

                      <div className="bg-slate-900/80 p-2.5 rounded border border-slate-800">
                        <span className="text-[9px] text-slate-500 block">TEMPERATURE</span>
                        <span className={`font-bold ${inc.sensorValues.temperature >= 38.5 ? "text-red-400" : "text-white"}`}>
                          {inc.sensorValues.temperature} °C
                        </span>
                      </div>

                      <div className="bg-slate-900/80 p-2.5 rounded border border-slate-800">
                        <span className="text-[9px] text-slate-500 block">GAS LEVEL</span>
                        <span className={`font-bold ${inc.sensorValues.gasLevel > 180 ? "text-red-400" : "text-white"}`}>
                          {inc.sensorValues.gasLevel} PPM
                        </span>
                      </div>

                      <div className="bg-slate-900/80 p-2.5 rounded border border-slate-800">
                        <span className="text-[9px] text-slate-500 block">COMMUNICATION</span>
                        <span className="font-bold text-emerald-400">
                          {targetWorker.communicationStatus || "ONLINE"}
                        </span>
                      </div>

                      <div className="bg-slate-900/80 p-2.5 rounded border border-slate-800">
                        <span className="text-[9px] text-slate-500 block">BATTERY</span>
                        <span className="font-bold text-white">
                          {inc.sensorValues.battery}%
                        </span>
                      </div>
                    </div>

                    {/* Active Voice Call / Evacuation Banner Notifications */}
                    {isCalling && (
                      <div className="mb-4 p-3 rounded bg-cyan-950/60 border border-cyan-500 text-cyan-300 text-xs flex items-center justify-between font-mono animate-pulse">
                        <span>📞 LIVE LORA VOICE CHANNEL ACTIVE: CONNECTED TO HELMET {inc.workerId}</span>
                        <button
                          onClick={() => callWorker(inc.workerId)}
                          className="px-2 py-0.5 bg-cyan-500 text-black font-bold rounded"
                        >
                          END CALL
                        </button>
                      </div>
                    )}

                    {isEvacuated && (
                      <div className="mb-4 p-3 rounded bg-red-950/80 border border-red-500 text-red-300 text-xs font-mono font-bold flex items-center gap-2">
                        <span>🚨 ZONE SIREN SIREN BROADCAST: AREA EVACUATION ORDER IN PROGRESS</span>
                      </div>
                    )}

                    {/* Emergency Command Action Buttons */}
                    <div className="pt-3 border-t border-slate-800 flex items-center justify-between flex-wrap gap-2 text-xs">
                      <div className="flex items-center gap-2 flex-wrap">
                        {/* 1. ACKNOWLEDGE */}
                        <button
                          onClick={() => acknowledgeIncident(inc.id)}
                          className={`px-3 py-1.5 rounded font-bold border transition-all ${
                            isAck
                              ? "bg-slate-800 text-slate-400 border-slate-700"
                              : "bg-amber-500 text-black border-amber-400 hover:bg-amber-400"
                          }`}
                        >
                          {isAck ? "✓ ACKNOWLEDGED" : "ACKNOWLEDGE"}
                        </button>

                        {/* 2. DISPATCH RESPONSE */}
                        <button
                          onClick={() => dispatchResponse(inc.id)}
                          className={`px-3 py-1.5 rounded font-bold border transition-all ${
                            isDispatched
                              ? "bg-emerald-500/20 text-emerald-400 border-emerald-500"
                              : "bg-slate-800 text-white border-slate-700 hover:border-slate-500"
                          }`}
                        >
                          {isDispatched ? "✓ RESCUE DISPATCHED" : "DISPATCH RESPONSE"}
                        </button>

                        {/* 3. CALL WORKER */}
                        <button
                          onClick={() => callWorker(inc.workerId)}
                          className={`px-3 py-1.5 rounded font-bold border transition-all ${
                            isCalling
                              ? "bg-cyan-500 text-black border-cyan-400"
                              : "bg-slate-800 text-cyan-400 border-slate-700 hover:border-slate-500"
                          }`}
                        >
                          {isCalling ? "END CALL" : "CALL WORKER"}
                        </button>

                        {/* 4. EVACUATE AREA */}
                        <button
                          onClick={() => evacuateArea(inc.location.split("(")[0].trim())}
                          className="px-3 py-1.5 rounded font-bold bg-red-950/60 text-red-300 border border-red-500/50 hover:bg-red-900/60 transition-all"
                        >
                          EVACUATE AREA
                        </button>
                      </div>

                      {/* 5. RESOLVE */}
                      <button
                        onClick={() => resolveIncident(inc.id)}
                        className="px-4 py-1.5 rounded font-bold bg-emerald-600 text-white hover:bg-emerald-500 transition-all shadow-md"
                      >
                        ✓ RESOLVE INCIDENT
                      </button>
                    </div>
                  </motion.div>
                );
              })}
            </AnimatePresence>
          </div>
        )}
      </div>

      {/* Resolved Incident History Section */}
      <div className="command-panel p-6 space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <h3 className="font-display font-bold text-white text-lg">
            RESOLVED INCIDENT HISTORY ({resolvedIncidents.length})
          </h3>
          <span className="font-mono text-xs text-slate-400">
            Archived Subterranean Events
          </span>
        </div>

        {resolvedIncidents.length === 0 ? (
          <div className="text-center py-6 font-mono text-xs text-slate-500">
            No resolved incident history recorded.
          </div>
        ) : (
          <div className="space-y-2">
            {resolvedIncidents.map((inc) => (
              <div
                key={inc.id}
                className="p-3 rounded bg-slate-900/40 border border-slate-800 flex items-center justify-between flex-wrap gap-2 text-xs font-mono opacity-75"
              >
                <div>
                  <span className="font-bold text-emerald-400">{inc.id}</span> —{" "}
                  <span className="text-white font-semibold">{inc.type}</span> ({inc.workerName})
                  <div className="text-[10px] text-slate-400 mt-0.5">
                    {inc.location} · Resolved at {new Date(inc.timestamp).toLocaleTimeString()}
                  </div>
                </div>
                <span className="px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 text-[10px] font-bold">
                  ✓ RESOLVED
                </span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
