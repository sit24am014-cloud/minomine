// client/src/views/SensorSimulatorView.jsx
// Complete SIH 2026 Presentation Sensor Simulator for MINO MINE

import React from "react";
import { useMinoMine } from "../context/MinoMineContext";

export default function SensorSimulatorView() {
  const {
    workers,
    selectedWorkerId,
    setSelectedWorkerId,
    updateWorkerSensor,
    triggerHazardEvent,
    resetWorker,
    clearAllEmergencies,
    startDemoMode,
    toggleSimulationPause,
    isSimulationPaused,
    isDemoActive,
  } = useMinoMine();

  const activeWorkerId = selectedWorkerId || workers[3]?.id || "W004";
  const worker = workers.find((w) => w.id === activeWorkerId) || workers[3] || workers[0];

  if (!worker) return null;

  return (
    <div className="space-y-6">
      {/* Required Page Header */}
      <div className="command-panel p-6 border-l-4 border-l-amber-500">
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="font-mono text-xs font-bold text-amber-500 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/30">
                MINO MINE
              </span>
              <span className="font-mono text-xs text-slate-400">
                UNDERGROUND MINING SAFETY SYSTEM
              </span>
            </div>
            <h1 className="font-display text-2xl font-black text-white">
              HARDWARE SENSOR SIMULATOR CONSOLE
            </h1>
          </div>
          <span className="font-mono text-xs px-3 py-1.5 rounded bg-slate-800 text-amber-400 border border-slate-700">
            DEMO / SIMULATION MODE
          </span>
        </div>
      </div>

      {/* SIH Jury Presentation Master Control Bar */}
      <div className="command-panel p-5 bg-slate-900/90 border border-amber-500/40 flex items-center justify-between flex-wrap gap-4 font-mono">
        <div>
          <span className="text-xs text-amber-500 font-bold uppercase tracking-wider block">
            SIH Jury Presentation Master Controls
          </span>
          <span className="text-[11px] text-slate-400">
            {isDemoActive
              ? "● START DEMO Script Executing (Auto Sequence Active)"
              : isSimulationPaused
              ? "⏸ SIMULATION PAUSED (Still-Frame Inspection)"
              : "● Real-time Simulation Engine Running"}
          </span>
        </div>

        <div className="flex items-center gap-3 flex-wrap">
          <button
            onClick={startDemoMode}
            disabled={isDemoActive}
            className={`px-4 py-2.5 rounded font-bold text-xs shadow-lg transition-all ${
              isDemoActive
                ? "bg-slate-700 text-slate-400 cursor-not-allowed"
                : "bg-amber-500 text-black hover:bg-amber-400 animate-pulse"
            }`}
          >
            ▶ START DEMO
          </button>

          <button
            onClick={toggleSimulationPause}
            className={`px-4 py-2.5 rounded font-bold text-xs border transition-all ${
              isSimulationPaused
                ? "bg-amber-500/20 text-amber-400 border-amber-500"
                : "bg-slate-800 text-slate-300 border-slate-700 hover:border-slate-500"
            }`}
          >
            {isSimulationPaused ? "▶ RESUME SIMULATION" : "⏸ PAUSE SIMULATION"}
          </button>

          <button
            onClick={clearAllEmergencies}
            className="px-4 py-2.5 rounded font-bold text-xs bg-emerald-600 text-white hover:bg-emerald-500 transition-all shadow-md"
          >
            🔄 RESET ALL WORKERS
          </button>
        </div>
      </div>

      {/* Worker Selection */}
      <div className="command-panel p-6">
        <div className="flex items-center justify-between mb-3">
          <label className="font-mono text-xs font-bold text-slate-300 uppercase">
            SELECT WORKER FOR HARDWARE TELEMETRY OVERRIDE
          </label>
          <span className="font-mono text-xs text-amber-500 font-bold">
            Selected: {worker.id} — {worker.name} ({worker.zone.split("–")[0].trim()})
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 gap-2">
          {workers.map((w) => {
            const isSelected = w.id === activeWorkerId;
            const isCrit = w.safetyStatus === "CRITICAL";
            const isWarn = w.safetyStatus === "WARNING";
            const isOff = w.safetyStatus === "OFFLINE";

            const borderCol = isCrit
              ? "border-red-500 bg-red-950/30"
              : isWarn
              ? "border-amber-500 bg-amber-950/20"
              : isOff
              ? "border-slate-700 bg-slate-900"
              : "border-slate-800 bg-slate-900/60";

            return (
              <button
                key={w.id}
                onClick={() => setSelectedWorkerId(w.id)}
                className={`p-3 rounded-lg border text-left font-mono transition-all relative ${borderCol} ${
                  isSelected ? "ring-2 ring-amber-500 border-amber-500 z-10" : "hover:border-slate-700"
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-bold text-xs text-white">{w.id}</span>
                  <span
                    className={`w-2 h-2 rounded-full ${
                      isCrit
                        ? "bg-red-500 animate-ping"
                        : isWarn
                        ? "bg-amber-500"
                        : isOff
                        ? "bg-slate-600"
                        : "bg-emerald-500"
                    }`}
                  />
                </div>
                <div className="text-[11px] text-slate-300 font-medium truncate mt-0.5">{w.name}</div>
                <div className="text-[9px] text-slate-400 mt-1">{w.safetyStatus}</div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Target Worker Sensor Override Controls */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Sliders Panel */}
        <div className="lg:col-span-8 command-panel p-6 space-y-6">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800">
            <div>
              <h3 className="font-display font-bold text-lg text-white">
                Live Sensor Telemetry Sliders ({worker.id} - {worker.name})
              </h3>
              <p className="font-mono text-xs text-slate-400">
                Modifying these values immediately updates Control Room, Emergency Center, 3D Helmet, and Phone interface.
              </p>
            </div>
            <span
              className={`font-mono text-xs font-bold px-2.5 py-1 rounded border ${
                worker.safetyStatus === "CRITICAL"
                  ? "bg-red-500/20 text-red-400 border-red-500"
                  : worker.safetyStatus === "WARNING"
                  ? "bg-amber-500/20 text-amber-400 border-amber-500"
                  : "bg-emerald-500/20 text-emerald-400 border-emerald-500"
              }`}
            >
              {worker.safetyStatus}
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 font-mono text-xs">
            {/* Heart Rate */}
            <div className="space-y-1.5 p-3 rounded bg-slate-900/60 border border-slate-800">
              <div className="flex justify-between text-slate-300">
                <span>Heart Rate (MAX30102 PPG)</span>
                <span className={`font-bold ${worker.heartRate > 125 ? "text-red-400" : "text-amber-500"}`}>
                  {worker.heartRate} BPM
                </span>
              </div>
              <input
                type="range"
                min="40"
                max="180"
                value={worker.heartRate}
                onChange={(e) => updateWorkerSensor(activeWorkerId, "heartRate", parseInt(e.target.value))}
                className="w-full accent-amber-500 bg-slate-800 h-2 rounded cursor-pointer"
              />
              <span className="text-[9px] text-slate-500 block">Normal: 60-100 BPM · Critical: &gt;130 BPM</span>
            </div>

            {/* Temperature */}
            <div className="space-y-1.5 p-3 rounded bg-slate-900/60 border border-slate-800">
              <div className="flex justify-between text-slate-300">
                <span>Temperature Probe (°C)</span>
                <span className={`font-bold ${worker.temperature >= 38.5 ? "text-red-400" : "text-amber-500"}`}>
                  {worker.temperature} °C
                </span>
              </div>
              <input
                type="range"
                min="35.0"
                max="42.0"
                step="0.1"
                value={worker.temperature}
                onChange={(e) => updateWorkerSensor(activeWorkerId, "temperature", parseFloat(e.target.value))}
                className="w-full accent-amber-500 bg-slate-800 h-2 rounded cursor-pointer"
              />
              <span className="text-[9px] text-slate-500 block">Normal: 36.4-37.2°C · High Temp Critical: &gt;=38.5°C</span>
            </div>

            {/* Systolic BP */}
            <div className="space-y-1.5 p-3 rounded bg-slate-900/60 border border-slate-800">
              <div className="flex justify-between text-slate-300">
                <span>Systolic Blood Pressure</span>
                <span className="text-amber-500 font-bold">{worker.systolicBP} mmHg</span>
              </div>
              <input
                type="range"
                min="90"
                max="180"
                value={worker.systolicBP}
                onChange={(e) => updateWorkerSensor(activeWorkerId, "systolicBP", parseInt(e.target.value))}
                className="w-full accent-amber-500 bg-slate-800 h-2 rounded cursor-pointer"
              />
              <span className="text-[9px] text-slate-500 block">Normal: 110-125 mmHg · High: &gt;140 mmHg</span>
            </div>

            {/* Diastolic BP */}
            <div className="space-y-1.5 p-3 rounded bg-slate-900/60 border border-slate-800">
              <div className="flex justify-between text-slate-300">
                <span>Diastolic Blood Pressure</span>
                <span className="text-amber-500 font-bold">{worker.diastolicBP} mmHg</span>
              </div>
              <input
                type="range"
                min="60"
                max="120"
                value={worker.diastolicBP}
                onChange={(e) => updateWorkerSensor(activeWorkerId, "diastolicBP", parseInt(e.target.value))}
                className="w-full accent-amber-500 bg-slate-800 h-2 rounded cursor-pointer"
              />
              <span className="text-[9px] text-slate-500 block">Normal: 70-85 mmHg · High: &gt;90 mmHg</span>
            </div>

            {/* Respiration Rate */}
            <div className="space-y-1.5 p-3 rounded bg-slate-900/60 border border-slate-800">
              <div className="flex justify-between text-slate-300">
                <span>Respiration Rate</span>
                <span className="text-amber-500 font-bold">{worker.respiration} breaths/min</span>
              </div>
              <input
                type="range"
                min="6"
                max="35"
                value={worker.respiration}
                onChange={(e) => updateWorkerSensor(activeWorkerId, "respiration", parseInt(e.target.value))}
                className="w-full accent-amber-500 bg-slate-800 h-2 rounded cursor-pointer"
              />
              <span className="text-[9px] text-slate-500 block">Normal: 12-20 br/m · Critical: &lt;8 or &gt;30 br/m</span>
            </div>

            {/* Gas Level */}
            <div className="space-y-1.5 p-3 rounded bg-slate-900/60 border border-slate-800">
              <div className="flex justify-between text-slate-300">
                <span>MQ Gas Sensor Array (PPM)</span>
                <span className={`font-bold ${worker.gasLevel >= 180 ? "text-red-400" : "text-amber-500"}`}>
                  {worker.gasLevel} PPM
                </span>
              </div>
              <input
                type="range"
                min="0"
                max="350"
                value={worker.gasLevel}
                onChange={(e) => updateWorkerSensor(activeWorkerId, "gasLevel", parseInt(e.target.value))}
                className="w-full accent-amber-500 bg-slate-800 h-2 rounded cursor-pointer"
              />
              <span className="text-[9px] text-slate-500 block">Normal: 0-30 PPM · Gas Leak Alert: &gt;=180 PPM</span>
            </div>

            {/* Battery */}
            <div className="space-y-1.5 p-3 rounded bg-slate-900/60 border border-slate-800 col-span-1 md:col-span-2">
              <div className="flex justify-between text-slate-300">
                <span>Helmet Battery Charge Level (%)</span>
                <span className="text-amber-500 font-bold">{worker.battery}% Charge</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                value={worker.battery}
                onChange={(e) => updateWorkerSensor(activeWorkerId, "battery", parseInt(e.target.value))}
                className="w-full accent-amber-500 bg-slate-800 h-2 rounded cursor-pointer"
              />
            </div>
          </div>
        </div>

        {/* Action Buttons Panel */}
        <div className="lg:col-span-4 command-panel p-6 flex flex-col justify-between space-y-6">
          <div>
            <h3 className="font-display font-bold text-white text-lg pb-3 border-b border-slate-800">
              Emergency Action Buttons ({worker.id})
            </h3>
            <p className="font-mono text-xs text-slate-400 mt-2">
              Pressing any emergency trigger immediately updates worker status to CRITICAL, broadcasts a LoRa incident, and triggers phone & Control Room alarms.
            </p>

            <div className="space-y-3 mt-4">
              <button
                onClick={() => triggerHazardEvent(activeWorkerId, "FALL")}
                className="w-full py-3 px-4 rounded-xl bg-red-950/60 border border-red-500/50 hover:border-red-400 text-red-300 font-mono text-xs font-bold flex items-center justify-between transition-all"
              >
                <div className="flex items-center gap-2">
                  <span className="text-xl">🤸</span>
                  <span>TRIGGER FALL</span>
                </div>
                <span className="text-[10px] text-red-400">MPU6050</span>
              </button>

              <button
                onClick={() => triggerHazardEvent(activeWorkerId, "FIRE")}
                className="w-full py-3 px-4 rounded-xl bg-orange-950/60 border border-orange-500/50 hover:border-orange-400 text-orange-300 font-mono text-xs font-bold flex items-center justify-between transition-all"
              >
                <div className="flex items-center gap-2">
                  <span className="text-xl">🔥</span>
                  <span>TRIGGER FIRE</span>
                </div>
                <span className="text-[10px] text-orange-400">IR FLAME</span>
              </button>

              <button
                onClick={() => triggerHazardEvent(activeWorkerId, "GAS_LEAK")}
                className="w-full py-3 px-4 rounded-xl bg-amber-950/60 border border-amber-500/50 hover:border-amber-400 text-amber-300 font-mono text-xs font-bold flex items-center justify-between transition-all"
              >
                <div className="flex items-center gap-2">
                  <span className="text-xl">☁️</span>
                  <span>TRIGGER GAS LEAK</span>
                </div>
                <span className="text-[10px] text-amber-400">MQ SENSOR</span>
              </button>

              <button
                onClick={() => triggerHazardEvent(activeWorkerId, "MEDICAL")}
                className="w-full py-3 px-4 rounded-xl bg-purple-950/60 border border-purple-500/50 hover:border-purple-400 text-purple-300 font-mono text-xs font-bold flex items-center justify-between transition-all"
              >
                <div className="flex items-center gap-2">
                  <span className="text-xl">🚑</span>
                  <span>TRIGGER MEDICAL EMERGENCY</span>
                </div>
                <span className="text-[10px] text-purple-400">MAX30102</span>
              </button>

              <button
                onClick={() => resetWorker(activeWorkerId)}
                className="w-full py-3 px-4 rounded-xl bg-slate-800 border border-slate-700 hover:border-slate-500 text-white font-mono text-xs font-bold flex items-center justify-between transition-all mt-4"
              >
                <div className="flex items-center gap-2">
                  <span>🔄</span>
                  <span>RESET WORKER ({worker.id})</span>
                </div>
                <span className="text-[10px] text-emerald-400">SAFE</span>
              </button>
            </div>
          </div>

          <div className="p-4 rounded bg-slate-900 border border-slate-800 font-mono text-[11px] text-slate-400 space-y-1">
            <div className="font-bold text-amber-500">Live Data Propagation Verified:</div>
            <div>• Control Room: Immediately reflects {worker.id} status</div>
            <div>• Emergency Center: Logged as active incident</div>
            <div>• Phone View: Receives emergency alarm</div>
          </div>
        </div>
      </div>
    </div>
  );
}
