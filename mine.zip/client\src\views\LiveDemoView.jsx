// client/src/views/LiveDemoView.jsx
// Automated 8-Scene SIH 2026 Presentation Sequence Runner for MINO MINE

import React, { useState, useEffect, useRef } from "react";
import { motion } from "framer-motion";
import { useMinoMine } from "../context/MinoMineContext";
import ControlRoomView from "./ControlRoomView";
import SmartHelmetView from "./SmartHelmetView";
import MobileWorkerView from "./MobileWorkerView";
import IncidentHistoryView from "./IncidentHistoryView";

const DEMO_SCENES = [
  {
    scene: 1,
    title: "SCENE 1: WORKERS INSIDE THE MINE",
    subtitle: "Control Room displays 12 subterranean workers (W001 - W012). All initially SAFE.",
    status: "SAFE",
    targetWorker: "W001",
    tab: "CONTROL ROOM",
  },
  {
    scene: 2,
    title: "SCENE 2: WORKER 01 FALL INCIDENT",
    subtitle: "W001 (Arjun Mehta) triggers MPU6050 -> FALL DETECTED -> ESP32 -> LoRa -> REPEATERS -> GATEWAY -> CONTROL ROOM.",
    status: "CRITICAL",
    targetWorker: "W001",
    tab: "WORKER PHONE",
  },
  {
    scene: 3,
    title: "SCENE 3: CONTROL ROOM EMERGENCY RESPONSE",
    subtitle: "Operator acknowledges W001 alert, pinpoints subterranean location & incident report.",
    status: "ACKNOWLEDGED",
    targetWorker: "W001",
    tab: "CONTROL ROOM",
  },
  {
    scene: 4,
    title: "SCENE 4: TUNNEL COLLAPSE HAZARD DETECTED",
    subtitle: "Control Room identifies environmental danger in Zone B. Operator targets Zone B workers (W002, W003, W004, W005).",
    status: "WARNING",
    targetWorker: "W002",
    tab: "CONTROL ROOM",
  },
  {
    scene: 5,
    title: "SCENE 5: REVERSE LORA MESH BROADCAST TRANSMISSION",
    subtitle: "CONTROL ROOM -> GATEWAY -> REPEATER 3 -> REPEATER 2 -> REPEATER 1 -> TARGET WORKER HELMETS",
    status: "TRANSMITTING",
    targetWorker: "W002",
    tab: "CONTROL ROOM",
  },
  {
    scene: 6,
    title: "SCENE 6: WORKER HELMET DEVICE EVACUATION ALERT",
    subtitle: "Selected workers (W002-W005) receive 🚨 EMERGENCY BROADCAST & intra-helmet vibration motor pulse.",
    status: "EVACUATING",
    targetWorker: "W002",
    tab: "WORKER PHONE",
  },
  {
    scene: 7,
    title: "SCENE 7: CONTROL ROOM MONITORING GRID STATUS",
    subtitle: "W001: CRITICAL (FALL) | W002-W005: EVACUATION REQUIRED | W006-W012: SAFE (UNAFFECTED)",
    status: "CRITICAL",
    targetWorker: "W001",
    tab: "CONTROL ROOM",
  },
  {
    scene: 8,
    title: "SCENE 8: INCIDENT HISTORY AUDIT & PARADIGM",
    subtitle: "Audit log records W001 Fall + Zone B Evacuation. Workflow: DETECT -> ANALYZE -> COMMUNICATE -> RESPOND -> PROTECT",
    status: "RESOLVED",
    targetWorker: "W001",
    tab: "INCIDENT HISTORY",
  },
];

export default function LiveDemoView() {
  const {
    workers,
    incidents,
    triggerHazardEvent,
    clearAllEmergencies,
    acknowledgeIncident,
    setSelectedWorkerId,
    broadcastControlRoomCommand,
    clearControlRoomBroadcasts,
  } = useMinoMine();

  const [currentSceneIndex, setCurrentSceneIndex] = useState(0);
  const [isRunning, setIsRunning] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [activePreviewTab, setActivePreviewTab] = useState("CONTROL ROOM");

  const timerRef = useRef(null);

  const currentScene = DEMO_SCENES[currentSceneIndex] || DEMO_SCENES[0];

  // Automated 8-Scene Timer Engine
  useEffect(() => {
    if (isRunning && !isPaused) {
      timerRef.current = setTimeout(() => {
        if (currentSceneIndex < DEMO_SCENES.length - 1) {
          const nextIndex = currentSceneIndex + 1;
          executeSceneStep(nextIndex);
          setCurrentSceneIndex(nextIndex);
        } else {
          setIsRunning(false);
        }
      }, 4000);
    }
    return () => clearTimeout(timerRef.current);
  }, [isRunning, isPaused, currentSceneIndex]);

  const executeSceneStep = (sceneIdx) => {
    switch (sceneIdx) {
      case 0: // Scene 1: All SAFE
        clearAllEmergencies();
        clearControlRoomBroadcasts();
        setSelectedWorkerId("W001");
        setActivePreviewTab("CONTROL ROOM");
        break;

      case 1: // Scene 2: W001 FALL -> Only W001 becomes CRITICAL
        clearControlRoomBroadcasts();
        setSelectedWorkerId("W001");
        triggerHazardEvent("W001", "FALL");
        setActivePreviewTab("WORKER PHONE");
        break;

      case 2: // Scene 3: Control Room response to W001
        setSelectedWorkerId("W001");
        if (incidents.length > 0) {
          acknowledgeIncident(incidents[0].id);
        }
        setActivePreviewTab("CONTROL ROOM");
        break;

      case 3: // Scene 4: Control Room operator selects W002-W005 in Zone B
        setSelectedWorkerId("W002");
        setActivePreviewTab("CONTROL ROOM");
        break;

      case 4: // Scene 5: Broadcast Evacuation command
        broadcastControlRoomCommand({
          type: "TUNNEL COLLAPSE",
          zone: "Zone B – East Tunnel",
          recipientWorkerIds: ["W002", "W003", "W004", "W005"],
          message: "TUNNEL COLLAPSE DETECTED IN ZONE B. EVACUATE TO SAFE ROUTE IMMEDIATELY.",
          severity: "HIGH",
        });
        setActivePreviewTab("CONTROL ROOM");
        break;

      case 5: // Scene 6: Worker Helmets receive broadcast (W002-W005)
        setSelectedWorkerId("W002");
        setActivePreviewTab("WORKER PHONE");
        break;

      case 6: // Scene 7: Control Room Grid showing W001 CRITICAL, W002-W005 EVACUATION REQUIRED, W006-W012 SAFE
        setActivePreviewTab("CONTROL ROOM");
        break;

      case 7: // Scene 8: Incident History Audit Trail
        setActivePreviewTab("INCIDENT HISTORY");
        break;

      default:
        break;
    }
  };

  const handleStartLiveDemo = () => {
    clearAllEmergencies();
    clearControlRoomBroadcasts();
    setCurrentSceneIndex(0);
    setIsRunning(true);
    setIsPaused(false);
    executeSceneStep(0);
  };

  const handlePauseDemo = () => {
    setIsPaused((prev) => !prev);
  };

  const handleResetDemo = () => {
    if (timerRef.current) clearTimeout(timerRef.current);
    setIsRunning(false);
    setIsPaused(false);
    setCurrentSceneIndex(0);
    clearAllEmergencies();
    clearControlRoomBroadcasts();
    executeSceneStep(0);
  };

  return (
    <div className="space-y-6 font-sans">
      {/* ─── HEADER BANNER & LABELS ─── */}
      <div className="bg-slate-900 p-6 rounded-xl border border-slate-800 shadow-xl space-y-4">
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1 font-mono">
              <span className="text-xs font-black text-amber-500 bg-amber-500/10 px-2.5 py-0.5 rounded border border-amber-500/30">
                MINO MINE
              </span>
              <span className="text-xs text-slate-400 font-bold">
                UNDERGROUND MINING SAFETY SYSTEM
              </span>
              <span className="text-xs font-bold text-blue-400 bg-blue-500/10 px-2 py-0.5 rounded border border-blue-500/30">
                SIH 2026
              </span>
            </div>
            <h1 className="text-2xl font-black text-white tracking-tight">
              FINAL SIH 2026 LIVE DEMONSTRATION PRESENTATION
            </h1>
            <p className="font-mono text-xs text-amber-400 font-bold mt-1">
              DEMO MODE · SIMULATED HARDWARE DATA (SOFTWARE PRESENTATION)
            </p>
          </div>

          <div className="flex items-center gap-3 font-mono text-xs">
            <button
              onClick={handleStartLiveDemo}
              disabled={isRunning && !isPaused}
              className={`px-5 py-2.5 rounded-lg font-bold shadow-xl transition-all ${
                isRunning && !isPaused
                  ? "bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700"
                  : "bg-amber-500 text-black hover:bg-amber-400 animate-pulse shadow-[0_0_20px_rgba(245,158,11,0.5)]"
              }`}
            >
              ▶ START LIVE DEMO
            </button>

            <button
              onClick={handlePauseDemo}
              disabled={!isRunning}
              className="px-4 py-2.5 rounded-lg font-bold bg-slate-800 text-slate-200 border border-slate-700 hover:border-slate-500 transition-colors"
            >
              {isPaused ? "▶ RESUME" : "⏸ PAUSE"}
            </button>

            <button
              onClick={handleResetDemo}
              className="px-4 py-2.5 rounded-lg font-bold bg-slate-800 text-amber-400 border border-slate-700 hover:border-amber-500 transition-colors"
            >
              🔄 RESET DEMO
            </button>
          </div>
        </div>

        {/* ─── 5-STAGE CORE SAFETY PARADIGM BANNER ─── */}
        <div className="bg-slate-950 p-3 rounded-lg border border-slate-800 flex items-center justify-between overflow-x-auto scrollbar-none font-mono text-xs">
          <span className="text-amber-500 font-black tracking-wider text-[11px]">
            CORE SAFETY PARADIGM:
          </span>
          <div className="flex items-center gap-2 font-bold text-slate-200 text-[11px] min-w-max">
            <span className="px-2.5 py-1 rounded bg-slate-900 border border-slate-800 text-cyan-400">
              ⚡ DETECT
            </span>
            <span>→</span>
            <span className="px-2.5 py-1 rounded bg-slate-900 border border-slate-800 text-amber-400">
              🧠 ANALYZE
            </span>
            <span>→</span>
            <span className="px-2.5 py-1 rounded bg-slate-900 border border-slate-800 text-blue-400">
              📡 COMMUNICATE
            </span>
            <span>→</span>
            <span className="px-2.5 py-1 rounded bg-slate-900 border border-slate-800 text-emerald-400">
              🚑 RESPOND
            </span>
            <span>→</span>
            <span className="px-2.5 py-1 rounded bg-slate-900 border border-slate-800 text-purple-400">
              🛡️ PROTECT
            </span>
          </div>
        </div>
      </div>

      {/* ─── 8-SCENE PROGRESS TRACKER BAR ─── */}
      <div className="bg-slate-900 p-5 rounded-xl border border-slate-800 space-y-4 font-mono">
        <div className="flex items-center justify-between text-xs">
          <span className="font-bold text-amber-500 tracking-wider">
            PRESENTATION SCENE {currentScene.scene} OF 8
          </span>
          <span className="text-slate-400 text-[11px]">
            {isRunning ? (isPaused ? "⏸ PRESENTATION PAUSED" : "▶ RUNNING AUTOMATED SEQUENCE") : "READY TO START"}
          </span>
        </div>

        {/* Scene Stepper Pills */}
        <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-8 gap-2 text-[10px]">
          {DEMO_SCENES.map((s, idx) => {
            const isPast = currentSceneIndex > idx;
            const isCurrent = currentSceneIndex === idx;

            return (
              <button
                key={s.scene}
                onClick={() => {
                  setCurrentSceneIndex(idx);
                  executeSceneStep(idx);
                }}
                className={`p-2.5 rounded-lg border text-center transition-all ${
                  isCurrent
                    ? "bg-amber-500 text-black font-bold border-amber-400 shadow-md scale-105"
                    : isPast
                    ? "bg-emerald-500/20 text-emerald-400 border-emerald-500/40"
                    : "bg-slate-950 text-slate-500 border-slate-800 hover:border-slate-700"
                }`}
              >
                <div className="font-black text-[11px]">SCENE {s.scene}</div>
                <div className="truncate text-[9px] mt-0.5 font-sans font-semibold">{s.status}</div>
              </button>
            );
          })}
        </div>

        {/* Active Scene Explanation Card */}
        <motion.div
          key={currentScene.scene}
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          className="p-4 rounded-xl bg-slate-950 border border-amber-500/40 flex items-center justify-between flex-wrap gap-4 font-mono shadow-md"
        >
          <div className="space-y-1">
            <div className="text-xs font-bold text-amber-400 tracking-wider uppercase">
              {currentScene.title}
            </div>
            <p className="text-sm font-semibold text-slate-100 font-sans">
              {currentScene.subtitle}
            </p>
          </div>

          <div className="text-right">
            <span className="text-[10px] text-slate-400 block uppercase">PRIMARY VIEW</span>
            <span className="text-xs font-bold px-2.5 py-1 rounded bg-blue-500/20 text-blue-400 border border-blue-500/40 inline-block mt-0.5">
              {activePreviewTab}
            </span>
          </div>
        </motion.div>
      </div>

      {/* ─── LIVE INTERACTIVE VIEWPORT PREVIEW ─── */}
      <div className="space-y-4 font-mono">
        <div className="flex items-center justify-between text-xs">
          <span className="text-slate-400 font-bold uppercase tracking-wider">
            LIVE PRESENTATION VIEWPORT PREVIEW
          </span>
          <div className="flex items-center border border-slate-700 rounded-lg overflow-hidden bg-slate-900 text-xs">
            <button
              onClick={() => setActivePreviewTab("CONTROL ROOM")}
              className={`px-3 py-1.5 font-bold transition-all ${
                activePreviewTab === "CONTROL ROOM" ? "bg-amber-500 text-black shadow-md" : "text-slate-400 hover:text-white"
              }`}
            >
              💻 CONTROL ROOM
            </button>
            <button
              onClick={() => setActivePreviewTab("WORKER PHONE")}
              className={`px-3 py-1.5 font-bold transition-all ${
                activePreviewTab === "WORKER PHONE" ? "bg-amber-500 text-black shadow-md" : "text-slate-400 hover:text-white"
              }`}
            >
              📱 WORKER PHONE
            </button>
            <button
              onClick={() => setActivePreviewTab("INCIDENT HISTORY")}
              className={`px-3 py-1.5 font-bold transition-all ${
                activePreviewTab === "INCIDENT HISTORY" ? "bg-amber-500 text-black shadow-md" : "text-slate-400 hover:text-white"
              }`}
            >
              📋 AUDIT HISTORY
            </button>
            <button
              onClick={() => setActivePreviewTab("HELMET")}
              className={`px-3 py-1.5 font-bold transition-all ${
                activePreviewTab === "HELMET" ? "bg-amber-500 text-black shadow-md" : "text-slate-400 hover:text-white"
              }`}
            >
              🪖 3D HELMET
            </button>
          </div>
        </div>

        <div className="min-h-[550px] bg-slate-950 p-2 rounded-2xl border border-slate-800">
          {activePreviewTab === "CONTROL ROOM" && <ControlRoomView />}
          {activePreviewTab === "WORKER PHONE" && <MobileWorkerView />}
          {activePreviewTab === "INCIDENT HISTORY" && <IncidentHistoryView />}
          {activePreviewTab === "HELMET" && <SmartHelmetView />}
        </div>
      </div>
    </div>
  );
}
