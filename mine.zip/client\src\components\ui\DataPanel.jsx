// client/src/components/ui/DataPanel.jsx
// Slide-in tech panel showing hardware specs for all 12 helmet components

import React from "react";
import { motion, AnimatePresence } from "framer-motion";

const COMPONENT_INFO = {
  esp32: {
    icon: "🔲",
    title: "1. ESP32 MCU SoC",
    tech: "Dual-Core Tensilica LX6 @ 240 MHz",
    specs: [
      { label: "Architecture", value: "32-bit Dual Core" },
      { label: "Wireless", value: "Wi-Fi 802.11 + BLE 4.2" },
      { label: "SRAM", value: "520 KB" },
      { label: "OS", value: "FreeRTOS Real-Time" },
    ],
    description:
      "Central processing hub coordinating 12-sensor data acquisition, edge anomaly classification, LoRa telemetry packet generation, and intra-helmet haptic alert execution.",
    color: "#00e676",
  },
  max30102: {
    icon: "❤️",
    title: "2. MAX30102 PPG Sensor",
    tech: "Pulse Oximeter & Heart Rate Module",
    specs: [
      { label: "Accuracy", value: "±2 BPM / ±1% SpO₂" },
      { label: "LED Wavelength", value: "Red 660nm / IR 880nm" },
      { label: "Sample Rate", value: "50–3200 Hz" },
      { label: "Interface", value: "I2C @ 400 kHz" },
    ],
    description:
      "Photoplethysmography sensor integrated inside helmet headband. Measures forehead arterial blood volume pulse for real-time Heart Rate (BPM) and Blood Oxygen Saturation (SpO₂%).",
    color: "#ff1744",
  },
  mpu6050: {
    icon: "🤸",
    title: "3. MPU6050 6-Axis IMU",
    tech: "3-Axis Accel + 3-Axis Gyroscope",
    specs: [
      { label: "Accel Range", value: "±2g, ±4g, ±8g, ±16g" },
      { label: "Gyro Range", value: "±250 to ±2000°/s" },
      { label: "DMP Unit", value: "Digital Motion Processor" },
      { label: "Fall Detect", value: "Zero-G + Impact Threshold" },
    ],
    description:
      "Detects sudden subterranean miner falls, vertical drops, structural impacts, and prolonged post-impact immobility (Man-Down status) to dispatch immediate rescue teams.",
    color: "#ffab00",
  },
  mq_gas: {
    icon: "☁️",
    title: "4. MQ Gas Sensor Array",
    tech: "MQ-4 / MQ-135 Gas Sensors",
    specs: [
      { label: "Target Gases", value: "Methane (CH₄), CO, H₂S" },
      { label: "CH₄ Range", value: "200–10000 PPM" },
      { label: "CO Range", value: "10–1000 PPM" },
      { label: "Alarm Threshold", value: "180 PPM" },
    ],
    description:
      "Electrochemical gas detection array monitoring hazardous coal mine gases. Continuously evaluates air safety to prevent subterranean gas explosions and asphyxiation.",
    color: "#ff8800",
  },
  flame_sensor: {
    icon: "🔥",
    title: "5. IR Flame Sensor",
    tech: "High-Sensitivity Photodiode",
    specs: [
      { label: "Wavelength", value: "760nm–1100nm IR" },
      { label: "Detection Angle", value: "60 Degrees" },
      { label: "Response Time", value: "< 50 ms" },
      { label: "Trigger Output", value: "Digital Interrupt + Analog" },
    ],
    description:
      "Infrared optical flame sensor positioned on helmet exterior. Instantly detects open fires, electrical arcing, and ignition flames inside dark underground mine shafts.",
    color: "#ff1744",
  },
  temp_sensor: {
    icon: "🌡️",
    title: "6. Temperature Sensor Probe",
    tech: "NTC Precision Thermal Probe",
    specs: [
      { label: "Range", value: "-20°C to +85°C" },
      { label: "Accuracy", value: "±0.5°C" },
      { label: "Resolution", value: "0.1°C" },
      { label: "Heat-Stroke Alert", value: "Threshold >= 38.5°C" },
    ],
    description:
      "Monitors both ambient underground thermal atmosphere and miner body temperature to warn control rooms against heat stroke, hyperthermia, and thermal runaway.",
    color: "#00d4ff",
  },
  gps: {
    icon: "🗺️",
    title: "7. GPS / GIS Subterranean Beacon",
    tech: "U-blox NEO-6M + Subterranean BLE Mesh",
    specs: [
      { label: "Update Rate", value: "5 Hz" },
      { label: "Sensitivity", value: "-161 dBm" },
      { label: "Depth Tracking", value: "Shaft Barometric + GIS" },
      { label: "Accuracy", value: "< 2.5m Underground" },
    ],
    description:
      "Provides exact subterranean shaft coordinates, elevation depth meters, and tunnel beacon positioning so surface command knows exact miner locations.",
    color: "#00e676",
  },
  lora: {
    icon: "📡",
    title: "8. LoRa SX1276 Radio Module",
    tech: "Sub-GHz Long Range Radio Transceiver",
    specs: [
      { label: "Frequency", value: "868 / 915 MHz" },
      { label: "Subterranean Range", value: "Up to 5 km through rock" },
      { label: "TX Power", value: "+14 dBm" },
      { label: "Bandwidth", value: "125 kHz" },
    ],
    description:
      "Penetrates solid subterranean rock strata where Wi-Fi and cellular signals fail. Transmits real-time 12-sensor telemetry packets to surface control room gateways.",
    color: "#00d4ff",
  },
  ldr: {
    icon: "☀️",
    title: "9. LDR Light Sensor",
    tech: "Photoresistor Ambient Sensor",
    specs: [
      { label: "Lux Range", value: "1 to 10,000 Lux" },
      { label: "Peak Sensitivity", value: "540nm" },
      { label: "Auto Headlamp", value: "Adjusts LED Brightness" },
      { label: "Power Draft", value: "< 0.5 mA" },
    ],
    description:
      "Measures ambient illumination around the miner. Automatically controls headlamp intensity in pitch-black tunnels while conserving helmet battery life.",
    color: "#ffd700",
  },
  led_headlamp: {
    icon: "💡",
    title: "10. Cree LED Headlamp & RGB",
    tech: "High-Lumen Cree LED + RGB Status",
    specs: [
      { label: "Luminance", value: "1000 Lumens" },
      { label: "Color Temp", value: "6500K Cool White" },
      { label: "RGB Status", value: "SAFE (Green) / WARN / DANGER" },
      { label: "Life Rating", value: "50,000 Hours" },
    ],
    description:
      "High-power ultra-bright headlamp for subterranean tunnel illumination, integrated with an RGB halo light giving visual safety status to co-workers in the mine.",
    color: "#ffffff",
  },
  vibration_motor: {
    icon: "📳",
    title: "11. Vibration Haptic Motor",
    tech: "Coin ERM Vibration Actuator",
    specs: [
      { label: "Voltage", value: "3.0V DC" },
      { label: "Speed", value: "12,000 RPM" },
      { label: "Patterns", value: "Pulse Emergency / Hazard Warning" },
      { label: "Latency", value: "< 10 ms" },
    ],
    description:
      "Provides instant tactile/haptic vibration alerts directly inside the helmet shell, warning miners immediately even in noisy 100+ dB drilling environments.",
    color: "#ff00ff",
  },
  battery: {
    icon: "🔋",
    title: "12. Li-Ion Battery & BMS",
    tech: "3.7V 4400 mAh ATEX Certified",
    specs: [
      { label: "Capacity", value: "4400 mAh" },
      { label: "Runtime", value: "14–16 Hours" },
      { label: "ATEX Zone", value: "Zone 0 Certified Intrinsically Safe" },
      { label: "BMS Protection", value: "Overcharge, Short Circuit" },
    ],
    description:
      "Intrinsically safe lithium-ion battery system equipped with Smart BMS. Designed to operate safely in explosive coal seam methane atmospheres.",
    color: "#ffab00",
  },
};

export default function DataPanel({ componentId, onClose }) {
  const info = componentId ? COMPONENT_INFO[componentId] : null;

  return (
    <AnimatePresence>
      {info && (
        <motion.div
          key={componentId}
          initial={{ x: 60, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          exit={{ x: 60, opacity: 0 }}
          transition={{ type: "spring", stiffness: 300, damping: 28 }}
          className="absolute right-4 top-20 w-80 glass-strong rounded-2xl overflow-hidden z-30 shadow-2xl"
          style={{ borderColor: `${info.color}44` }}
        >
          {/* Header */}
          <div
            className="px-5 py-4 flex items-center justify-between"
            style={{ background: `${info.color}15`, borderBottom: `1px solid ${info.color}33` }}
          >
            <div className="flex items-center gap-3">
              <span className="text-2xl">{info.icon}</span>
              <div>
                <p className="font-display font-bold text-white text-sm leading-tight">
                  {info.title}
                </p>
                <p className="font-mono text-[10px] mt-0.5" style={{ color: info.color }}>
                  {info.tech}
                </p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="text-white/40 hover:text-white text-lg leading-none transition-colors"
            >
              ×
            </button>
          </div>

          {/* Specs table */}
          <div className="px-5 py-3 border-b border-white/5 space-y-1">
            {info.specs.map((s, i) => (
              <div key={i} className="flex justify-between items-center py-1">
                <span className="text-[10px] font-mono text-white/40 uppercase tracking-wider">
                  {s.label}
                </span>
                <span className="font-mono text-xs font-semibold" style={{ color: info.color }}>
                  {s.value}
                </span>
              </div>
            ))}
          </div>

          {/* Description */}
          <div className="px-5 py-4">
            <p className="text-[11px] text-white/60 leading-relaxed font-body">
              {info.description}
            </p>
          </div>

          {/* Live indicator */}
          <div className="px-5 pb-4 flex items-center gap-2">
            <div className="w-2 h-2 rounded-full animate-ping" style={{ background: info.color }} />
            <span className="text-[9px] font-mono text-white/30 uppercase tracking-widest">
              Live Telemetry Stream Active
            </span>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
