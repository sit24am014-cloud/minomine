// client/src/components/ui/HardwareDiagnosticModal.jsx
// Detailed 12-Hardware Sensor Inspection Modal for underground worker safety diagnostic

import React, { useEffect, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useMinoMine } from "../../context/MinoMineContext";

export default function HardwareDiagnosticModal() {
  const { selectedWorker, setSelectedWorkerId, updateWorkerSensor, controlRoomBroadcasts } = useMinoMine();

  const closeDiagnostics = useCallback(
    (e) => {
      if (e && typeof e.stopPropagation === "function") {
        e.stopPropagation();
      }
      setSelectedWorkerId(null);
    },
    [setSelectedWorkerId]
  );

  // Escape key listener to close modal
  useEffect(() => {
    if (!selectedWorker) return;

    const handleKeyDown = (e) => {
      if (e.key === "Escape") {
        closeDiagnostics(e);
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [selectedWorker, closeDiagnostics]);

  const w = selectedWorker;

  // Active Broadcast check for Vibration Motor card
  const hasActiveBroadcast = w
    ? (controlRoomBroadcasts || []).some(
        (bc) => bc.status === "ACTIVE" && (bc.recipientWorkerIds.includes("ALL") || bc.recipientWorkerIds.includes(w.id))
      )
    : false;

  return (
    <AnimatePresence>
      {selectedWorker && (
        <div
          key="hardware-diagnostic-modal-backdrop"
          onClick={closeDiagnostics}
          className="fixed inset-x-0 bottom-0 top-[52px] md:top-[56px] z-40 flex items-center justify-center p-3 sm:p-4 bg-slate-950/80 backdrop-blur-sm font-sans cursor-pointer"
        >
          <motion.div
            key="hardware-diagnostic-modal-box"
            onClick={(e) => e.stopPropagation()}
            initial={{ opacity: 0, scale: 0.96, y: 10 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.96, y: 10 }}
            transition={{ duration: 0.18 }}
            className="bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl max-w-4xl w-full max-h-[calc(100vh-5.5rem)] flex flex-col overflow-hidden text-slate-100 cursor-default pointer-events-auto"
          >
            {/* ─── MODAL HEADER ─── */}
            <div className="p-4 sm:px-6 sm:py-4 border-b border-slate-800 flex items-center justify-between bg-slate-900/90 shrink-0 font-mono">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 font-bold text-sm">
                  {w.id}
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="font-bold text-white text-base sm:text-lg font-sans leading-tight">
                      {w.name}
                    </h3>
                    <span className={`text-[10px] px-2 py-0.5 rounded font-bold border ${
                      w.safetyStatus === "CRITICAL"
                        ? "bg-red-500/20 text-red-400 border-red-500/50"
                        : w.safetyStatus === "WARNING"
                        ? "bg-amber-500/20 text-amber-400 border-amber-500/50"
                        : "bg-emerald-500/20 text-emerald-400 border-emerald-500/50"
                    }`}>
                      {w.safetyStatus}
                    </span>
                  </div>
                  <p className="text-xs text-slate-400 mt-0.5">
                    {w.zone} · <strong className="text-amber-400">{w.depthMeters}m Depth</strong> · {w.shift} Shift
                  </p>
                </div>
              </div>

              {/* X Close Button - Minimum 44x44px touch target */}
              <button
                type="button"
                onClick={closeDiagnostics}
                className="min-w-[44px] min-h-[44px] w-11 h-11 rounded-xl bg-slate-800 hover:bg-slate-700 active:bg-slate-600 text-slate-300 hover:text-white flex items-center justify-center text-xl font-bold border border-slate-700 transition-colors cursor-pointer select-none"
                aria-label="Close worker diagnostics"
                title="Close Diagnostics (ESC)"
              >
                ✕
              </button>
            </div>

            {/* ─── 12 HARDWARE SENSORS DIAGNOSTICS BODY ─── */}
            <div className="p-4 sm:p-5 overflow-y-auto flex-1 space-y-4 scrollbar-thin scrollbar-thumb-slate-700">
              <div className="flex items-center justify-between text-xs font-mono text-slate-400 border-b border-slate-800 pb-2">
                <span className="font-bold text-amber-500 uppercase tracking-wider">
                  12 SMART HELMET HARDWARE DIAGNOSTICS (ESP32 SoC)
                </span>
                <span>Worker Node ID: <strong className="text-white">{w.id}</strong></span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs font-mono">
                {/* 1. ESP32 MCU */}
                <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl space-y-1">
                  <div className="flex justify-between font-bold text-blue-400">
                    <span>1. ESP32 MCU SoC</span>
                    <span className="text-emerald-400">ONLINE</span>
                  </div>
                  <p className="text-[10px] text-slate-400">Dual-Core Tensilica LX6 @ 240 MHz · FreeRTOS</p>
                  <div className="text-slate-300 text-[11px] pt-1 border-t border-slate-800/80 space-y-0.5">
                    <div>CPU Load: 24% · SRAM: 320 KB Free</div>
                    <div>Mesh Signal: -65 dBm (Subterranean RSSI)</div>
                  </div>
                </div>

                {/* 2. MAX30102 PPG */}
                <div className={`p-3 bg-slate-950 border rounded-xl space-y-1 ${w.heartRate > 125 ? "border-red-500/60 bg-red-950/20" : "border-slate-800"}`}>
                  <div className="flex justify-between font-bold text-red-400">
                    <span>2. MAX30102 Oximeter & HR</span>
                    <span>{w.heartRate} BPM / {w.spO2 || 98}% SpO₂</span>
                  </div>
                  <p className="text-[10px] text-slate-400">PPG Dual Red/IR Arterial Pulse Array</p>
                  <div className="text-slate-300 text-[11px] pt-1 border-t border-slate-800/80 space-y-0.5">
                    <div>Blood Pressure: {w.systolicBP}/{w.diastolicBP} mmHg</div>
                    <div>Respiration Rate: {w.respiration} breaths/min</div>
                  </div>
                </div>

                {/* 3. MPU6050 6-Axis IMU */}
                <div className={`p-3 bg-slate-950 border rounded-xl space-y-1 ${w.fallDetected ? "border-red-500/80 bg-red-950/30" : "border-slate-800"}`}>
                  <div className="flex justify-between font-bold text-yellow-400">
                    <span>3. MPU6050 6-Axis IMU</span>
                    <span className={w.fallDetected ? "text-red-400 font-black animate-pulse" : "text-emerald-400"}>
                      {w.fallDetected ? "FALL DETECTED!" : "NORMAL MOTION"}
                    </span>
                  </div>
                  <p className="text-[10px] text-slate-400">Accelerometer & Gyroscope Motion Sensor</p>
                  <div className="text-slate-300 text-[11px] pt-1 border-t border-slate-800/80 space-y-0.5">
                    <div>Accel Force: {w.fallDetected ? "4.2G (Impact Detected)" : "1.02G (Nominal)"}</div>
                    <div>Orientation: Pitch 12°, Roll 4°</div>
                  </div>
                </div>

                {/* 4. MQ Gas Sensor Array */}
                <div className={`p-3 bg-slate-950 border rounded-xl space-y-1 ${w.gasLevel > 180 ? "border-red-500/60 bg-red-950/20" : w.gasLevel > 80 ? "border-amber-500/60 bg-amber-950/20" : "border-slate-800"}`}>
                  <div className="flex justify-between font-bold text-amber-400">
                    <span>4. MQ Gas Sensor Array</span>
                    <span className={w.gasLevel > 180 ? "text-red-400" : "text-amber-300"}>{w.gasLevel} PPM</span>
                  </div>
                  <p className="text-[10px] text-slate-400">Electrochemical CH₄ & CO Gas Monitor</p>
                  <div className="text-slate-300 text-[11px] pt-1 border-t border-slate-800/80 space-y-0.5">
                    <div>Hazard Level: {w.gasLevel > 180 ? "DANGER SURGE" : w.gasLevel > 80 ? "ELEVATED" : "NOMINAL"}</div>
                    <div>Air Quality Index: {Math.max(12, 100 - Math.floor(w.gasLevel / 3))}/100</div>
                  </div>
                </div>

                {/* 5. IR Flame Sensor */}
                <div className={`p-3 bg-slate-950 border rounded-xl space-y-1 ${w.fireDetected ? "border-orange-500/80 bg-orange-950/30" : "border-slate-800"}`}>
                  <div className="flex justify-between font-bold text-orange-400">
                    <span>5. IR Flame Sensor</span>
                    <span className={w.fireDetected ? "text-red-400 font-black animate-pulse" : "text-emerald-400"}>
                      {w.fireDetected ? "FLAME DETECTED!" : "CLEAR"}
                    </span>
                  </div>
                  <p className="text-[10px] text-slate-400">760nm–1100nm Optical Flame Detector</p>
                  <div className="text-slate-300 text-[11px] pt-1 border-t border-slate-800/80 space-y-0.5">
                    <div>Optical Response: {w.fireDetected ? "HIGH IR IGNITION" : "NOMINAL (0 IR)"}</div>
                    <div>Response Time: &lt; 50 ms</div>
                  </div>
                </div>

                {/* 6. Temperature Sensor */}
                <div className={`p-3 bg-slate-950 border rounded-xl space-y-1 ${w.temperature >= 38.5 ? "border-red-500/60 bg-red-950/20" : "border-slate-800"}`}>
                  <div className="flex justify-between font-bold text-amber-400">
                    <span>6. Temperature Sensor</span>
                    <span className={w.temperature >= 38.5 ? "text-red-400" : "text-emerald-400"}>{w.temperature} °C</span>
                  </div>
                  <p className="text-[10px] text-slate-400">NTC Thermal Probe & Heat Monitor</p>
                  <div className="text-slate-300 text-[11px] pt-1 border-t border-slate-800/80 space-y-0.5">
                    <div>Heat Stress: {w.temperature >= 38.5 ? "HIGH FEVER / HEAT STROKE" : "NOMINAL"}</div>
                    <div>Ambient Shaft Temp: 28.4 °C</div>
                  </div>
                </div>

                {/* 7. GPS Module */}
                <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl space-y-1">
                  <div className="flex justify-between font-bold text-cyan-400">
                    <span>7. GPS / Subterranean Beacon</span>
                    <span className="text-emerald-400">ACTIVE</span>
                  </div>
                  <p className="text-[10px] text-slate-400">Shaft Positioning & Depth Beacon</p>
                  <div className="text-slate-300 text-[11px] pt-1 border-t border-slate-800/80 space-y-0.5">
                    <div>GIS: {w.latitude.toFixed(4)}° N, {w.longitude.toFixed(4)}° E</div>
                    <div>Shaft Depth: {w.depthMeters} meters underground</div>
                  </div>
                </div>

                {/* 8. LoRa Radio (SX1276) */}
                <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl space-y-1">
                  <div className="flex justify-between font-bold text-blue-400">
                    <span>8. LoRa SX1276 868MHz</span>
                    <span className="text-cyan-400">{w.communicationStatus}</span>
                  </div>
                  <p className="text-[10px] text-slate-400">Sub-GHz Long-Range Radio Transceiver</p>
                  <div className="text-slate-300 text-[11px] pt-1 border-t border-slate-800/80 space-y-0.5">
                    <div>TX Power: +14 dBm · Packet Loss: 0.0%</div>
                    <div>Mesh Route: Repeater #1 → Gateway</div>
                  </div>
                </div>

                {/* 9. LDR Light Sensor */}
                <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl space-y-1">
                  <div className="flex justify-between font-bold text-yellow-300">
                    <span>9. LDR Light Sensor</span>
                    <span>{w.ldrLux || 45} LUX</span>
                  </div>
                  <p className="text-[10px] text-slate-400">Ambient Photoresistor Dimmer</p>
                  <div className="text-slate-300 text-[11px] pt-1 border-t border-slate-800/80 space-y-0.5">
                    <div>Ambient State: Dark Shaft Atmosphere</div>
                    <div>Auto-Dimming: Active</div>
                  </div>
                </div>

                {/* 10. LED Headlamp & Status RGB */}
                <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl space-y-1">
                  <div className="flex justify-between font-bold text-white">
                    <span>10. High-Intensity LED Light</span>
                    <span className="text-amber-400">{w.headlightOn ? "ON (1000L)" : "AUTO ON"}</span>
                  </div>
                  <p className="text-[10px] text-slate-400">Cree LED + RGB Visual Halo Beacon</p>
                  <div className="text-slate-300 text-[11px] pt-1 border-t border-slate-800/80 space-y-0.5">
                    <div>Visual Status Halo: {w.safetyStatus} Glow</div>
                  </div>
                </div>

                {/* 11. Vibration Motor */}
                <div className={`p-3 bg-slate-950 border rounded-xl space-y-1 ${w.safetyStatus === "CRITICAL" || hasActiveBroadcast ? "border-red-500/60 bg-red-950/20" : "border-slate-800"}`}>
                  <div className="flex justify-between font-bold text-purple-400">
                    <span>11. Vibration Haptic Motor</span>
                    <span className={w.safetyStatus === "CRITICAL" || hasActiveBroadcast ? "text-red-400 font-bold animate-pulse" : "text-slate-400"}>
                      {w.safetyStatus === "CRITICAL" || hasActiveBroadcast ? "ACTIVE 📳" : "STANDBY"}
                    </span>
                  </div>
                  <p className="text-[10px] text-slate-400">Intra-Helmet Tactile Alert Motor</p>
                  <div className="text-slate-300 text-[11px] pt-1 border-t border-slate-800/80 space-y-0.5">
                    <div>Haptic State: {hasActiveBroadcast ? "EVACUATION PULSE" : w.safetyStatus === "CRITICAL" ? "EMERGENCY PULSE" : "IDLE"}</div>
                  </div>
                </div>

                {/* 12. Battery & BMS */}
                <div className="p-3 bg-slate-950 border border-slate-800 rounded-xl space-y-1">
                  <div className="flex justify-between font-bold text-emerald-400">
                    <span>12. Li-Ion Battery & BMS</span>
                    <span>{w.battery}% Charge</span>
                  </div>
                  <p className="text-[10px] text-slate-400">ATEX Zone 0 Certified 4400 mAh Cell</p>
                  <div className="text-slate-300 text-[11px] pt-1 border-t border-slate-800/80 space-y-0.5">
                    <div>Battery Voltage: 3.84 V</div>
                    <div>Estimated Runtime: 14.5 Hours</div>
                  </div>
                </div>
              </div>
            </div>

            {/* ─── STICKY MODAL FOOTER ─── */}
            <div className="p-3.5 sm:px-6 sm:py-4 bg-slate-900 border-t border-slate-800 flex items-center justify-between shrink-0 font-mono text-xs z-10 shadow-lg">
              <button
                type="button"
                onClick={() => updateWorkerSensor(w.id, "noiseCancel", !w.noiseCancel)}
                className="px-3 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold border border-slate-700 transition-colors"
              >
                🔊 Noise Cancel: <strong className={w.noiseCancel ? "text-emerald-400" : "text-slate-400"}>{w.noiseCancel ? "ACTIVE" : "OFF"}</strong>
              </button>

              <button
                type="button"
                onClick={closeDiagnostics}
                className="min-h-[44px] px-5 py-2.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-black font-bold tracking-wider uppercase transition-colors shadow-md cursor-pointer flex items-center justify-center select-none"
                aria-label="Close worker diagnostics"
              >
                CLOSE DIAGNOSTICS
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
