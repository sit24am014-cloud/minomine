// client/src/components/ui/VitalsChart.jsx
// Compact sparkline-style heart rate trend chart

import React, { useMemo } from "react";
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  YAxis,
  Tooltip,
} from "recharts";

const CustomTooltip = ({ active, payload }) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-mine-surface border border-mine-neon/20 rounded px-2 py-1">
      <span className="font-mono text-xs text-mine-cyan">{payload[0].value} bpm</span>
    </div>
  );
};

export default function VitalsChart({ data = [], color = "#00d4ff" }) {
  const chartData = useMemo(
    () => data.map((v, i) => ({ t: i, hr: v })),
    [data]
  );

  const min = Math.min(...data) - 5;
  const max = Math.max(...data) + 5;

  return (
    <div className="w-full h-full">
      <div className="flex items-center justify-between mb-1">
        <span className="text-[9px] font-mono text-white/25 uppercase tracking-widest">HR Trend (30 readings)</span>
        <span className="text-[9px] font-mono" style={{ color }}>
          {data[data.length - 1]} bpm
        </span>
      </div>
      <ResponsiveContainer width="100%" height={52}>
        <AreaChart data={chartData} margin={{ top: 2, right: 2, left: 0, bottom: 0 }}>
          <defs>
            <linearGradient id={`grad-${color.replace("#","")}`} x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%"  stopColor={color} stopOpacity={0.25} />
              <stop offset="95%" stopColor={color} stopOpacity={0}    />
            </linearGradient>
          </defs>
          <YAxis domain={[min, max]} hide />
          <Tooltip content={<CustomTooltip />} />
          <Area
            type="monotone"
            dataKey="hr"
            stroke={color}
            strokeWidth={1.5}
            fill={`url(#grad-${color.replace("#","")})`}
            dot={false}
            isAnimationActive={false}
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}
