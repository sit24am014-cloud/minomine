// client/src/components/ui/IncidentCenter.jsx
// Incident Log & Emergency Response Center for MINO MINE

import React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useMinoMine } from "../../context/MinoMineContext";

const EMERGENCY_BADGES = {
  FALL: { label: "MPU6050 FALL DETECTED", icon: "🤸", color: "#ff1744" },
  FIRE: { label: "FLAME SENSOR FIRE", icon: "🔥", color: "#ff1744" },
  GAS_LEAK: { label: "MQ GAS LEAK SURGE", icon: "☁️", color: "#ffab00" },
  HIGH_TEMPERATURE: { label: "HEAT-STROKE THERMAL", icon: "🌡️", color: "#ffab00" },
  ABNORMAL_HEART_RATE: { label: "PPG HEART RATE SPIKE", icon: "❤️", color: "#ff1744" },
  MEDICAL: { label: "CRITICAL VITALS DROP", icon: "🚑", color: "#ff1744" },
  MISSING_WORKER: { label: "LORA telemetry OFFLINE", icon: "📡", color: "#999999" },
  MANUAL_EMERGENCY: { label: "SOS MANUAL BUTTON", icon: "🚨", color: "#ff1744" },
};

export default function IncidentCenter() {
  const { incidents, acknowledgeIncident, resolveIncident } = useMinoMine();

  const activeIncidents = incidents.filter((i) => i.status !== "RESOLVED");

  if (incidents.length === 0) return null;

  return (
    <div className="glass rounded-2xl p-6 mb-8 border border-white/10">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <span className="w-2.5 h-2.5 rounded-full bg-mine-danger animate-pulse" />
          <h3 className="font-display font-bold text-white text-lg">
            Emergency Incident Management Center ({activeIncidents.length} Active)
          </h3>
        </div>
        <span className="text-[10px] font-mono text-white/40">SIH 2026 Response Log</span>
      </div>

      <div className="space-y-3 max-h-96 overflow-y-auto pr-2">
        <AnimatePresence>
          {incidents.slice(0, 10).map((inc) => {
            const badge = EMERGENCY_BADGES[inc.type] || {
              label: inc.type,
              icon: "⚠️",
              color: "#ffab00",
            };

            const isUnack = inc.acknowledgementStatus === "UNACKNOWLEDGED";

            return (
              <motion.div
                key={inc.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, height: 0 }}
                className={`p-4 rounded-xl border flex flex-col md:flex-row md:items-center justify-between gap-4 transition-all ${
                  inc.status === "RESOLVED"
                    ? "bg-white/[0.02] border-white/10 opacity-60"
                    : isUnack
                    ? "bg-red-950/30 border-red-500/50 shadow-[0_0_15px_rgba(255,23,68,0.2)]"
                    : "bg-orange-950/20 border-orange-500/30"
                }`}
              >
                <div className="flex items-start gap-3">
                  <div className="text-2xl mt-0.5">{badge.icon}</div>
                  <div>
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-mono text-xs font-bold text-white">{inc.id}</span>
                      <span
                        className="text-[9px] font-mono font-bold px-2 py-0.5 rounded border"
                        style={{
                          color: badge.color,
                          borderColor: `${badge.color}66`,
                          background: `${badge.color}15`,
                        }}
                      >
                        {badge.label}
                      </span>
                      <span className="text-[9px] font-mono text-white/40">
                        {new Date(inc.timestamp).toLocaleTimeString()}
                      </span>
                    </div>

                    <p className="font-display font-semibold text-white text-sm mt-1">
                      {inc.workerName} ({inc.workerId}) —{" "}
                      <span className="text-mine-neon">{inc.location}</span>
                    </p>

                    {/* Sensor snapshot */}
                    <div className="flex items-center gap-3 font-mono text-[10px] text-white/50 mt-1 flex-wrap">
                      <span>HR: {inc.sensorValues.heartRate} BPM</span>
                      <span>Gas: {inc.sensorValues.gasLevel} PPM</span>
                      <span>Temp: {inc.sensorValues.temperature} °C</span>
                      <span>SpO₂: {inc.sensorValues.spO2 || "--"}%</span>
                      <span>Battery: {inc.sensorValues.battery}%</span>
                    </div>
                  </div>
                </div>

                {/* Response Action Buttons */}
                <div className="flex items-center gap-2 self-end md:self-center">
                  {inc.status !== "RESOLVED" && isUnack && (
                    <button
                      onClick={() => acknowledgeIncident(inc.id)}
                      className="text-[10px] font-mono font-bold px-3 py-1.5 rounded bg-yellow-500/20 text-yellow-300 border border-yellow-500/40 hover:bg-yellow-500/30 transition-all"
                    >
                      ACKNOWLEDGE
                    </button>
                  )}

                  {inc.status !== "RESOLVED" && (
                    <button
                      onClick={() => resolveIncident(inc.id)}
                      className="text-[10px] font-mono font-bold px-3 py-1.5 rounded bg-mine-safe/20 text-mine-safe border border-mine-safe/40 hover:bg-mine-safe/30 transition-all"
                    >
                      RESOLVE INCIDENT
                    </button>
                  )}

                  {inc.status === "RESOLVED" && (
                    <span className="text-[10px] font-mono text-mine-safe border border-mine-safe/30 px-2 py-1 rounded bg-mine-safe/10">
                      ✓ RESOLVED
                    </span>
                  )}
                </div>
              </motion.div>
            );
          })}
        </AnimatePresence>
      </div>
    </div>
  );
}
