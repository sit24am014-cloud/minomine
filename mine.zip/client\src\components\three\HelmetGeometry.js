// client/src/components/three/HelmetGeometry.js
// Builds the 3D WebGL Smart Helmet containing all 12 SIH 2026 hardware components

import * as THREE from "three";

function helmetMaterial(color = 0x1a1a2e, rough = 0.25, metal = 0.7) {
  return new THREE.MeshStandardMaterial({ color, roughness: rough, metalness: metal });
}

function emissiveMat(color, emissive, intensity = 0.8) {
  return new THREE.MeshStandardMaterial({
    color,
    emissive,
    emissiveIntensity: intensity,
    roughness: 0.4,
    metalness: 0.3,
  });
}

function glassMat(color = 0x00aaff, opacity = 0.25) {
  return new THREE.MeshStandardMaterial({
    color,
    transparent: true,
    opacity,
    roughness: 0.05,
    metalness: 0.1,
    side: THREE.DoubleSide,
  });
}

export function buildHelmet() {
  const helmetGroup = new THREE.Group();
  const shellGroup = new THREE.Group();
  const baseGroup = new THREE.Group();
  const internalParts = [];

  // ── Outer Dome Top Shell ──
  const domeGeo = new THREE.SphereGeometry(1.1, 64, 32, 0, Math.PI * 2, 0, Math.PI / 1.7);
  const dome = new THREE.Mesh(domeGeo, helmetMaterial(0x1a1a2e));
  dome.castShadow = true;
  shellGroup.add(dome);

  // ── Brim ──
  const brimGeo = new THREE.CylinderGeometry(1.28, 1.32, 0.09, 64);
  const brim = new THREE.Mesh(brimGeo, helmetMaterial(0x151525));
  brim.position.y = -0.52;
  shellGroup.add(brim);

  // ── Front Peak ──
  const peakGeo = new THREE.BoxGeometry(0.65, 0.06, 0.38);
  const peak = new THREE.Mesh(peakGeo, helmetMaterial(0x111120));
  peak.position.set(0, -0.52, 1.22);
  shellGroup.add(peak);

  // ── Visor Arc ──
  const visorGeo = new THREE.SphereGeometry(1.05, 32, 16, -0.5, 1.0, 0.3, 0.9);
  const visorMat = glassMat(0x00aaff, 0.25);
  const visor = new THREE.Mesh(visorGeo, visorMat);
  shellGroup.add(visor);

  // ── Neon Strip ──
  const stripeGeo = new THREE.TorusGeometry(1.28, 0.025, 8, 64);
  const stripe = new THREE.Mesh(stripeGeo, emissiveMat(0xff6600, 0xff6600, 1.2));
  stripe.position.y = -0.52;
  stripe.rotation.x = Math.PI / 2;
  shellGroup.add(stripe);

  helmetGroup.add(shellGroup);

  // ── Inner Base Housing ──
  const innerGeo = new THREE.SphereGeometry(1.05, 32, 16, 0, Math.PI * 2, 0, Math.PI / 1.8);
  const inner = new THREE.Mesh(
    innerGeo,
    new THREE.MeshStandardMaterial({ color: 0x0d0d18, roughness: 0.8, side: THREE.BackSide })
  );
  baseGroup.add(inner);

  // ─────────────────────────────────────────────────────────────────────────
  // 12 HARDWARE COMPONENTS REVEALED ON EXPLOSION
  // ─────────────────────────────────────────────────────────────────────────

  // 1. ESP32 MCU SoC Module
  const espGeo = new THREE.BoxGeometry(0.5, 0.04, 0.35);
  const espMesh = new THREE.Mesh(espGeo, emissiveMat(0x002b15, 0x00ff88, 0.7));
  espMesh.position.set(0, 0.1, 0);
  espMesh.userData = { componentId: "esp32", label: "1. ESP32 MCU SoC" };
  // Metal Shield IC
  const shield = new THREE.Mesh(
    new THREE.BoxGeometry(0.2, 0.03, 0.2),
    new THREE.MeshStandardMaterial({ color: 0xcccccc, metalness: 0.9, roughness: 0.1 })
  );
  shield.position.set(-0.08, 0.03, 0);
  espMesh.add(shield);
  internalParts.push(espMesh);
  baseGroup.add(espMesh);

  // 2. MAX30102 PPG Pulse Oximeter & HR
  const maxGeo = new THREE.CylinderGeometry(0.08, 0.08, 0.04, 24);
  const maxMesh = new THREE.Mesh(maxGeo, emissiveMat(0x2a0000, 0xff0044, 1.8));
  maxMesh.position.set(-0.45, 0.25, 0.5);
  maxMesh.userData = { componentId: "max30102", label: "2. MAX30102 PPG HR Sensor" };
  internalParts.push(maxMesh);
  baseGroup.add(maxMesh);

  // 3. MPU6050 6-Axis IMU (Fall Sensor)
  const mpuGeo = new THREE.BoxGeometry(0.18, 0.05, 0.18);
  const mpuMesh = new THREE.Mesh(mpuGeo, emissiveMat(0x2a2a00, 0xffaa00, 1.2));
  mpuMesh.position.set(0.45, 0.25, 0.5);
  mpuMesh.userData = { componentId: "mpu6050", label: "3. MPU6050 6-Axis IMU (Fall)" };
  internalParts.push(mpuMesh);
  baseGroup.add(mpuMesh);

  // 4. MQ Gas Sensor Array
  const mqGeo = new THREE.CylinderGeometry(0.1, 0.1, 0.12, 24);
  const mqMesh = new THREE.Mesh(mqGeo, emissiveMat(0x332200, 0xff8800, 1.0));
  mqMesh.position.set(0, 0.55, 0.55);
  mqMesh.userData = { componentId: "mq_gas", label: "4. MQ Gas Sensor (CH4/CO)" };
  internalParts.push(mqMesh);
  baseGroup.add(mqMesh);

  // 5. Flame IR Sensor
  const flameGeo = new THREE.CylinderGeometry(0.05, 0.05, 0.1, 16);
  const flameMesh = new THREE.Mesh(flameGeo, emissiveMat(0x330000, 0xff0000, 2.0));
  flameMesh.position.set(0.25, 0.45, 0.7);
  flameMesh.userData = { componentId: "flame_sensor", label: "5. IR Flame Sensor" };
  internalParts.push(flameMesh);
  baseGroup.add(flameMesh);

  // 6. Temperature Sensor Probe
  const tempGeo = new THREE.CylinderGeometry(0.03, 0.03, 0.15, 12);
  const tempMesh = new THREE.Mesh(tempGeo, emissiveMat(0x001a33, 0x00d4ff, 1.0));
  tempMesh.position.set(-0.25, 0.45, 0.7);
  tempMesh.userData = { componentId: "temp_sensor", label: "6. Temp Sensor Probe" };
  internalParts.push(tempMesh);
  baseGroup.add(tempMesh);

  // 7. GPS Module
  const gpsGeo = new THREE.BoxGeometry(0.22, 0.05, 0.22);
  const gpsMesh = new THREE.Mesh(gpsGeo, emissiveMat(0x002233, 0x00e676, 0.9));
  gpsMesh.position.set(-0.45, 0.1, -0.2);
  gpsMesh.userData = { componentId: "gps", label: "7. GPS / Subterranean Beacon" };
  internalParts.push(gpsMesh);
  baseGroup.add(gpsMesh);

  // 8. LoRa SX1276 Radio Module
  const loraGeo = new THREE.BoxGeometry(0.35, 0.06, 0.22);
  const loraMesh = new THREE.Mesh(loraGeo, emissiveMat(0x001a1a, 0x00d4ff, 0.8));
  loraMesh.position.set(0.45, 0.1, -0.2);
  loraMesh.userData = { componentId: "lora", label: "8. LoRa SX1276 Radio" };
  const ant = new THREE.Mesh(
    new THREE.CylinderGeometry(0.015, 0.015, 0.35, 8),
    new THREE.MeshStandardMaterial({ color: 0xaaaaaa, metalness: 0.9 })
  );
  ant.position.set(0.12, 0.2, 0);
  loraMesh.add(ant);
  internalParts.push(loraMesh);
  baseGroup.add(loraMesh);

  // 9. LDR Light Sensor
  const ldrGeo = new THREE.CylinderGeometry(0.04, 0.04, 0.03, 16);
  const ldrMesh = new THREE.Mesh(ldrGeo, emissiveMat(0x333300, 0xffff00, 1.5));
  ldrMesh.position.set(0, -0.15, 1.15);
  ldrMesh.userData = { componentId: "ldr", label: "9. LDR Light Sensor" };
  internalParts.push(ldrMesh);
  baseGroup.add(ldrMesh);

  // 10. LED Headlamp
  const ledGeo = new THREE.BoxGeometry(0.5, 0.06, 0.06);
  const ledMesh = new THREE.Mesh(ledGeo, emissiveMat(0xffffff, 0xffffff, 2.5));
  ledMesh.position.set(0, -0.1, 1.1);
  ledMesh.userData = { componentId: "led_headlamp", label: "10. Cree LED Headlamp" };
  internalParts.push(ledMesh);
  baseGroup.add(ledMesh);

  // 11. Intra-Helmet Vibration Motor
  const vibGeo = new THREE.CylinderGeometry(0.08, 0.08, 0.05, 20);
  const vibMesh = new THREE.Mesh(vibGeo, emissiveMat(0x330033, 0xff00ff, 1.5));
  vibMesh.position.set(0.35, -0.1, 0.3);
  vibMesh.userData = { componentId: "vibration_motor", label: "11. Vibration Motor" };
  internalParts.push(vibMesh);
  baseGroup.add(vibMesh);

  // 12. Li-Ion Battery Pack
  const batGeo = new THREE.BoxGeometry(0.55, 0.08, 0.2);
  const batMesh = new THREE.Mesh(batGeo, helmetMaterial(0x1a1a00, 0.6, 0.3));
  batMesh.position.set(0, -0.1, -0.6);
  batMesh.userData = { componentId: "battery", label: "12. Li-Ion Battery & BMS" };
  internalParts.push(batMesh);
  baseGroup.add(batMesh);

  helmetGroup.add(baseGroup);
  helmetGroup.position.y = -0.3;

  return {
    helmetGroup,
    shellGroup,
    internalParts,
    visorMesh: visor,
  };
}

export function buildLights(scene) {
  const ambient = new THREE.AmbientLight(0xffffff, 0.4);
  scene.add(ambient);

  const key = new THREE.DirectionalLight(0xff8833, 1.5);
  key.position.set(3, 3, 4);
  scene.add(key);

  const fill = new THREE.DirectionalLight(0x336699, 0.8);
  fill.position.set(-4, 1, -2);
  scene.add(fill);

  const rim = new THREE.PointLight(0x00d4ff, 0.7, 8);
  rim.position.set(0, 3, -3);
  scene.add(rim);
}
