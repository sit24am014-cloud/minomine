// client/src/views/HomeView.jsx
// Command Center Overview & System Health Matrix for MINO MINE

import React from "react";
import { motion } from "framer-motion";
import { useMinoMine } from "../context/MinoMineContext";
import SubterraneanZoneMap from "../components/ui/SubterraneanZoneMap";
import IncidentCenter from "../components/ui/IncidentCenter";

export default function HomeView({ onNavigate }) {
  const { workers, incidents, activeEmergency, clearAllEmergencies, triggerHazardEvent } = useMinoMine();

  const safeCount = workers.filter((w) => w.safetyStatus === "SAFE").length;
  const warnCount = workers.filter((w) => w.safetyStatus === "WARNING").length;
  const critCount = workers.filter((w) => w.safetyStatus === "CRITICAL").length;
  const offCount = workers.filter((w) => w.safetyStatus === "OFFLINE").length;

  return (
    <div className="space-y-8">
      {/* Page Mandatory Title Header */}
      <div className="command-panel p-6 border-l-4 border-l-amber-500">
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="font-mono text-xs font-bold text-amber-500 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/30">
                MINO MINE
              </span>
              <span className="font-mono text-xs text-slate-400">
                UNDERGROUND MINING SAFETY SYSTEM
              </span>
            </div>
            <h1 className="font-display text-2xl font-black text-white">
              COMMAND CENTER OVERVIEW
            </h1>
          </div>
          <div className="flex items-center gap-3">
            <span className="font-mono text-xs px-3 py-1.5 rounded bg-slate-800 text-amber-400 border border-slate-700">
              DEMO / SIMULATION MODE
            </span>
            <button
              onClick={() => onNavigate("SENSOR SIMULATOR")}
              className="font-mono text-xs font-bold px-4 py-2 rounded bg-amber-500 text-black hover:bg-amber-400 transition-colors shadow-lg"
            >
              ⚡ LAUNCH SENSOR SIMULATOR
            </button>
          </div>
        </div>
      </div>

      {/* Industrial Key Metrics Row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="command-panel p-5">
          <div className="font-mono text-xs text-slate-400 uppercase">Underground Workers</div>
          <div className="font-mono text-3xl font-bold text-white mt-1">12</div>
          <div className="font-mono text-[10px] text-slate-500 mt-1">Smart Helmets Connected</div>
        </div>
        <div className="command-panel p-5">
          <div className="font-mono text-xs text-slate-400 uppercase">Nominal / Safe</div>
          <div className="font-mono text-3xl font-bold text-emerald-400 mt-1">{safeCount}</div>
          <div className="font-mono text-[10px] text-emerald-500/70 mt-1">Optimal Vitals</div>
        </div>
        <div className="command-panel p-5">
          <div className="font-mono text-xs text-slate-400 uppercase">Elevated / Warning</div>
          <div className="font-mono text-3xl font-bold text-amber-400 mt-1">{warnCount}</div>
          <div className="font-mono text-[10px] text-amber-500/70 mt-1">Gas / Temp Elevated</div>
        </div>
        <div className="command-panel p-5">
          <div className="font-mono text-xs text-slate-400 uppercase">Critical / Incidents</div>
          <div className="font-mono text-3xl font-bold text-red-500 mt-1">{critCount}</div>
          <div className="font-mono text-[10px] text-red-400/70 mt-1">Immediate Action Required</div>
        </div>
      </div>

      {/* Quick Launch Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div
          onClick={() => onNavigate("SMART HELMET")}
          className="command-panel p-6 hover:border-amber-500/60 cursor-pointer transition-all group"
        >
          <div className="text-3xl mb-3">🪖</div>
          <h3 className="font-display font-bold text-lg text-white group-hover:text-amber-500 transition-colors">
            12-Sensor Smart Helmet
          </h3>
          <p className="font-body text-xs text-slate-400 mt-2 leading-relaxed">
            Inspect the 3D WebGL exploded view of ESP32, MAX30102 PPG, MPU6050 fall detector, MQ gas array, and LoRa module.
          </p>
          <div className="mt-4 font-mono text-xs text-amber-500 font-semibold flex items-center gap-1">
            OPEN 3D MODEL →
          </div>
        </div>

        <div
          onClick={() => onNavigate("CONTROL ROOM")}
          className="command-panel p-6 hover:border-amber-500/60 cursor-pointer transition-all group"
        >
          <div className="text-3xl mb-3">🗺️</div>
          <h3 className="font-display font-bold text-lg text-white group-hover:text-amber-500 transition-colors">
            Control Room & Shaft Map
          </h3>
          <p className="font-body text-xs text-slate-400 mt-2 leading-relaxed">
            View real-time subterranean mine shaft corridor locations, miner depths, and live worker telemetry cards.
          </p>
          <div className="mt-4 font-mono text-xs text-amber-500 font-semibold flex items-center gap-1">
            VIEW CONTROL ROOM →
          </div>
        </div>

        <div
          onClick={() => onNavigate("EMERGENCY CENTER")}
          className="command-panel p-6 hover:border-amber-500/60 cursor-pointer transition-all group"
        >
          <div className="text-3xl mb-3">🚨</div>
          <h3 className="font-display font-bold text-lg text-white group-hover:text-amber-500 transition-colors">
            Emergency Incident Center
          </h3>
          <p className="font-body text-xs text-slate-400 mt-2 leading-relaxed">
            Manage active subterranean emergency responses, fall incidents, gas surges, and acknowledge rescue dispatches.
          </p>
          <div className="mt-4 font-mono text-xs text-amber-500 font-semibold flex items-center gap-1">
            OPEN INCIDENTS ({incidents.length}) →
          </div>
        </div>
      </div>

      {/* Interactive Underground GIS Floorplan Map */}
      <SubterraneanZoneMap />

      {/* Emergency Incident Log */}
      <IncidentCenter />
    </div>
  );
}
