// client/src/components/ui/WorkerCard.jsx
// Individual worker monitoring card with real-time 12-sensor telemetry display

import React, { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import VitalsChart from "./VitalsChart";
import { useMinoMine } from "../../context/MinoMineContext";

const STATUS_CONFIG = {
  SAFE: { label: "SAFE", color: "#00e676", bg: "rgba(0,230,118,0.08)" },
  WARNING: { label: "WARNING", color: "#ffab00", bg: "rgba(255,171,0,0.1)" },
  CRITICAL: { label: "CRITICAL", color: "#ff1744", bg: "rgba(255,23,68,0.15)" },
  OFFLINE: { label: "OFFLINE", color: "#888888", bg: "rgba(255,255,255,0.03)" },
};

function VitalBadge({ label, value, unit, warn = false, danger = false }) {
  const color = danger ? "#ff1744" : warn ? "#ffab00" : "#00d4ff";
  return (
    <div className="flex flex-col gap-0.5">
      <span className="text-[9px] font-mono text-white/30 uppercase tracking-widest">{label}</span>
      <span className="font-mono text-xs font-bold" style={{ color }}>
        {value}
        <span className="text-[9px] font-normal text-white/40 ml-0.5">{unit}</span>
      </span>
    </div>
  );
}

export default function WorkerCard({ worker }) {
  const { setSelectedWorkerId, selectedWorkerId, updateWorkerSensor } = useMinoMine();
  const [showChart, setShowChart] = useState(false);

  const cfg = STATUS_CONFIG[worker.safetyStatus] || STATUS_CONFIG.SAFE;
  const isEmergency = worker.safetyStatus === "CRITICAL";
  const isSelected = selectedWorkerId === worker.id;

  return (
    <motion.div
      layout
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      onClick={() => setSelectedWorkerId(worker.id)}
      className={`glass glow-border rounded-xl p-4 cursor-pointer select-none transition-all ${
        isSelected ? "ring-2 ring-mine-neon border-mine-neon" : ""
      }`}
      style={{
        background: cfg.bg,
        borderColor: `${cfg.color}44`,
        animation: isEmergency ? "pulse-alert 0.8s ease-in-out infinite" : undefined,
      }}
      whileHover={{ scale: 1.01, y: -2 }}
      whileTap={{ scale: 0.99 }}
    >
      {/* Header */}
      <div className="flex items-start justify-between mb-3">
        <div>
          <div className="flex items-center gap-2 mb-0.5">
            <span className="font-mono text-xs text-mine-neon font-bold">{worker.id}</span>
            <span
              className="text-[9px] font-mono font-bold px-1.5 py-0.5 rounded border"
              style={{ color: cfg.color, background: `${cfg.color}22`, borderColor: `${cfg.color}55` }}
            >
              {cfg.label}
            </span>
          </div>
          <p className="font-display font-semibold text-white text-sm leading-tight">{worker.name}</p>
          <p className="text-[10px] text-white/40 font-mono mt-0.5">
            {worker.zone} ({worker.depthMeters}m)
          </p>
        </div>

        {/* Battery & Status */}
        <div className="flex flex-col items-end gap-1">
          <div className="flex items-center gap-1">
            <div className="w-5 h-3 border border-white/20 rounded-sm relative overflow-hidden">
              <div
                className="h-full rounded-sm transition-all duration-500"
                style={{
                  width: `${worker.battery}%`,
                  background: worker.battery > 30 ? "#00e676" : "#ff1744",
                }}
              />
            </div>
            <span className="text-[9px] font-mono text-white/30">{worker.battery}%</span>
          </div>
          <span className="text-[9px] font-mono text-white/30">{worker.shift} Shift</span>
        </div>
      </div>

      {/* Hazard Badges if triggered */}
      {(worker.fallDetected || worker.fireDetected || worker.gasLevel >= 80 || worker.heartRate > 100 || worker.heartRate < 45 || worker.temperature >= 37.8 || (worker.spO2 && worker.spO2 < 92) || worker.systolicBP > 140) && (
        <div className="flex items-center gap-1.5 mb-3 flex-wrap">
          {worker.fallDetected && (
            <span className="text-[9px] font-mono font-bold px-2 py-0.5 rounded bg-red-500/20 text-red-400 border border-red-500/40 animate-pulse">
              🤸 FALL DETECTED
            </span>
          )}
          {worker.fireDetected && (
            <span className="text-[9px] font-mono font-bold px-2 py-0.5 rounded bg-orange-500/20 text-orange-400 border border-orange-500/40 animate-pulse">
              🔥 FIRE DETECTED
            </span>
          )}
          {worker.gasLevel >= 180 && (
            <span className="text-[9px] font-mono font-bold px-2 py-0.5 rounded bg-yellow-500/20 text-yellow-400 border border-yellow-500/40 animate-pulse">
              ☁️ GAS SURGE ({worker.gasLevel} PPM)
            </span>
          )}
          {worker.gasLevel >= 80 && worker.gasLevel < 180 && (
            <span className="text-[9px] font-mono font-bold px-2 py-0.5 rounded bg-amber-500/20 text-amber-400 border border-amber-500/40">
              ☁️ ELEVATED GAS ({worker.gasLevel} PPM)
            </span>
          )}
          {(worker.heartRate > 125 || worker.heartRate < 45) && (
            <span className="text-[9px] font-mono font-bold px-2 py-0.5 rounded bg-red-500/20 text-red-400 border border-red-500/40 animate-pulse">
              ❤️ HIGH HEART RATE ({worker.heartRate} BPM)
            </span>
          )}
          {worker.heartRate > 100 && worker.heartRate <= 125 && (
            <span className="text-[9px] font-mono font-bold px-2 py-0.5 rounded bg-amber-500/20 text-amber-400 border border-amber-500/40">
              ❤️ ELEVATED HR ({worker.heartRate} BPM)
            </span>
          )}
          {worker.temperature >= 38.5 && (
            <span className="text-[9px] font-mono font-bold px-2 py-0.5 rounded bg-red-500/20 text-red-400 border border-red-500/40 animate-pulse">
              🌡️ HIGH TEMP ({worker.temperature}°C)
            </span>
          )}
          {worker.temperature >= 37.8 && worker.temperature < 38.5 && (
            <span className="text-[9px] font-mono font-bold px-2 py-0.5 rounded bg-amber-500/20 text-amber-400 border border-amber-500/40">
              🌡️ ELEVATED TEMP ({worker.temperature}°C)
            </span>
          )}
          {worker.spO2 && worker.spO2 < 92 && (
            <span className="text-[9px] font-mono font-bold px-2 py-0.5 rounded bg-purple-500/20 text-purple-400 border border-purple-500/40 animate-pulse">
              🫁 LOW SpO₂ ({worker.spO2}%)
            </span>
          )}
          {worker.systolicBP > 140 && (
            <span className="text-[9px] font-mono font-bold px-2 py-0.5 rounded bg-red-500/20 text-red-400 border border-red-500/40">
              🩸 HIGH BP ({worker.systolicBP}/{worker.diastolicBP})
            </span>
          )}
        </div>
      )}

      {/* Vitals Grid */}
      <div className="grid grid-cols-4 gap-2 mb-3">
        <VitalBadge
          label="HR"
          value={worker.heartRate}
          unit="bpm"
          warn={worker.heartRate > 100}
          danger={worker.heartRate > 125 || worker.heartRate < 45}
        />
        <VitalBadge
          label="BP"
          value={`${worker.systolicBP}/${worker.diastolicBP}`}
          unit="mmHg"
          warn={worker.systolicBP > 130}
          danger={worker.systolicBP > 145}
        />
        <VitalBadge
          label="SpO₂"
          value={worker.spO2 || 98}
          unit="%"
          warn={(worker.spO2 || 98) < 95}
          danger={(worker.spO2 || 98) < 90}
        />
        <VitalBadge
          label="TEMP"
          value={worker.temperature}
          unit="°C"
          warn={worker.temperature > 37.3}
          danger={worker.temperature > 38.4}
        />
      </div>

      {/* Extended Hardware Row */}
      <div className="flex items-center justify-between text-[9px] font-mono text-white/30 pt-2 border-t border-white/5">
        <div className="flex items-center gap-3">
          <span>GAS: <strong className={worker.gasLevel > 80 ? "text-yellow-400" : "text-white"}>{worker.gasLevel} PPM</strong></span>
          <span>RESP: <strong className="text-white">{worker.respiration}</strong></span>
          <span>LDR: <strong className="text-white">{worker.ldrLux || 45} lx</strong></span>
        </div>
        <button
          className="text-mine-neon/60 hover:text-mine-neon transition-colors font-bold"
          onClick={(e) => {
            e.stopPropagation();
            setShowChart((v) => !v);
          }}
        >
          {showChart ? "HIDE TREND ▲" : "TREND ▼"}
        </button>
      </div>

      {/* Trend Chart */}
      <AnimatePresence>
        {showChart && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 80, opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="overflow-hidden mt-3 border-t border-white/5 pt-2"
          >
            <VitalsChart data={worker.hrHistory || []} color={cfg.color} />
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}
