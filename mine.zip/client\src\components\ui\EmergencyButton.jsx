// client/src/components/ui/EmergencyButton.jsx
// Dramatic button that triggers emergency simulation via socket

import React, { useState } from "react";
import { motion } from "framer-motion";

export default function EmergencyButton({ socket, activeEmergency }) {
  const [fired, setFired] = useState(false);

  const trigger = () => {
    if (!socket || activeEmergency) return;
    socket.emit("trigger_emergency");
    setFired(true);
    setTimeout(() => setFired(false), 9000);
  };

  const clear = () => {
    if (!socket) return;
    socket.emit("clear_emergency");
    setFired(false);
  };

  return (
    <div className="flex items-center gap-3">
      <motion.button
        onClick={activeEmergency ? clear : trigger}
        disabled={fired && !activeEmergency}
        whileHover={{ scale: 1.03 }}
        whileTap={{ scale: 0.97 }}
        className="relative overflow-hidden px-5 py-2.5 rounded-lg font-display font-bold text-sm tracking-widest uppercase transition-all"
        style={{
          background:   activeEmergency
            ? "rgba(255,23,68,0.2)"
            : "rgba(255,107,0,0.15)",
          border:       `1px solid ${activeEmergency ? "#ff1744" : "#ff6b00"}`,
          color:        activeEmergency ? "#ff1744" : "#ff6b00",
          boxShadow:    activeEmergency
            ? "0 0 20px rgba(255,23,68,0.3)"
            : "0 0 12px rgba(255,107,0,0.15)",
          animation:    activeEmergency ? "glow-ring 1s ease-in-out infinite" : undefined,
        }}
      >
        {/* Animated background sweep on hover */}
        <motion.span
          className="absolute inset-0 rounded-lg"
          style={{ background: activeEmergency ? "rgba(255,23,68,0.08)" : "rgba(255,107,0,0.05)" }}
          initial={{ x: "-100%" }}
          whileHover={{ x: "100%" }}
          transition={{ duration: 0.4 }}
        />
        <span className="relative z-10">
          {activeEmergency ? "⚠ CLEAR EMERGENCY" : "⚡ SIMULATE EMERGENCY"}
        </span>
      </motion.button>

      {activeEmergency && (
        <motion.div
          initial={{ opacity: 0, x: -10 }}
          animate={{ opacity: 1, x: 0 }}
          className="flex items-center gap-2"
        >
          <div className="w-2 h-2 rounded-full bg-mine-danger animate-ping" />
          <span className="text-xs font-mono text-mine-danger">ACTIVE</span>
        </motion.div>
      )}
    </div>
  );
}
