// client/src/hooks/useSocket.js
// Manages Socket.io connection lifecycle and all real-time state

import { useEffect, useRef, useState, useCallback } from "react";
import { io } from "socket.io-client";

export default function useSocket(url) {
  const socketRef = useRef(null);
  const [isConnected,    setIsConnected]    = useState(false);
  const [workers,        setWorkers]        = useState([]);
  const [alerts,         setAlerts]         = useState([]);
  const [activeEmergency,setActiveEmergency]= useState(false);
  const [systemStatus,   setSystemStatus]   = useState({ connected: 0 });

  useEffect(() => {
    const socket = io(url, {
      transports:       ["websocket", "polling"],
      reconnectionDelay: 1000,
      reconnectionAttempts: 10,
    });
    socketRef.current = socket;

    socket.on("connect",    () => setIsConnected(true));
    socket.on("disconnect", () => setIsConnected(false));

    // Full initial worker list on first connect
    socket.on("initial_state", (snapshot) => {
      setWorkers(snapshot);
    });

    // Incremental per-worker telemetry update
    socket.on("worker_update", (update) => {
      setWorkers(prev => {
        const idx = prev.findIndex(w => w.id === update.id);
        if (idx === -1) return [...prev, update];
        const next = [...prev];
        next[idx] = update;
        return next;
      });
    });

    // Emergency broadcast
    socket.on("emergency_alert", (payload) => {
      setActiveEmergency(true);
      setAlerts(prev => [
        { ...payload, id: Date.now() },
        ...prev.slice(0, 9), // keep last 10 alerts
      ]);
    });

    // Emergency resolved
    socket.on("emergency_cleared", () => {
      setActiveEmergency(false);
    });

    // Noise cancellation state change
    socket.on("noise_cancel_update", ({ workerId, active }) => {
      setWorkers(prev =>
        prev.map(w => w.id === workerId ? { ...w, noiseCancel: active } : w)
      );
    });

    socket.on("system_status", (status) => {
      setSystemStatus(status);
      if (status.emergencyActive !== undefined) {
        setActiveEmergency(status.emergencyActive);
      }
    });

    return () => {
      socket.disconnect();
    };
  }, [url]);

  // Expose the raw socket so components can emit events
  const getSocket = useCallback(() => socketRef.current, []);

  return {
    socket:         socketRef.current,
    isConnected,
    workers,
    alerts,
    activeEmergency,
    systemStatus,
  };
}
