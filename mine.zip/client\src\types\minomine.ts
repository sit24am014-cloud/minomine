// client/src/types/minomine.ts
// Core TypeScript interfaces for MINO MINE SIH 2026

export type SafetyStatus = "SAFE" | "WARNING" | "CRITICAL" | "OFFLINE";

export type CommunicationStatus = "ONLINE" | "DEGRADED" | "OFFLINE";

export type EmergencyType =
  | "FALL"
  | "FIRE"
  | "GAS_LEAK"
  | "MEDICAL"
  | "HIGH_TEMPERATURE"
  | "ABNORMAL_HEART_RATE"
  | "MISSING_WORKER"
  | "MANUAL_EMERGENCY";

export type IncidentStatus = "ACTIVE" | "ACKNOWLEDGED" | "RESOLVED";

export type SeverityLevel = "LOW" | "MEDIUM" | "HIGH" | "CRITICAL";

export interface SensorValuesSnapshot {
  heartRate: number;
  temperature: number;
  systolicBP: number;
  diastolicBP: number;
  respiration: number;
  gasLevel: number;
  fallDetected: boolean;
  fireDetected: boolean;
  battery: number;
  spO2?: number;
  noiseDb?: number;
  ldrLux?: number;
}

export interface Worker {
  id: string;
  name: string;
  heartRate: number;        // BPM
  temperature: number;      // °C
  systolicBP: number;       // mmHg
  diastolicBP: number;      // mmHg
  respiration: number;      // breaths/min
  gasLevel: number;         // PPM (MQ sensor)
  fallDetected: boolean;    // MPU6050 Fall
  fireDetected: boolean;    // Flame Sensor
  battery: number;          // %
  latitude: number;         // GPS / Tunnel Coord Lat
  longitude: number;        // GPS / Tunnel Coord Lng
  communicationStatus: CommunicationStatus;
  safetyStatus: SafetyStatus;
  lastUpdated: number;      // timestamp (ms)
  
  // Extended hardware telemetry fields
  spO2?: number;            // MAX30102 O2 %
  noiseDb?: number;         // MEMS Mic dB
  noiseCancel?: boolean;    // Active noise cancellation state
  hapticActive?: boolean;   // Vibration motor state
  headlightOn?: boolean;    // LED headlamp state
  ldrLux?: number;          // LDR ambient light lux
  zone: string;             // Subterranean mine zone (e.g. "Zone A - Main Shaft")
  depthMeters: number;      // Underground depth in meters (e.g. 450)
  shift: "Alpha" | "Beta" | "Gamma";
  hrHistory: number[];      // Trend buffer
}

export interface Incident {
  id: string;               // incident ID (e.g. INC-1001)
  workerId: string;
  workerName: string;
  type: EmergencyType;
  severity: SeverityLevel;
  timestamp: number;
  location: string;
  sensorValues: SensorValuesSnapshot;
  status: IncidentStatus;
  acknowledgementStatus: "UNACKNOWLEDGED" | "ACKNOWLEDGED";
}

export interface CommunicationState {
  connectedClients: number;
  loraGatewayOnline: boolean;
  meshSignalDb: number;
  lastPacketTimestamp: number;
  socketConnected: boolean;
}

export interface MinoMineState {
  workers: Worker[];
  incidents: Incident[];
  activeEmergency: boolean;
  selectedWorkerId: string | null;
  communicationState: CommunicationState;
  filterZone: string;
  filterStatus: string;
  noiseCancelGlobal: boolean;
}
