// client/src/views/NetworkView.jsx
// Subterranean LoRa SX1276 Animated Mesh Topology & Transmission Flow Simulator for MINO MINE

import React, { useState } from "react";
import { motion } from "framer-motion";
import { useMinoMine } from "../context/MinoMineContext";

const NETWORK_STEPS = [
  { id: "sensor", name: "SENSOR EVENT", sub: "MPU6050 / MAX30102 / MQ", icon: "⚡" },
  { id: "mcu", name: "PACKET CREATED", sub: "ESP32 SoC Payload", icon: "📦" },
  { id: "lora", name: "LoRa TRANSMITTING", sub: "868 MHz Sub-GHz", icon: "📡" },
  { id: "rep1", name: "REPEATER 1", sub: "300m Shaft Corridor", icon: "🔁" },
  { id: "rep2", name: "REPEATER 2", sub: "550m Tunnel Junction", icon: "🔁" },
  { id: "rep3", name: "REPEATER 3", sub: "750m Shaft Rise", icon: "🔁" },
  { id: "gateway", name: "GATEWAY", sub: "Ground Elevation 0m", icon: "📶" },
  { id: "control", name: "CONTROL ROOM", sub: "Surface Command Station", icon: "🏢" },
];

export default function NetworkView() {
  const { workers, selectedWorkerId, setSelectedWorkerId, triggerHazardEvent, incidents } = useMinoMine();

  const activeWorkerId = selectedWorkerId || workers[0]?.id || "W001";
  const worker = workers.find((w) => w.id === activeWorkerId) || workers[0];

  const activeIncident = incidents.find(
    (inc) => inc.workerId === worker?.id && inc.status !== "RESOLVED"
  );

  const [activeStepIndex, setActiveStepIndex] = useState(-1);
  const [packetType, setPacketType] = useState("NORMAL"); // "NORMAL" | "EMERGENCY"
  const [packetLabel, setPacketLabel] = useState("IDLE");
  const [lastPacketInfo, setLastPacketInfo] = useState({
    time: new Date().toLocaleTimeString(),
    packetId: `PKT-${worker.id}-7714`,
    rssi: "-68 dBm",
    snr: "+9.8 dB",
    type: "NORMAL TELEMETRY",
    sender: worker.id,
  });

  const isEmergency = worker.safetyStatus === "CRITICAL" || activeIncident !== undefined;

  const runTransmissionSequence = (type = "NORMAL", eventLabel = "TELEMETRY") => {
    setPacketType(type);
    setPacketLabel(`${eventLabel} TRANSMISSION STARTED`);
    setActiveStepIndex(0);

    let currentStep = 0;
    const interval = setInterval(() => {
      currentStep++;
      if (currentStep < NETWORK_STEPS.length) {
        setActiveStepIndex(currentStep);
        setPacketLabel(`${NETWORK_STEPS[currentStep].name} — ${type === "EMERGENCY" ? "EMERGENCY PACKET" : "TELEMETRY"}`);
      } else {
        clearInterval(interval);
        setActiveStepIndex(-1);
        setPacketLabel("CONTROL ROOM RECEIVED — PACKET DELIVERED");
        setLastPacketInfo({
          time: new Date().toLocaleTimeString(),
          packetId: `PKT-${worker.id}-${Math.floor(1000 + Math.random() * 9000)}`,
          rssi: type === "EMERGENCY" ? "-62 dBm (HIGH PRIORITY)" : "-68 dBm",
          snr: "+9.8 dB",
          type: type === "EMERGENCY" ? `EMERGENCY ALERT (${eventLabel})` : "NORMAL TELEMETRY",
          sender: worker.id,
        });
      }
    }, 450);
  };

  const handleSimulateHazard = (hazardType, label) => {
    triggerHazardEvent(worker.id, hazardType);
    runTransmissionSequence("EMERGENCY", label);
  };

  return (
    <div className="space-y-6 font-mono text-slate-100 bg-slate-950 p-4 sm:p-6 rounded-2xl">
      {/* ─── PAGE HEADER ─── */}
      <div className="command-panel p-5 border-l-4 border-l-cyan-500 bg-slate-900 border-slate-800 rounded-xl flex items-center justify-between flex-wrap gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs font-bold text-cyan-400 bg-cyan-500/10 px-2.5 py-0.5 rounded border border-cyan-500/30">
              MINO MINE
            </span>
            <span className="text-xs text-slate-400">
              SUBTERRANEAN LORA MESH NETWORK
            </span>
          </div>
          <h1 className="font-display text-2xl font-black text-white">
            WORKER TO CONTROL ROOM COMMUNICATION FLOW
          </h1>
          <p className="text-xs text-amber-400 font-bold mt-1">
            LoRa Communication Simulation (SX1276 Sub-GHz Mesh Architecture)
          </p>
        </div>

        <div className="flex items-center gap-3">
          <span className="text-xs px-3 py-1.5 rounded bg-slate-800 text-amber-400 border border-slate-700">
            SIMULATION MODE (NO PHYSICAL HARDWARE)
          </span>
        </div>
      </div>

      {/* ─── WORKER & EVENT TRIGGER SELECTION ─── */}
      <div className="command-panel p-5 bg-slate-900 border-slate-800 rounded-xl space-y-4">
        <div className="flex items-center justify-between flex-wrap gap-3 border-b border-slate-800 pb-3">
          <div>
            <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">
              SELECT TARGET WORKER FOR TRANSMISSION FLOW
            </span>
            <span className="text-sm font-bold text-white">
              Selected: <strong className="text-amber-400">{worker.id} — {worker.name}</strong> ({worker.zone.split("–")[0].trim()})
            </span>
          </div>

          <select
            value={activeWorkerId}
            onChange={(e) => setSelectedWorkerId(e.target.value)}
            className="bg-slate-800 border border-slate-700 text-white font-bold text-xs rounded-lg px-3 py-2 focus:outline-none focus:border-cyan-500 cursor-pointer"
          >
            {workers.map((w) => (
              <option key={w.id} value={w.id}>
                {w.id} — {w.name} ({w.safetyStatus})
              </option>
            ))}
          </select>
        </div>

        {/* Hazard Simulation Trigger Buttons */}
        <div>
          <span className="text-xs text-slate-400 font-bold uppercase tracking-wider block mb-2">
            TRIGGER WORKER EMERGENCY TRANSMISSION (TARGET: {worker.id})
          </span>
          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2 text-xs">
            <button
              onClick={() => handleSimulateHazard("FALL", "FALL DETECTED")}
              className="p-2.5 rounded-lg bg-red-950/60 hover:bg-red-900/60 text-red-300 font-bold border border-red-500/50 transition-all text-center"
            >
              🤸 FALL
            </button>
            <button
              onClick={() => handleSimulateHazard("FIRE", "FLAME FIRE")}
              className="p-2.5 rounded-lg bg-orange-950/60 hover:bg-orange-900/60 text-orange-300 font-bold border border-orange-500/50 transition-all text-center"
            >
              🔥 FIRE
            </button>
            <button
              onClick={() => handleSimulateHazard("GAS_LEAK", "GAS LEAK")}
              className="p-2.5 rounded-lg bg-amber-950/60 hover:bg-amber-900/60 text-amber-300 font-bold border border-amber-500/50 transition-all text-center"
            >
              ☁️ GAS LEAK
            </button>
            <button
              onClick={() => handleSimulateHazard("MEDICAL", "MEDICAL EMERGENCY")}
              className="p-2.5 rounded-lg bg-purple-950/60 hover:bg-purple-900/60 text-purple-300 font-bold border border-purple-500/50 transition-all text-center"
            >
              🚑 MEDICAL
            </button>
            <button
              onClick={() => triggerHazardEvent(worker.id, "heartRate") || handleSimulateHazard("MEDICAL", "HIGH HEART RATE")}
              className="p-2.5 rounded-lg bg-red-950/60 hover:bg-red-900/60 text-red-300 font-bold border border-red-500/50 transition-all text-center"
            >
              ❤️ HIGH HR
            </button>
            <button
              onClick={() => triggerHazardEvent(worker.id, "temperature") || handleSimulateHazard("HIGH_TEMPERATURE", "HIGH TEMP")}
              className="p-2.5 rounded-lg bg-orange-950/60 hover:bg-orange-900/60 text-orange-300 font-bold border border-orange-500/50 transition-all text-center"
            >
              🌡️ HIGH TEMP
            </button>
            <button
              onClick={() => handleSimulateHazard("MANUAL_EMERGENCY", "SOS ALARM")}
              className="p-2.5 rounded-lg bg-red-600 hover:bg-red-500 text-white font-black border border-red-400 transition-all text-center animate-pulse"
            >
              🆘 SOS
            </button>
          </div>
        </div>
      </div>

      {/* ─── REAL-TIME TRANSMISSION STATUS BANNER ─── */}
      <div
        className={`command-panel p-4 border rounded-xl flex items-center justify-between flex-wrap gap-4 transition-all ${
          activeStepIndex >= 0 || isEmergency
            ? "border-red-500 bg-red-950/40 text-red-300 shadow-[0_0_20px_rgba(239,68,68,0.3)] animate-pulse"
            : "border-cyan-500/50 bg-cyan-950/20 text-cyan-300"
        }`}
      >
        <div className="flex items-center gap-3">
          <span className="text-2xl">{isEmergency ? "🚨" : "📡"}</span>
          <div>
            <span className="text-[10px] text-slate-400 block uppercase">COMMUNICATION FLOW STATUS</span>
            <span className="font-display font-black text-base text-white tracking-wider">{packetLabel}</span>
          </div>
        </div>

        <div className="flex items-center gap-4 text-xs">
          <div>
            <span className="text-slate-400 block text-[10px]">PACKET OWNER</span>
            <span className="font-bold text-amber-400">{worker.id} ({worker.name})</span>
          </div>

          <div>
            <span className="text-slate-400 block text-[10px]">PACKET TYPE</span>
            <span className={`font-bold ${isEmergency ? "text-red-400" : "text-cyan-400"}`}>
              {packetType === "EMERGENCY" ? "RED / EMERGENCY PACKET" : "BLUE / NORMAL TELEMETRY"}
            </span>
          </div>

          <button
            onClick={() => runTransmissionSequence(isEmergency ? "EMERGENCY" : "NORMAL", isEmergency ? "EMERGENCY ALARM" : "TELEMETRY")}
            className="px-3 py-1.5 rounded bg-slate-800 text-white border border-slate-700 hover:border-slate-500 text-xs font-bold"
          >
            TEST TRANSMISSION
          </button>
        </div>
      </div>

      {/* ─── 8-STEP ANIMATED SUBTERRANEAN TRANSMISSION CHAIN ─── */}
      <div className="command-panel p-6 bg-slate-900 border-slate-800 rounded-xl space-y-6 relative overflow-hidden">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div>
            <span className="text-[10px] text-cyan-400 font-bold uppercase tracking-widest block">
              8-Stage Subterranean Mesh Flow
            </span>
            <h3 className="font-display font-bold text-white text-lg mt-0.5">
              Sensor → ESP32 → LoRa → Repeater 1 → Repeater 2 → Repeater 3 → Gateway → Control Room
            </h3>
          </div>
          <div className="text-xs text-slate-400 flex items-center gap-4">
            <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-cyan-400" /> Normal Telemetry</span>
            <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-red-500 animate-ping" /> Emergency Packet</span>
          </div>
        </div>

        {/* Chain Pipeline */}
        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-2 relative z-10">
          {NETWORK_STEPS.map((step, idx) => {
            const isCurrentStep = activeStepIndex === idx;
            const isPassedStep = activeStepIndex > idx;
            const stepEmergency = isEmergency && (isCurrentStep || isPassedStep);

            const stepColor = stepEmergency
              ? "#ef4444"
              : isCurrentStep
              ? "#38bdf8"
              : isPassedStep
              ? "#10b981"
              : "#64748b";

            return (
              <motion.div
                key={step.id}
                animate={isCurrentStep ? { scale: [1, 1.05, 1] } : {}}
                className={`p-3 rounded-xl border flex flex-col justify-between text-center transition-all min-h-[140px] ${
                  isCurrentStep
                    ? stepEmergency
                      ? "bg-red-950/80 border-red-500 shadow-[0_0_20px_rgba(239,68,68,0.4)]"
                      : "bg-cyan-950/80 border-cyan-400 shadow-[0_0_20px_rgba(56,189,248,0.3)]"
                    : "bg-slate-950 border-slate-800"
                }`}
              >
                <div className="text-2xl mb-1">{step.icon}</div>
                <div>
                  <div className="font-bold text-xs text-white uppercase leading-tight">{step.name}</div>
                  <div className="text-[9px] text-slate-400 mt-1">{step.sub}</div>
                </div>

                <div className="mt-2 pt-2 border-t border-slate-800/80 text-[9px] flex items-center justify-center">
                  <span
                    className="font-bold px-1.5 py-0.5 rounded text-[8px]"
                    style={{ color: stepColor, background: `${stepColor}20` }}
                  >
                    {isCurrentStep ? "TRANSMITTING" : isPassedStep ? "RECEIVED" : "READY"}
                  </span>
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>

      {/* ─── LIVE PACKET DIAGNOSTICS LOG ─── */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-2 font-mono text-xs">
        <div className="bg-slate-900 p-3.5 rounded-xl border border-slate-800">
          <span className="text-[10px] text-slate-400 block uppercase">PACKET ID</span>
          <span className="font-bold text-cyan-400 text-sm mt-0.5 block">{lastPacketInfo.packetId}</span>
        </div>

        <div className="bg-slate-900 p-3.5 rounded-xl border border-slate-800">
          <span className="text-[10px] text-slate-400 block uppercase">SIGNAL (RSSI)</span>
          <span className="font-bold text-emerald-400 text-sm mt-0.5 block">{lastPacketInfo.rssi}</span>
        </div>

        <div className="bg-slate-900 p-3.5 rounded-xl border border-slate-800">
          <span className="text-[10px] text-slate-400 block uppercase">LAST PACKET TIME</span>
          <span className="font-bold text-white text-sm mt-0.5 block">{lastPacketInfo.time}</span>
        </div>

        <div className="bg-slate-900 p-3.5 rounded-xl border border-slate-800">
          <span className="text-[10px] text-slate-400 block uppercase">TARGET WORKER</span>
          <span className="font-bold text-amber-400 text-sm mt-0.5 block">{lastPacketInfo.sender}</span>
        </div>
      </div>
    </div>
  );
}

