// client/src/services/alertEngine.js
// Automated safety state evaluation and incident generation engine for MINO MINE

/**
 * Classifies the overall safety status of a worker based on 12-hardware telemetry rules.
 * @param {import('../types/minomine').Worker} worker
 * @returns {import('../types/minomine').SafetyStatus}
 */
export function evaluateSafetyStatus(worker) {
  if (worker.communicationStatus === "OFFLINE") {
    return "OFFLINE";
  }

  // Critical conditions
  if (
    worker.fallDetected ||
    worker.fireDetected ||
    worker.gasLevel >= 180 ||
    worker.temperature >= 38.5 ||
    worker.heartRate > 130 ||
    worker.heartRate < 45 ||
    (worker.spO2 !== undefined && worker.spO2 < 90) ||
    worker.respiration < 8 ||
    worker.respiration > 30
  ) {
    return "CRITICAL";
  }

  // Warning conditions
  if (
    worker.gasLevel >= 80 ||
    worker.temperature >= 37.5 ||
    worker.heartRate > 105 ||
    worker.heartRate < 55 ||
    (worker.spO2 !== undefined && worker.spO2 < 94) ||
    worker.systolicBP > 140 ||
    worker.battery < 15 ||
    worker.communicationStatus === "DEGRADED"
  ) {
    return "WARNING";
  }

  return "SAFE";
}

/**
 * Checks if worker telemetry requires triggering a new Incident.
 * @param {import('../types/minomine').Worker} worker
 * @returns {import('../types/minomine').Incident|null}
 */
export function checkWorkerIncident(worker) {
  let emergencyType = null;
  let severity = "MEDIUM";

  if (worker.fireDetected) {
    emergencyType = "FIRE";
    severity = "CRITICAL";
  } else if (worker.fallDetected) {
    emergencyType = "FALL";
    severity = "CRITICAL";
  } else if (worker.gasLevel >= 180) {
    emergencyType = "GAS_LEAK";
    severity = "CRITICAL";
  } else if (worker.temperature >= 38.5) {
    emergencyType = "HIGH_TEMPERATURE";
    severity = "HIGH";
  } else if (worker.heartRate > 130 || worker.heartRate < 45) {
    emergencyType = "ABNORMAL_HEART_RATE";
    severity = "HIGH";
  } else if (worker.communicationStatus === "OFFLINE") {
    emergencyType = "MISSING_WORKER";
    severity = "HIGH";
  } else if (
    (worker.spO2 !== undefined && worker.spO2 < 88) ||
    worker.respiration < 8 ||
    worker.respiration > 30 ||
    worker.systolicBP > 160
  ) {
    emergencyType = "MEDICAL";
    severity = "HIGH";
  }

  if (!emergencyType) return null;

  return {
    id: `INC-${Date.now().toString().slice(-6)}-${Math.floor(Math.random() * 900 + 100)}`,
    workerId: worker.id,
    workerName: worker.name,
    type: emergencyType,
    severity,
    timestamp: Date.now(),
    location: `${worker.zone} (${worker.depthMeters}m Depth)`,
    sensorValues: {
      heartRate: worker.heartRate,
      temperature: worker.temperature,
      systolicBP: worker.systolicBP,
      diastolicBP: worker.diastolicBP,
      respiration: worker.respiration,
      gasLevel: worker.gasLevel,
      fallDetected: worker.fallDetected,
      fireDetected: worker.fireDetected,
      battery: worker.battery,
      spO2: worker.spO2,
      noiseDb: worker.noiseDb,
      ldrLux: worker.ldrLux,
    },
    status: "ACTIVE",
    acknowledgementStatus: "UNACKNOWLEDGED",
  };
}
